﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace YB_Timeliness_Reporter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnbrowse_Click(object sender, EventArgs e)
        {
            Connect_To_Excel();
        }

        public void Connect_To_Excel()
        {
            try
            {
                OpenFileDialog openFileDialog1 = new OpenFileDialog();  //create openfileDialog Object
                //openFileDialog1.Filter = "Excel Files (*.xls; *.xlsx|*.xls; *.xlsx";//open file format define Excel Files(.xls)|*.xls| Excel Files(.xlsx)|*.xlsx| 
                openFileDialog1.Filter = "Excel Files (*.xlsx|*.xlsx";//open file format define Excel Files(.xls)|*.xls| Excel Files(.xlsx)|*.xlsx| 
                openFileDialog1.FilterIndex = 3;
                openFileDialog1.FilterIndex = 3;

                openFileDialog1.Multiselect = false;        //not allow multiline selection at the file selection level
                openFileDialog1.Title = "Open OBIEE Report";   //define the name of openfileDialog
                openFileDialog1.InitialDirectory = @"Desktop"; //define the initial directory

                if (openFileDialog1.ShowDialog() == DialogResult.OK)        //executing when file open
                {

                    dgridmain.DataSource = null;
                    dgridmain.Rows.Clear();

                    string pathName = openFileDialog1.FileName;
                    string fileName = System.IO.Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
                    DataTable tbContainer = new DataTable();
                    string strConn = string.Empty;
                    string sheetName = fileName;

                    FileInfo file = new FileInfo(pathName);
                    if (!file.Exists) { throw new Exception("Error, file doesn't exists!"); }
                    string extension = file.Extension;
                    switch (extension)
                    {
                        case ".xls":
                            strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                            //strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + pathName + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
                            break;
                        case ".xlsx":
                            //strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                            strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + pathName + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
                            break;
                        default:
                            strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                            break;
                    }

                    OleDbConnection cnnxls = new OleDbConnection(strConn);
                    cnnxls.Open();
                    DataTable dtsheet = new DataTable();
                    dtsheet = cnnxls.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    string ExcelSheetName = dtsheet.Rows[0]["Table_Name"].ToString();    //get First Excel Sheet Name

                    OleDbDataAdapter oda = new OleDbDataAdapter(string.Format("select * from [" + ExcelSheetName.Trim('\'') + "] WHERE YEAR([Org Author]) > 2017 OR [Org Author] = null ", sheetName), cnnxls);
                    oda.Fill(tbContainer);
                    tbContainer.AcceptChanges();

                    dgridmain.DataSource = tbContainer;
                    lbltotalrow.Text = dgridmain.Rows.Count.ToString();

                    foreach (DataGridViewColumn dgcol in dgridmain.Columns)
                    {
                        dgcol.SortMode = DataGridViewColumnSortMode.NotSortable;
                        dgcol.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                    }
                    cnnxls.Close();
                    MessageBox.Show("OBIEE Report has been sucessfully loaded", "OBIEE Loaded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Unable to load excel file. Please select file with .xlsx only", "Unable to load", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using Excel = Microsoft.Office.Interop.Excel;

namespace YB_Timeliness_Reporter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbchecklistcpo.SelectedIndex = 0;
            cmbcpo.SelectedIndex = 0;
            cmbonlinecpo.SelectedIndex = 0;
            Create_Grid_Columns();

            dtpickerstart.Value = dtpickerstart.Value.AddMonths(-6);
            dtponlinestart.Value = dtponlinestart.Value.AddMonths(-2);
            //dtpickerend.Value = dtpickerstart.Value.AddMonths(4);
        }

        private void btnbrowse_Click(object sender, EventArgs e)
        {
            Connect_To_Excel();
            Print_ECOMP_Checklist();
        }
        public void Connect_To_Excel()
        {
            //try
            //{
                OpenFileDialog openFileDialog1 = new OpenFileDialog();  //create openfileDialog Object
                //openFileDialog1.Filter = "Excel Files (*.xls; *.xlsx|*.xls; *.xlsx";//open file format define Excel Files(.xls)|*.xls| Excel Files(.xlsx)|*.xlsx| 
                openFileDialog1.Filter = "Excel Files (*.xlsx|*.xlsx";//open file format define Excel Files(.xls)|*.xls| Excel Files(.xlsx)|*.xlsx| 
                openFileDialog1.FilterIndex = 3;
                openFileDialog1.FilterIndex = 3;

                openFileDialog1.Multiselect = false;        //not allow multiline selection at the file selection level
                openFileDialog1.Title = "Open OBIEE Report";   //define the name of openfileDialog
                openFileDialog1.InitialDirectory = @"Desktop"; //define the initial directory

                if (openFileDialog1.ShowDialog() == DialogResult.OK)        //executing when file open
                {

                    dgridmain.DataSource = null;
                    dgridmain.Rows.Clear();

                    string pathName = openFileDialog1.FileName;
                    string fileName = System.IO.Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
                    DataTable tbContainer = new DataTable();
                    string strConn = string.Empty;
                    string sheetName = fileName;

                    FileInfo file = new FileInfo(pathName);
                    if (!file.Exists) { throw new Exception("Error, file doesn't exists!"); }
                    string extension = file.Extension;
                    switch (extension)
                    {
                        case ".xls":
                            strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                            //strConn = @"Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + pathName + ";" + "Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\"";

                            //strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + pathName + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
                            break;
                        case ".xlsx":
                            //strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + pathName + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
                            strConn = @"Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + pathName + ";" + "Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\"";
                            break;
                        default:
                            strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                            break;
                    }

                    txtbrowse.Text = pathName.ToString();

                    OleDbConnection cnnxls = new OleDbConnection(strConn);
                    cnnxls.Open();
                    DataTable dtsheet = new DataTable();
                    dtsheet = cnnxls.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    string ExcelSheetName = dtsheet.Rows[0]["Table_Name"].ToString();    //get First Excel Sheet Name

                    OleDbDataAdapter oda = new OleDbDataAdapter(string.Format("select * from [" + ExcelSheetName.Trim('\'') + "] WHERE (FORMAT([Org Author], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to OR FORMAT([P Author], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to) AND YEAR([P Author]) = '" + dtpickerstart.Value.ToString("yyyy") + "' ", sheetName), cnnxls); //AND YEAR([P Author]) =  " + dtpickerstart.Value.ToString("yyyy") + " 
                    //oda.SelectCommand.Parameters.AddWithValue("@from", dtpickerstart.Value.ToString("MM/dd/yyyy"));
                    //oda.SelectCommand.Parameters.AddWithValue("@to", dtpickerend.Value.AddMonths(12).ToString("MM/dd/yyyy"));
                    oda.SelectCommand.Parameters.Add("@from", OleDbType.Date).Value = dtpickerstart.Value.ToString("MM/dd/yyyy hh:mm:ss");
                    oda.SelectCommand.Parameters.Add("@to", OleDbType.Date).Value = dtpickerend.Value.ToString("MM/dd/yyyy hh:mm:ss");
                    oda.Fill(tbContainer);
                    tbContainer.AcceptChanges();

                    dgridmain.DataSource = tbContainer;
                    lbltotalrow.Text = dgridmain.Rows.Count.ToString();

                    foreach (DataGridViewColumn dgcol in dgridmain.Columns)
                    {
                        dgcol.SortMode = DataGridViewColumnSortMode.NotSortable;
                        dgcol.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                    }
                    cnnxls.Close();
                    MessageBox.Show("OBIEE Report has been sucessfully loaded", "OBIEE Loaded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            //}
            //catch (Exception)
            //{
            //    MessageBox.Show("Unable to load excel file. Please select file with .xlsx only", "Unable to load", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }
        public void Filter_by_CPO()
        {
            dgridmain.DataSource = null;
            string pathName = txtbrowse.Text;
            string fileName = System.IO.Path.GetFileNameWithoutExtension(txtbrowse.Text);
            DataTable tbContainer = new DataTable();
            string strConn = string.Empty;
            string sheetName = fileName;
            strConn = @"Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + pathName + ";" + "Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\"";

            OleDbConnection cnnxls = new OleDbConnection(strConn);
            cnnxls.Open();
            DataTable dtsheet = new DataTable();
            dtsheet = cnnxls.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            string ExcelSheetName = dtsheet.Rows[0]["Table_Name"].ToString();    //get First Excel Sheet Name

            if (cmbcpo.SelectedItem.ToString() == "ALL CPO")
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("select * from [" + ExcelSheetName.Trim('\'') + "] WHERE (FORMAT([Org Author], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to OR FORMAT([P Author], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to) AND YEAR([P Author]) = '" + dtpickerstart.Value.ToString("yyyy") + "'", sheetName), cnnxls);
                oda123.SelectCommand.Parameters.AddWithValue("@from", dtpickerstart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.SelectCommand.Parameters.AddWithValue("@to", dtpickerend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }
            else if (cmbcpo.SelectedItem.ToString() == "Manila Team Only")
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("select * from [" + ExcelSheetName.Trim('\'') + "] WHERE ([CPO Name] = 'Aquino,Sheila' OR [CPO Name] = 'Ampongan,Yudz Bellen' OR [CPO Name] = 'Dino,Jon Frederick Barazon' OR [CPO Name] = 'Manipon,Dada Apilada') AND (FORMAT([Org Author], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to OR FORMAT([P Author], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to) AND YEAR([P Author]) =  " + dtpickerstart.Value.ToString("yyyy") + " ORDER BY [Pub Pub Number]", sheetName), cnnxls);
                oda123.SelectCommand.Parameters.AddWithValue("@from", dtpickerstart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.SelectCommand.Parameters.AddWithValue("@to", dtpickerend.Value.ToString("MM/dd/yyyy hh:mm:ss"));

                //OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("select * from [" + ExcelSheetName.Trim('\'') + "] WHERE ([CPO Name] = 'Aquino,Sheila' OR [CPO Name] = 'Ampongan,Yudz Bellen' OR [CPO Name] = 'Dino,Jon Frederick Barazon' OR [CPO Name] = 'Manipon,Dada Apilada') AND ([Poc Name] IS NOT NULL AND [Sec Name] IS NOT NULL) AND (YEAR([Org Author]) >= 2018 OR [Org Author] = NULL AND (FORMAT([Org Author], 'MM/dd/yyyy') BETWEEN " + lblstart.Text + " AND " + lblend.Text + " ))", sheetName), cnnxls);
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }
            else if (cmbcpo.SelectedItem.ToString() == "Iloilo Team Only")
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("select * from [" + ExcelSheetName.Trim('\'') + "] WHERE ([CPO Name] = 'Lomigo,Paul Anthony Villeza' OR [CPO Name] = 'Arsenal,Tim Ryan Arroyo' OR [CPO Name] = 'Sumpay,Lirie John Paran')  AND (FORMAT([Org Author], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to OR FORMAT([P Author], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to) AND YEAR([P Author]) =  " + dtpickerstart.Value.ToString("yyyy") + " ", sheetName), cnnxls);
                oda123.SelectCommand.Parameters.AddWithValue("@from", dtpickerstart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.SelectCommand.Parameters.AddWithValue("@to", dtpickerend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }
            else
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("select * from [" + ExcelSheetName.Trim('\'') + "] WHERE [CPO Name] = '" + cmbcpo.SelectedItem.ToString() + "'  AND (FORMAT([Org Author], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to OR FORMAT([P Author], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to) AND YEAR([P Author]) =  " + dtpickerstart.Value.ToString("yyyy") + " ", sheetName), cnnxls);
                oda123.SelectCommand.Parameters.AddWithValue("@from", dtpickerstart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.SelectCommand.Parameters.AddWithValue("@to", dtpickerend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }

            dgridmain.DataSource = tbContainer;
            lbltotalrow.Text = "0";
            lbltotalrow.Text = dgridmain.Rows.Count.ToString();

            foreach (DataGridViewColumn dgcol in dgridmain.Columns)
            {
                dgcol.SortMode = DataGridViewColumnSortMode.NotSortable;
                dgcol.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            }
            cnnxls.Close();
            MessageBox.Show("OBIEE Report has been sucessfully loaded", "OBIEE Loaded", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnmilestones_Click(object sender, EventArgs e)
        {
            Start_Checking();
            /**
            this.dgridpast.Sort(this.dgridpast.Columns["Pub Ops"], ListSortDirection.Ascending);
            this.dgridtoday.Sort(this.dgridtoday.Columns["Pub Ops"], ListSortDirection.Ascending);
            this.dgridweek.Sort(this.dgridweek.Columns["Pub Ops"], ListSortDirection.Ascending);


            this.dgridpast.Sort(this.dgridpast.Columns["Milestone"], ListSortDirection.Ascending);
            this.dgridtoday.Sort(this.dgridtoday.Columns["Milestone"], ListSortDirection.Ascending);
            this.dgridweek.Sort(this.dgridweek.Columns["Milestone"], ListSortDirection.Ascending);
            **/
            foreach (DataGridViewColumn column in dgridpast.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            foreach (DataGridViewColumn column in dgridtoday.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            foreach (DataGridViewColumn column in dgridweek.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }
        public void Create_Grid_Columns()
        {
            dgridpast.Columns.Clear();
            dgridpast.Columns.Add("Pub No.", "Pub No.");
            dgridpast.Columns.Add("Rel No.", "Rel No.");
            dgridpast.Columns.Add("Pub Ops", "Pub Ops");
            dgridpast.Columns.Add("Pub Eds", "Pub Eds");
            dgridpast.Columns.Add("Milestone", "Milestone");
            dgridpast.Columns.Add("P Actual", "P Actual");
            dgridpast.Columns.Add("Actual", "Actual");
            dgridpast.Columns.Add("Comment", "Comment");
            dgridpast.Columns[0].Width = 100;
            dgridpast.Columns[1].Width = 100;
            dgridpast.Columns[2].Width = 200;
            dgridpast.Columns[3].Width = 200;
            dgridpast.Columns[4].Width = 200;
            dgridpast.Columns[5].Width = 100;
            dgridpast.Columns[6].Width = 100;
            dgridpast.Columns[7].Width = 250;

            dgridtoday.Columns.Clear();
            dgridtoday.Columns.Add("Pub No.", "Pub No.");
            dgridtoday.Columns.Add("Rel No.", "Rel No.");
            dgridtoday.Columns.Add("Pub Ops", "Pub Ops");
            dgridtoday.Columns.Add("Pub Eds", "Pub Eds");
            dgridtoday.Columns.Add("Milestone", "Milestone");
            dgridtoday.Columns.Add("P Actual", "P Actual");
            dgridtoday.Columns.Add("Actual", "Actual");
            dgridtoday.Columns.Add("Comment", "Comment");
            dgridtoday.Columns[0].Width = 100;
            dgridtoday.Columns[1].Width = 100;
            dgridtoday.Columns[2].Width = 200;
            dgridtoday.Columns[3].Width = 200;
            dgridtoday.Columns[4].Width = 200;
            dgridtoday.Columns[5].Width = 100;
            dgridtoday.Columns[6].Width = 100;
            dgridtoday.Columns[7].Width = 250;

            dgridweek.Columns.Clear();
            dgridweek.Columns.Add("Pub No.", "Pub No.");
            dgridweek.Columns.Add("Rel No.", "Rel No.");
            dgridweek.Columns.Add("Pub Ops", "Pub Ops");
            dgridweek.Columns.Add("Pub Eds", "Pub Eds");
            dgridweek.Columns.Add("Milestone", "Milestone");
            dgridweek.Columns.Add("P Actual", "P Actual");
            dgridweek.Columns.Add("Actual", "Actual");
            dgridweek.Columns.Add("Comment", "Comment");
            dgridweek.Columns[0].Width = 100;
            dgridweek.Columns[1].Width = 100;
            dgridweek.Columns[2].Width = 200;
            dgridweek.Columns[3].Width = 200;
            dgridweek.Columns[4].Width = 200;
            dgridweek.Columns[5].Width = 100;
            dgridweek.Columns[6].Width = 100;
            dgridweek.Columns[7].Width = 250;
        }
        public void Start_Checking()
        {
            dgridweek.Rows.Clear();
            dgridpast.Rows.Clear();
            dgridtoday.Rows.Clear();

            //Check_Author_Date();
            Check_JO_Date();
            Check_MStoOps_Date();
            Check_CopyEdit_Date();

            Check_DataToOS_Date();
            Check_DataFromOS_Date();
            Check_ContentEnhancement_Date();

            Check_Composition_Date();
            Check_FirstPass_Date();

            //Check_ToAuthor_Date();
            //Check_FromAuthor_Date();
            Check_FirstPassCorrection_Date();

            Check_EditorialQC_Date();
            Check_Showstoppe_Date();

            Check_ContentSignOff_Date();
            Check_Checkpointing_Complete();

            Check_FinalPassComp_Date();
            Check_Clear_Date();

            Check_Promote_Date();

            Check_Lexis_Com_Live_Date();
            Check_LexisQC_Checklist_Date();

            Check_LA_Date();
            Check_LAQC_Checklist_Date();

            Check_Infobase_Date();
            Check_InfobaseQC_Date();
            //Check_InfobaseQC_Checklist_Date();

            Check_eBook_Conversion_Date();
            Check_eBookQC_Date();
            Check_eBookQC_Checklist_Date();

            
            PerGrid_Color();
            lbllatcount.Text = dgridpast.Rows.Count.ToString();
            lbltodaycount.Text = dgridtoday.Rows.Count.ToString();
            lblupcomingcount.Text = dgridweek.Rows.Count.ToString();

            MessageBox.Show("Tool successfully ran the milestone validation!");
        }
        public void PerGrid_Color()
        {
            foreach (DataGridViewRow Myrow in dgridpast.Rows)
            {
                Myrow.HeaderCell.Style.BackColor = Color.LightBlue;
                Myrow.DataGridView.GridColor = Color.Black;
                Myrow.Cells[0].Style.BackColor = Color.White;
                Myrow.Cells[1].Style.BackColor = Color.White;
                Myrow.Cells[2].Style.BackColor = Color.White;
                Myrow.Cells[3].Style.BackColor = Color.White;
                Myrow.Cells[4].Style.BackColor = Color.White;
                Myrow.Cells[5].Style.BackColor = Color.White;
                Myrow.Cells[6].Style.BackColor = Color.White;
                Myrow.Cells[7].Style.BackColor = Color.White;

                if (DateTime.Today.DayOfWeek == DayOfWeek.Monday)
                {
                    if (Convert.ToDateTime(Myrow.Cells["P Actual"].Value) < DateTime.Now.AddDays(-3) && Myrow.Cells["Actual"].Value.ToString() == "" && Myrow.Cells["Comment"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridpast.Columns["Actual"].Index].Style.BackColor = Color.Orange;
                        Myrow.Cells[dgridpast.Columns["Comment"].Index].Style.BackColor = Color.Orange;
                    }
                    if (Convert.ToDateTime(Myrow.Cells["P Actual"].Value) < DateTime.Now.AddDays(-4) && Myrow.Cells["Actual"].Value.ToString() == "" && Myrow.Cells["Comment"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridpast.Columns["Actual"].Index].Style.BackColor = Color.Red;
                        Myrow.Cells[dgridpast.Columns["Comment"].Index].Style.BackColor = Color.Red;
                    }
                }
                else
                {
                    if (Convert.ToDateTime(Myrow.Cells["P Actual"].Value) < DateTime.Now.AddDays(-1) && Myrow.Cells["Actual"].Value.ToString() == "" && Myrow.Cells["Comment"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridpast.Columns["Actual"].Index].Style.BackColor = Color.Orange;
                        Myrow.Cells[dgridpast.Columns["Comment"].Index].Style.BackColor = Color.Orange;
                    }
                    if (Convert.ToDateTime(Myrow.Cells["P Actual"].Value) < DateTime.Now.AddDays(-2) && Myrow.Cells["Actual"].Value.ToString() == "" && Myrow.Cells["Comment"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridpast.Columns["Actual"].Index].Style.BackColor = Color.Red;
                        Myrow.Cells[dgridpast.Columns["Comment"].Index].Style.BackColor = Color.Red;
                    }
                }
            }
            foreach (DataGridViewRow Myrow in dgridtoday.Rows)
            {
                Myrow.DataGridView.GridColor = Color.Black;
                Myrow.Cells[0].Style.BackColor = Color.White;
                Myrow.Cells[1].Style.BackColor = Color.White;
                Myrow.Cells[2].Style.BackColor = Color.White;
                Myrow.Cells[3].Style.BackColor = Color.White;
                Myrow.Cells[4].Style.BackColor = Color.White;
                Myrow.Cells[5].Style.BackColor = Color.White;
                Myrow.Cells[6].Style.BackColor = Color.White;
                Myrow.Cells[7].Style.BackColor = Color.White;
                //if (Myrow.Cells["Actual"].Value.ToString() == "" && Myrow.Cells["Comment"].Value.ToString() == "")
                //{
                Myrow.Cells[dgridtoday.Columns["Actual"].Index].Style.BackColor = Color.Yellow;
                Myrow.Cells[dgridtoday.Columns["Comment"].Index].Style.BackColor = Color.Yellow;
                //}
            }
            foreach (DataGridViewRow Myrow in dgridweek.Rows)
            {
                Myrow.DataGridView.GridColor = Color.Black;
                Myrow.Cells[0].Style.BackColor = Color.White;
                Myrow.Cells[1].Style.BackColor = Color.White;
                Myrow.Cells[2].Style.BackColor = Color.White;
                Myrow.Cells[3].Style.BackColor = Color.White;
                Myrow.Cells[4].Style.BackColor = Color.White;
                Myrow.Cells[5].Style.BackColor = Color.White;
                Myrow.Cells[6].Style.BackColor = Color.White;
                Myrow.Cells[7].Style.BackColor = Color.White;
                //if (Myrow.Cells["Actual"].Value.ToString() == "" && Myrow.Cells["Comment"].Value.ToString() == "")
                //{
                Myrow.Cells[dgridweek.Columns["Actual"].Index].Style.BackColor = Color.YellowGreen;
                    Myrow.Cells[dgridweek.Columns["Comment"].Index].Style.BackColor = Color.YellowGreen;
                //}
            }
        }
        public void Check_Author_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Author"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Author"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Author Date";
                    p_actual = Myrow.Cells["P Author"].Value.ToString();
                    actual = Myrow.Cells["Act Author"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Author"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Author"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Author"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Author"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Author"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Author"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Author"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }
        public void Check_JO_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Job Order"].Value.ToString() == "")
                {
                    mydate = Myrow.Cells["Org Job Order"].Value.ToString();
                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Job Order";
                    p_actual = Myrow.Cells["Org Job Order"].Value.ToString();
                    actual = Myrow.Cells["Act Job Order"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Job Order"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Job Order"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["Org Job Order"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Job Order"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["Org Job Order"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Job Order"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["Org Job Order"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
                else
                {
                    mydate = Myrow.Cells["P Job Order"].Value.ToString();
                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Job Order";
                    p_actual = Myrow.Cells["P Job Order"].Value.ToString();
                    actual = Myrow.Cells["Act Job Order"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Job Order"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Job Order"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Job Order"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Job Order"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Job Order"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Job Order"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Job Order"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }
        public void Check_MStoOps_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Tmpl Template Description"].Value.ToString().Contains("Electronic"))
                { }
                else
                {
                    if (Myrow.Cells["P Ms To Ops"].Value.ToString() == "")
                    {
                        if(Myrow.Cells["Org Ms to Ops"].Value.ToString() == "")
                        { }
                        else
                        {
                            mydate = Myrow.Cells["Org Ms To Ops"].Value.ToString();

                            pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                            relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                            ops = Myrow.Cells["POC Name"].Value.ToString();
                            eds = Myrow.Cells["SEC Name"].Value.ToString();
                            milestone = "Ms To Ops";
                            p_actual = Myrow.Cells["Org Ms To Ops"].Value.ToString();
                            actual = Myrow.Cells["Act Ms To Ops"].Value.ToString();
                            act_comment = Myrow.Cells["Comm Ms To Ops"].Value.ToString();

                            if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Ms To Ops"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Ms To Ops"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                                dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Ms To Ops"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Ms To Ops"].Index].Style.BackColor = Color.Yellow;
                                dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Ms To Ops"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Ms To Ops"].Index].Style.BackColor = Color.Red;
                                dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else { }
                        }
                    }
                    else
                    {
                        mydate = Myrow.Cells["P Ms To Ops"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Ms To Ops";
                        p_actual = Myrow.Cells["P Ms To Ops"].Value.ToString();
                        actual = Myrow.Cells["Act Ms To Ops"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Ms To Ops"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Ms To Ops"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Ms To Ops"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Ms To Ops"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Ms To Ops"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Ms To Ops"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Ms To Ops"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
            }
        }
        public void Check_CopyEdit_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Tity Tier Type"].Value.ToString().Contains("2"))
                {
                    if (Myrow.Cells["P Copy Edit"].Value.ToString() == "")
                    {
                        if (Myrow.Cells["Org Copy Edit"].Value.ToString() == "")
                        { }
                        else
                        {
                            mydate = Myrow.Cells["Org Copy Edit"].Value.ToString();

                            pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                            relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                            ops = Myrow.Cells["POC Name"].Value.ToString();
                            eds = Myrow.Cells["SEC Name"].Value.ToString();
                            milestone = "Copy Edit";
                            p_actual = Myrow.Cells["Org Copy Edit"].Value.ToString();
                            actual = Myrow.Cells["Act Copy Edit"].Value.ToString();
                            act_comment = Myrow.Cells["Comm Copy Edit"].Value.ToString();

                            if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Copy Edit"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Copy Edit"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                                dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Copy Edit"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Copy Edit"].Index].Style.BackColor = Color.Yellow;
                                dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Copy Edit"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Copy Edit"].Index].Style.BackColor = Color.Red;
                                dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else { }
                        }
                    }
                    else
                    {
                        mydate = Myrow.Cells["P Copy Edit"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Copy Edit";
                        p_actual = Myrow.Cells["P Copy Edit"].Value.ToString();
                        actual = Myrow.Cells["Act Copy Edit"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Copy Edit"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Copy Edit"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Copy Edit"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Copy Edit"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Copy Edit"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Copy Edit"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Copy Edit"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
                else
                {
                }
            }
        } //not present in REPH Status Report ran by PO
        public void Check_DataToOS_Date() // No COMMENT Column
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Tmpl Template Description"].Value.ToString().Contains("Electronic"))
                {

                }
                else
                {
                    if (Myrow.Cells["P Data To Outsourcer2"].Value.ToString() == "")
                    {
                        if (Myrow.Cells["Org Data To Outsourcer"].Value.ToString() == "")
                        { }
                        else
                        {
                            mydate = Myrow.Cells["Org Data To Outsourcer"].Value.ToString();

                            pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                            relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                            ops = Myrow.Cells["POC Name"].Value.ToString();
                            eds = Myrow.Cells["SEC Name"].Value.ToString();
                            milestone = "Data To Outsourcer";
                            p_actual = Myrow.Cells["Org Data To Outsourcer"].Value.ToString();
                            actual = Myrow.Cells["Act Data To Outsourcer"].Value.ToString();
                            act_comment = Myrow.Cells["Comm Data To Outsourcer"].Value.ToString();

                            if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Data To Outsourcer"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Data To Outsourcer"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                                dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Data To Outsourcer"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Data To Outsourcer"].Index].Style.BackColor = Color.Yellow;
                                dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Data To Outsourcer"].Value.ToString() == "" && Myrow.Cells["Comm Data To Outsourcer"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Data To Outsourcer"].Index].Style.BackColor = Color.Red;
                                dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else { }
                        }
                    }
                    else
                    {
                        mydate = Myrow.Cells["P Data To Outsourcer2"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Data To Outsourcer";
                        p_actual = Myrow.Cells["P Data To Outsourcer2"].Value.ToString();
                        actual = Myrow.Cells["Act Data To Outsourcer"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Data To Outsourcer"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Data To Outsourcer"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Data To Outsourcer2"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Data To Outsourcer"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Data To Outsourcer2"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Data To Outsourcer"].Value.ToString() == "" && Myrow.Cells["Comm Data To Outsourcer"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Data To Outsourcer2"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
            }
        }
        public void Check_DataFromOS_Date() //NO COMMENT Column
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Tmpl Template Description"].Value.ToString().Contains("Electronic"))
                {
                }
                else
                {
                    if (Myrow.Cells["P Data From Outsourcer"].Value.ToString() == "")
                    {
                        if (Myrow.Cells["Org Data From Outsourcer"].Value.ToString() == "")
                        { }
                        else
                        {
                            mydate = Myrow.Cells["Org Data From Outsourcer"].Value.ToString();

                            pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                            relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                            ops = Myrow.Cells["POC Name"].Value.ToString();
                            eds = Myrow.Cells["SEC Name"].Value.ToString();
                            milestone = "Data From Outsourcer";
                            p_actual = Myrow.Cells["Org Data From Outsourcer"].Value.ToString();
                            actual = Myrow.Cells["Act Data From Outsourcer"].Value.ToString();
                            act_comment = Myrow.Cells["Comm Data From Outsourcer"].Value.ToString();

                            if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Data From Outsourcer"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Data From Outsourcer"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                                dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Data From Outsourcer"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Data From Outsourcer"].Index].Style.BackColor = Color.Yellow;
                                dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Data From Outsourcer"].Value.ToString() == "" && Myrow.Cells["Comm Data From Outsourcer"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Data From Outsourcer"].Index].Style.BackColor = Color.Red;
                                dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else { }
                        }
                    }
                    else
                    {
                        mydate = Myrow.Cells["P Data From Outsourcer"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Data From Outsourcer";
                        p_actual = Myrow.Cells["P Data From Outsourcer"].Value.ToString();
                        actual = Myrow.Cells["Act Data From Outsourcer"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Data From Outsourcer"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Data From Outsourcer"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Data From Outsourcer"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Data From Outsourcer"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Data From Outsourcer"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Data From Outsourcer"].Value.ToString() == "" && Myrow.Cells["Comm Data From Outsourcer"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Data From Outsourcer"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
                
            }
        }
        public void Check_ContentEnhancement_Date() //not present in REPH Status Report ran by PO
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Tmpl Template Description"].Value.ToString().Contains("Electronic"))
                {
                }
                else
                {
                    if (Myrow.Cells["P Content Enhancements"].Value.ToString() == "")
                    {
                        if (Myrow.Cells["Org Content Enhancements"].Value.ToString() == "") { }
                        else
                        {
                            mydate = Myrow.Cells["Org Content Enhancements"].Value.ToString();

                            pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                            relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                            ops = Myrow.Cells["POC Name"].Value.ToString();
                            eds = Myrow.Cells["SEC Name"].Value.ToString();
                            milestone = "Content Enhancements";
                            p_actual = Myrow.Cells["Org Content Enhancements"].Value.ToString();
                            actual = Myrow.Cells["Act Content Enhancements"].Value.ToString();
                            act_comment = Myrow.Cells["Comm Content Enhancements"].Value.ToString();

                            if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Content Enhancements"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Content Enhancements"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                                dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Content Enhancements"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Content Enhancements"].Index].Style.BackColor = Color.Yellow;
                                dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Content Enhancements"].Value.ToString() == "" && Myrow.Cells["Comm Content Enhancements"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Content Enhancements"].Index].Style.BackColor = Color.Red;
                                dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else { }
                        }
                    }
                    else
                    {
                        mydate = Myrow.Cells["P Content Enhancements"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Content Enhancements";
                        p_actual = Myrow.Cells["P Content Enhancements"].Value.ToString();
                        actual = Myrow.Cells["Act Content Enhancements"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Content Enhancements"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Content Enhancements"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Content Enhancements"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Content Enhancements"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Content Enhancements"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Content Enhancements"].Value.ToString() == "" && Myrow.Cells["Comm Content Enhancements"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Content Enhancements"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
            }
        }
        public void Check_Composition_Date() //not present in REPH Status Report ran by PO
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Composition"].Value.ToString() == "")
                {
                    if (Myrow.Cells["Org Composition"].Value.ToString() == "") { }
                    else
                    {
                        mydate = Myrow.Cells["Org Composition"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Composition";
                        p_actual = Myrow.Cells["Org Composition"].Value.ToString();
                        actual = Myrow.Cells["Act Composition"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Composition"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Composition"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["Org Composition"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Composition"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["Org Composition"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Composition"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["Org Composition"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    } 
                }
                else
                {
                    mydate = Myrow.Cells["P Composition"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Composition";
                    p_actual = Myrow.Cells["P Composition"].Value.ToString();
                    actual = Myrow.Cells["Act Composition"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Composition"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Composition"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Composition"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Composition"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Composition"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Composition"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Composition"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }

        public void Check_FirstPass_Date() //NO COMMENT Column
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Tmpl Template Description"].Value.ToString().Contains("Electronic"))
                { }
                else
                {
                    if (Myrow.Cells["P First Pass"].Value.ToString() == "")
                    {
                        if (Myrow.Cells["Org First Pass"].Value.ToString() == "") { }
                        else
                        {
                            mydate = Myrow.Cells["Org First Pass"].Value.ToString();

                            pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                            relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                            ops = Myrow.Cells["POC Name"].Value.ToString();
                            eds = Myrow.Cells["SEC Name"].Value.ToString();
                            milestone = "First Pass";
                            p_actual = Myrow.Cells["Org First Pass"].Value.ToString();
                            actual = Myrow.Cells["Act First Pass"].Value.ToString();
                            act_comment = Myrow.Cells["Comm First Pass"].Value.ToString();

                            if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act First Pass"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org First Pass"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                                dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act First Pass"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org First Pass"].Index].Style.BackColor = Color.Yellow;
                                dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act First Pass"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org First Pass"].Index].Style.BackColor = Color.Red;
                                dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else { }
                        }
                    }
                    else
                    {
                        mydate = Myrow.Cells["P First Pass"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "First Pass";
                        p_actual = Myrow.Cells["P First Pass"].Value.ToString();
                        actual = Myrow.Cells["Act First Pass"].Value.ToString();
                        act_comment = Myrow.Cells["Comm First Pass"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act First Pass"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P First Pass"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act First Pass"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P First Pass"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act First Pass"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P First Pass"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
            }
        }
        public void Check_ToAuthor_Date() //not present in REPH Status Report ran by PO
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Pub Author Review"].Value.ToString() == "N")
                { }
                else
                {
                    if (Myrow.Cells["P To Author"].Value.ToString() == "")
                    {
                        if (Myrow.Cells["Org To Author"].Value.ToString() == "") { }
                        else
                        {
                            mydate = Myrow.Cells["Org To Author"].Value.ToString();

                            pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                            relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                            ops = Myrow.Cells["POC Name"].Value.ToString();
                            eds = Myrow.Cells["SEC Name"].Value.ToString();
                            milestone = "To Author";
                            p_actual = Myrow.Cells["Org To Author"].Value.ToString();
                            actual = Myrow.Cells["Act To Author"].Value.ToString();
                            act_comment = Myrow.Cells["Comm To Author"].Value.ToString();

                            if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act To Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                            {
                                Myrow.Cells[dgridmain.Columns["Org To Author"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                                dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act To Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                            {
                                Myrow.Cells[dgridmain.Columns["Org To Author"].Index].Style.BackColor = Color.Yellow;
                                dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act To Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                            {
                                Myrow.Cells[dgridmain.Columns["Org To Author"].Index].Style.BackColor = Color.Red;
                                dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else { }
                        }
                    }
                    else
                    {
                        mydate = Myrow.Cells["P To Author"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "To Author";
                        p_actual = Myrow.Cells["P To Author"].Value.ToString();
                        actual = Myrow.Cells["Act To Author"].Value.ToString();
                        act_comment = Myrow.Cells["Comm To Author"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act To Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                        {
                            Myrow.Cells[dgridmain.Columns["P To Author"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act To Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                        {
                            Myrow.Cells[dgridmain.Columns["P To Author"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act To Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                        {
                            Myrow.Cells[dgridmain.Columns["P To Author"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
            }
        }
        public void Check_FromAuthor_Date() //not present in REPH Status Report ran by PO
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Pub Author Review"].Value.ToString()== "N")
                { }
                else
                {
                    if (Myrow.Cells["P From Author"].Value.ToString() == "")
                    {
                        if (Myrow.Cells["Org From Author"].Value.ToString() == "") { }
                        else
                        {
                            mydate = Myrow.Cells["Org From Author"].Value.ToString();

                            pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                            relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                            ops = Myrow.Cells["POC Name"].Value.ToString();
                            eds = Myrow.Cells["SEC Name"].Value.ToString();
                            milestone = "From Author";
                            p_actual = Myrow.Cells["Org From Author"].Value.ToString();
                            actual = Myrow.Cells["Act From Author"].Value.ToString();
                            act_comment = Myrow.Cells["Comm From Author"].Value.ToString();

                            if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act From Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                            {
                                Myrow.Cells[dgridmain.Columns["Org From Author"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                                dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act From Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                            {
                                Myrow.Cells[dgridmain.Columns["Org From Author"].Index].Style.BackColor = Color.Yellow;
                                dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act From Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                            {
                                Myrow.Cells[dgridmain.Columns["Org From Author"].Index].Style.BackColor = Color.Red;
                                dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else { }
                        }
                    }
                    else
                    {
                        mydate = Myrow.Cells["P From Author"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "From Author";
                        p_actual = Myrow.Cells["P From Author"].Value.ToString();
                        actual = Myrow.Cells["Act From Author"].Value.ToString();
                        act_comment = Myrow.Cells["Comm From Author"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act From Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                        {
                            Myrow.Cells[dgridmain.Columns["P From Author"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act From Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                        {
                            Myrow.Cells[dgridmain.Columns["P From Author"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act From Author"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                        {
                            Myrow.Cells[dgridmain.Columns["P From Author"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
            }
        }
        public void Check_FirstPassCorrection_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P First Pass Corrections"].Value.ToString() == "")
                {
                    if (Myrow.Cells["Org First Pass Corrections"].Value.ToString() == "") { }
                    else
                    {
                        mydate = Myrow.Cells["Org First Pass Corrections"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "First Pass Corrections";
                        p_actual = Myrow.Cells["Org First Pass Corrections"].Value.ToString();
                        actual = Myrow.Cells["Act First Pass Corrections"].Value.ToString();
                        act_comment = Myrow.Cells["Comm First Pass Corrections"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act First Pass Corrections"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                        {
                            Myrow.Cells[dgridmain.Columns["Org First Pass Corrections"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act First Pass Corrections"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                        {
                            Myrow.Cells[dgridmain.Columns["Org First Pass Corrections"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act First Pass Corrections"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                        {
                            Myrow.Cells[dgridmain.Columns["Org First Pass Corrections"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
                else
                {
                    mydate = Myrow.Cells["P First Pass Corrections"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "First Pass Corrections";
                    p_actual = Myrow.Cells["P First Pass Corrections"].Value.ToString();
                    actual = Myrow.Cells["Act First Pass Corrections"].Value.ToString();
                    act_comment = Myrow.Cells["Comm First Pass Corrections"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act First Pass Corrections"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P First Pass Corrections"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act First Pass Corrections"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P First Pass Corrections"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act First Pass Corrections"].Value.ToString() == "" && Myrow.Cells["Pub Author Review"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P First Pass Corrections"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }

        public void Check_EditorialQC_Date() //NO COMMENT Column
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Tmpl Template Description"].Value.ToString().Contains("Electronic")) // && Myrow.Cells["P Editorial Qc"].Value.ToString() != "" && DateTime.Now > Convert.ToDateTime(Myrow.Cells["P Editorial Qc"].Value.ToString()) && Myrow.Cells["Act Editorial Qc"].Value.ToString() == "")
                { }
                else
                {
                    if (Myrow.Cells["P Editorial Qc"].Value.ToString() == "")
                    {
                        if (Myrow.Cells["Org Editorial QC"].Value.ToString() == "") { }
                        else
                        {
                            mydate = Myrow.Cells["Org Editorial Qc"].Value.ToString();

                            pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                            relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                            ops = Myrow.Cells["POC Name"].Value.ToString();
                            eds = Myrow.Cells["SEC Name"].Value.ToString();
                            milestone = "Editorial Qc";
                            p_actual = Myrow.Cells["Org Editorial Qc"].Value.ToString();
                            actual = Myrow.Cells["Act Editorial Qc"].Value.ToString();
                            act_comment = Myrow.Cells["Comm Editorial Qc"].Value.ToString();

                            if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Editorial Qc"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Editorial Qc"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                                dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Editorial Qc"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Editorial Qc"].Index].Style.BackColor = Color.Yellow;
                                dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Editorial Qc"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Editorial Qc"].Index].Style.BackColor = Color.Red;
                                dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else { }
                        }
                    }
                    else
                    {
                        mydate = Myrow.Cells["P Editorial Qc"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Editorial Qc";
                        p_actual = Myrow.Cells["P Editorial Qc"].Value.ToString();
                        actual = Myrow.Cells["Act Editorial Qc"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Editorial Qc"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Editorial Qc"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Editorial Qc"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Editorial Qc"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Editorial Qc"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Editorial Qc"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Editorial Qc"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
            }
        }
        public void Check_Showstoppe_Date() //NO COMMENT Column
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Tmpl Template Description"].Value.ToString().Contains("Tier 1"))
                {
                    object showstopper_column;
                    object dgrid_main_col;
                    if (Myrow.Cells["P Checklistfiledeliveredtoc"].Value.ToString() == "")
                    {
                        //showstopper_column = @"""Rev Checklistfiledeliveredtoc""";
                        showstopper_column = Myrow.Cells["Rev Checklistfiledeliveredtoc"].Value.ToString();
                        dgrid_main_col = "Rev";//@"dgridmain.Columns[" + "\"Rev Checklistfiledeliveredtoc\"" + "].Index";
                    }
                    else if (Myrow.Cells["Rev Checklistfiledeliveredtoc"].Value.ToString() == "")
                    {
                        showstopper_column = Myrow.Cells["Org Checklistfiledeliveredtoc"].Value.ToString();
                        dgrid_main_col = "Org"; //@"dgridmain.Columns[" + "\"Org Checklistfiledeliveredtoc\"" + "].Index";
                    }
                    else
                    {
                        showstopper_column = Myrow.Cells["P Checklistfiledeliveredtoc"].Value.ToString();
                        dgrid_main_col = "P"; //@"dgridmain.Columns[" + "\"P Checklistfiledeliveredtoc\"" + "].Index";
                    }
                    //MessageBox.Show(dgrid_main_col.ToString());

                    if (showstopper_column.ToString() == "")
                    { }
                    else
                    {
                        mydate = showstopper_column.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Checklist File Delivered";
                        p_actual = showstopper_column.ToString();
                        actual = Myrow.Cells["Act Checklistfiledeliveredtoc"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Checklistfiledeliveredtoc"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Checklistfiledeliveredtoc"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns[@"" + dgrid_main_col.ToString() + " Checklistfiledeliveredtoc"].Index].Style.BackColor = Color.LightGreen;
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Checklistfiledeliveredtoc"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns[@"" + dgrid_main_col.ToString() + " Checklistfiledeliveredtoc"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Checklistfiledeliveredtoc"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns[@"" + dgrid_main_col.ToString() + " Checklistfiledeliveredtoc"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                    }
                }
                /// FOR TIER 2 BELOW
                else
                {
                    if (Myrow.Cells["P Showstopper Qc"].Value.ToString() == "")
                    { }
                    else
                    {
                        mydate = Myrow.Cells["P Showstopper Qc"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Showstopper Qc";
                        p_actual = Myrow.Cells["P Showstopper Qc"].Value.ToString();
                        actual = Myrow.Cells["Act Showstopper Qc"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Showstopper Qc"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Showstopper Qc"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Showstopper Qc"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Showstopper Qc"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Showstopper Qc"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Showstopper Qc"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Showstopper Qc"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
            }
        }
        public void Check_ContentSignOff_Date()
        {

            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Tmpl Template Description"].Value.ToString().Contains("Electronic"))
                { }
                else
                {
                    if (Myrow.Cells["P Content Sign Off"].Value.ToString() == "")
                    {
                        if (Myrow.Cells["Org Content Sign Off"].Value.ToString() == "") { }
                        else
                        {
                            mydate = Myrow.Cells["Org Content Sign Off"].Value.ToString();

                            pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                            relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                            ops = Myrow.Cells["POC Name"].Value.ToString();
                            eds = Myrow.Cells["SEC Name"].Value.ToString();
                            milestone = "Content Sign Off";
                            p_actual = Myrow.Cells["Org Content Sign Off"].Value.ToString();
                            actual = Myrow.Cells["Act Content Sign Off"].Value.ToString();
                            act_comment = Myrow.Cells["Comm Content Sign Off"].Value.ToString();

                            if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Content Sign Off"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Content Sign Off"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                                dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Content Sign Off"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Content Sign Off"].Index].Style.BackColor = Color.Yellow;
                                dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Content Sign Off"].Value.ToString() == "")
                            {
                                Myrow.Cells[dgridmain.Columns["Org Content Sign Off"].Index].Style.BackColor = Color.Red;
                                dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                            }
                            else { }
                        }
                    }
                    else
                    {
                        mydate = Myrow.Cells["P Content Sign Off"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Content Sign Off";
                        p_actual = Myrow.Cells["P Content Sign Off"].Value.ToString();
                        actual = Myrow.Cells["Act Content Sign Off"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Content Sign Off"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Content Sign Off"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Content Sign Off"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Content Sign Off"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Content Sign Off"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Content Sign Off"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Content Sign Off"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
            }
        }

        public void Check_Checkpointing_Complete()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {

                if (Myrow.Cells["Tmpl Template Description"].Value.ToString().Contains("Electronic"))
                { }
                else
                {
                    if (Myrow.Cells["P Checkpointing Complete"].Value.ToString() == "")
                    { }
                    else
                    {
                        mydate = Myrow.Cells["P Checkpointing Complete"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Checkpointing Complete";
                        p_actual = Myrow.Cells["P Checkpointing Complete"].Value.ToString();
                        actual = Myrow.Cells["Act Checkpointing Complete"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Checkpointing Complete"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Checkpointing Complete"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Checkpointing Complete"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                         else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Checkpointing Complete"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Checkpointing Complete"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Checkpointing Complete"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Checkpointing Complete"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else { }
                    }
                }
            }
        }
        public void Check_Clear_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Clear"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Clear"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Clear";
                    p_actual = Myrow.Cells["P Clear"].Value.ToString();
                    actual = Myrow.Cells["Act Clear"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Clear"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Clear"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Clear"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Clear"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Clear"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Clear"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Clear"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }
        public void Check_Promote_Date()
        {

            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["Tmpl Template Description"].Value.ToString().Contains("Electronic"))
                { }
                else
                {
                    if (Myrow.Cells["P Promote"].Value.ToString() == "")
                    { }
                    else
                    {
                        mydate = Myrow.Cells["P Promote"].Value.ToString();

                        pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                        relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                        ops = Myrow.Cells["POC Name"].Value.ToString();
                        eds = Myrow.Cells["SEC Name"].Value.ToString();
                        milestone = "Promote";
                        p_actual = Myrow.Cells["P Promote"].Value.ToString();
                        actual = Myrow.Cells["Act Promote"].Value.ToString();
                        act_comment = Myrow.Cells["Comm Promote"].Value.ToString();

                        if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Promote"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Promote"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                            dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) <= DateTime.Now.AddDays(7) && Myrow.Cells["Act Promote"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Promote"].Index].Style.BackColor = Color.Yellow;
                            dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                        else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Promote"].Value.ToString() == "")
                        {
                            Myrow.Cells[dgridmain.Columns["P Promote"].Index].Style.BackColor = Color.Red;
                            dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                        }
                    }
                }
            }
        }

        public void Check_Lexis_Com_Live_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Lexis#Com Live"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Lexis#Com Live"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Lexis.Com Live";
                    p_actual = Myrow.Cells["P Lexis#Com Live"].Value.ToString();
                    actual = Myrow.Cells["Act Lexis#Com Live"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Lexis#Com Live"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Lexis#Com Live"].Value.ToString() == "" && Myrow.Cells["Lexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis#Com Live"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Lexis#Com Live"].Value.ToString() == ""  && Myrow.Cells["Lexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis#Com Live"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Lexis#Com Live"].Value.ToString() == "" && Myrow.Cells["Comm Lexis Qc Checklist"].Value.ToString() == "" && Myrow.Cells["Act Lexis Qc Checklist"].Value.ToString() != "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis#Com Live"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }
        public void Check_LexisQC_Checklist_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Lexis Qc Checklist"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Lexis Qc Checklist"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Lexis Qc Checklist";
                    p_actual = Myrow.Cells["P Lexis Qc Checklist"].Value.ToString();
                    actual = Myrow.Cells["Act Lexis Qc Checklist"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Lexis Qc Checklist"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Lexis Qc Checklist"].Value.ToString() == "" && Myrow.Cells["Lexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis Qc Checklist"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Lexis Qc Checklist"].Value.ToString() == "" && Myrow.Cells["Lexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis Qc Checklist"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Lexis Qc Checklist"].Value.ToString() == "" && Myrow.Cells["Lexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis Qc Checklist"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }

        public void Check_LA_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Lexis Advance Live"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Lexis Advance Live"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Lexis Advance Live";
                    p_actual = Myrow.Cells["P Lexis Advance Live"].Value.ToString();
                    actual = Myrow.Cells["Act Lexis Advance Live"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Lexis Advance Live"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Lexis Advance Live"].Value.ToString() == "" && Myrow.Cells["Newlexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis Advance Live"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Lexis Advance Live"].Value.ToString() == "" && Myrow.Cells["Newlexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis Advance Live"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Lexis Advance Live"].Value.ToString() == "" && Myrow.Cells["Newlexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis Advance Live"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }
        public void Check_LAQC_Checklist_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Lexis Adv Qc Checklist"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Lexis Adv Qc Checklist"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Lexis Advance QC Checklist";
                    p_actual = Myrow.Cells["P Lexis Adv Qc Checklist"].Value.ToString();
                    actual = Myrow.Cells["Act Lexis Adv Qc Checklist"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Lexis Adv Qc Checklist"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Lexis Adv Qc Checklist"].Value.ToString() == "" && Myrow.Cells["Newlexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis Adv Qc Checklist"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Lexis Adv Qc Checklist"].Value.ToString() == "" && Myrow.Cells["Newlexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis Adv Qc Checklist"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Lexis Adv Qc Checklist"].Value.ToString() == "" && Myrow.Cells["Newlexis Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Lexis Adv Qc Checklist"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }

        public void Check_Infobase_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Infobase Qc"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Infobase Qc"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Infobase QC";
                    p_actual = Myrow.Cells["P Infobase Qc"].Value.ToString();
                    actual = Myrow.Cells["Act Infobase Qc"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Infobase Qc"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Infobase Qc"].Value.ToString() == "" && Myrow.Cells["Cd Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Infobase Qc"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Infobase Qc"].Value.ToString() == "" && Myrow.Cells["Cd Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Infobase Qc"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Infobase Qc"].Value.ToString() == "" && Myrow.Cells["Cd Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Infobase Qc"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }
        public void Check_InfobaseQC_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Infobase 4xgold"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Infobase 4xgold"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Infobase 4xgold";
                    p_actual = Myrow.Cells["P Infobase 4xgold"].Value.ToString();
                    actual = Myrow.Cells["Act Infobase 4xgold"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Infobase 4xgold"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Infobase 4xgold"].Value.ToString() == "" && Myrow.Cells["Cd Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Infobase 4xgold"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Infobase 4xgold"].Value.ToString() == "" && Myrow.Cells["Cd Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Infobase 4xgold"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Infobase 4xgold"].Value.ToString() == "" && Myrow.Cells["Cd Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Infobase 4xgold"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }
        public void Check_InfobaseQC_Checklist_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Infobase Qc Checklist"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Infobase Qc Checklist"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Infobase QC Checklist";
                    p_actual = Myrow.Cells["P Infobase Qc Checklist"].Value.ToString();
                    actual = Myrow.Cells["Act Infobase Qc Checklist2"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Infobase Qc Checklist"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Infobase Qc Checklist2"].Value.ToString() == "" && Myrow.Cells["Cd Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Infobase Qc Checklist"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Infobase Qc Checklist2"].Value.ToString() == "" && Myrow.Cells["Cd Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Infobase Qc Checklist"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Infobase Qc Checklist2"].Value.ToString() == "" && Myrow.Cells["Cd Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Infobase Qc Checklist"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }

        public void Check_eBook_Conversion_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P E Book Conversion"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P E Book Conversion"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "eBook Conversion";
                    p_actual = Myrow.Cells["P E Book Conversion"].Value.ToString();
                    actual = Myrow.Cells["Act E Book Conversion"].Value.ToString();
                    act_comment = Myrow.Cells["Comm E Book Conversion"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act E Book Conversion"].Value.ToString() == "" && Myrow.Cells["Ebookmb Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P E Book Conversion"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act E Book Conversion"].Value.ToString() == "" && Myrow.Cells["Ebookmb Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P E Book Conversion"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act E Book Conversion"].Value.ToString() == "" && Myrow.Cells["Ebookmb Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P E Book Conversion"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }
        public void Check_eBookQC_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P E Book Qc"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P E Book Qc"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "eBook QC";
                    p_actual = Myrow.Cells["P E Book Qc"].Value.ToString();
                    actual = Myrow.Cells["Act E Book Qc"].Value.ToString();
                    act_comment = Myrow.Cells["Comm E Book Qc"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act E Book Qc"].Value.ToString() == "" && Myrow.Cells["Ebookmb Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P E Book Qc"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act E Book Qc"].Value.ToString() == "" && Myrow.Cells["Ebookmb Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P E Book Qc"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act E Book Qc"].Value.ToString() == "" && Myrow.Cells["Ebookmb Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P E Book Qc"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }
        public void Check_eBookQC_Checklist_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Ebook Qc Checklist"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Ebook Qc Checklist"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "eBook QC Checklist";
                    p_actual = Myrow.Cells["P Ebook Qc Checklist"].Value.ToString();
                    actual = Myrow.Cells["Act Ebook Qc Checklist"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Ebook Qc Checklist"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Ebook Qc Checklist"].Value.ToString() == "" && Myrow.Cells["Ebookmb Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Ebook Qc Checklist"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Ebook Qc Checklist"].Value.ToString() == "" && Myrow.Cells["Ebookmb Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Ebook Qc Checklist"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Ebook Qc Checklist"].Value.ToString() == "" && Myrow.Cells["Ebookmb Del Method"].Value.ToString() == "Y")
                    {
                        Myrow.Cells[dgridmain.Columns["P Ebook Qc Checklist"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }

        public void Check_FinalPassComp_Date()
        {
            string mydate;
            string pubnum, relnum, ops, eds, milestone, p_actual, actual, act_comment;
            foreach (DataGridViewRow Myrow in dgridmain.Rows)
            {
                if (Myrow.Cells["P Final Pass Comp"].Value.ToString() == "")
                { }
                else
                {
                    mydate = Myrow.Cells["P Final Pass Comp"].Value.ToString();

                    pubnum = Myrow.Cells["Pub Pub Number"].Value.ToString();
                    relnum = Myrow.Cells["Rel Release Number"].Value.ToString();
                    ops = Myrow.Cells["POC Name"].Value.ToString();
                    eds = Myrow.Cells["SEC Name"].Value.ToString();
                    milestone = "Final Pass Composition";
                    p_actual = Myrow.Cells["P Final Pass Comp"].Value.ToString();
                    actual = Myrow.Cells["Act Final Pass Comp"].Value.ToString();
                    act_comment = Myrow.Cells["Comm Final Pass Comp"].Value.ToString();

                    if (Convert.ToDateTime(mydate).ToString("MM/dd/yyyy") == DateTime.Now.ToString("MM/dd/yyyy") && Myrow.Cells["Act Final Pass Comp"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Final Pass Comp"].Index].Style.BackColor = Color.LightGreen; // -1 cell index
                        dgridtoday.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                     else if (Convert.ToDateTime(mydate) > DateTime.Now && Convert.ToDateTime(mydate) < DateTime.Now.AddDays(7) && Myrow.Cells["Act Final Pass Comp"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Final Pass Comp"].Index].Style.BackColor = Color.Yellow;
                        dgridweek.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else if (DateTime.Now > Convert.ToDateTime(mydate) && Myrow.Cells["Act Final Pass Comp"].Value.ToString() == "")
                    {
                        Myrow.Cells[dgridmain.Columns["P Final Pass Comp"].Index].Style.BackColor = Color.Red;
                        dgridpast.Rows.Add(pubnum, relnum.ToString(), ops, eds, milestone, p_actual, actual, act_comment);
                    }
                    else { }
                }
            }
        }

        private void btnexportdates_Click(object sender, EventArgs e)
        {
            export_rep();
        }

        public void export_rep()
        {
            try
            {
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                app.Visible = false;
                worksheet = workbook.Sheets["Sheet1"];

                //worksheet = workbook.ActiveSheet;
                worksheet.Name = "Pub Status" + "_" + DateTime.Now.ToString("MM_dd_yyyy");

                try
                {
                    for (int i = 0; i < dgridpast.Columns.Count; i++)
                    {
                        worksheet.Cells[1, i + 1] = dgridpast.Columns[i].HeaderText;
                        //worksheet.Cells[1, i + 1].Borders.Color = Color.Black;
                    }
                    for (int i = 0; i < dgridpast.Rows.Count; i++)
                    {
                        for (int j = 0; j < dgridpast.Columns.Count; j++)
                        {
                            if (dgridpast.Rows[i].Cells[j].Value != null)// && dgridpast.Rows[i].Cells[7].Value.ToString() == "")
                            {
                                worksheet.Cells[i + 2, j + 1] = dgridpast.Rows[i].Cells[j].Value.ToString();
                                worksheet.Cells[i + 2, j + 1].Interior.Color = dgridpast.Rows[i].Cells[j].Style.BackColor;
                                worksheet.Cells[i + 2, j + 1].Borders.Color = Color.Black;
                            }
                            else
                            {
                                worksheet.Cells[i + 2, j + 1] = "";
                                //worksheet.Cells[i + 2, j + 1].Borders.Color = Color.Black;
                                //worksheet.Cells[i + 2, j + 1].Interior.Color = Color.Red;
                            }
                        }
                    }

                    /// FOR DUE TODAY
                    Excel.Range last = worksheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                    Excel.Range range = worksheet.get_Range("A1", last);
                    int lastUsedRow = last.Row;
                    int lastUsedColumn = last.Column;
                    
                    int for_today = 1;
                    int for_today_col = 1;
                    for (int i = 0; i < dgridtoday.Rows.Count; i++)
                    {
                        for (int j = 0; j < dgridtoday.Columns.Count; j++)
                        {
                            if (dgridtoday.Rows[i].Cells[j].Value != null)
                            {
                                worksheet.Cells[lastUsedRow + for_today, j + for_today_col] = dgridtoday.Rows[i].Cells[j].Value.ToString();
                                worksheet.Cells[lastUsedRow + for_today, j + for_today_col].Interior.Color = dgridtoday.Rows[i].Cells[j].Style.BackColor;
                                worksheet.Cells[lastUsedRow + for_today, j + for_today_col].Borders.Color = Color.Black;
                            }
                            else
                            {
                                worksheet.Cells[lastUsedRow + for_today, j + 1] = "";
                            }
                        }
                        for_today = for_today + 1;
                    }

                    /// FOR UPCOMING
                    Excel.Range last1 = worksheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                    Excel.Range range1 = worksheet.get_Range("A1", last1);
                    int lastUsedRow1 = last1.Row;
                    int lastUsedColumn1 = last1.Column;

                    int for_today1 = 1;
                    int for_today_col1 = 1;
                    for (int i = 0; i < dgridweek.Rows.Count; i++)
                    {
                        for (int j = 0; j < dgridweek.Columns.Count; j++)
                        {
                            if (dgridweek.Rows[i].Cells[j].Value != null)
                            {
                                worksheet.Cells[lastUsedRow1 + for_today1, j + for_today_col1] = dgridweek.Rows[i].Cells[j].Value.ToString();
                                worksheet.Cells[lastUsedRow1 + for_today1, j + for_today_col1].Interior.Color = dgridweek.Rows[i].Cells[j].Style.BackColor;
                                worksheet.Cells[lastUsedRow1 + for_today1, j + for_today_col1].Borders.Color = Color.Black;
                            }
                            else
                            {
                                worksheet.Cells[lastUsedRow1 + for_today1, j + 1] = "";
                            }
                        }
                        for_today1 = for_today1 + 1;
                    }



                    /// Excel Footer Data

                    /**if (lblsched == "fromshowstopper")
                    {

                        Excel.Range last = worksheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                        Excel.Range range = worksheet.get_Range("A1", last);
                        int lastUsedRow = last.Row;
                        int lastUsedColumn = last.Column;

                        worksheet.Cells[lastUsedRow + 2, 1] = "Total Showstopper QC:";
                        worksheet.Cells[lastUsedRow + 2, 2] = dgridpast.Rows.Count.ToString();

                        worksheet.Cells[lastUsedRow + 4, 1] = "---Showstopper QC Rating---";
                        worksheet.Cells[lastUsedRow + 5, 1] = "GO Rating:";
                        worksheet.Cells[lastUsedRow + 5, 2] = lblgo.Text;

                        worksheet.Cells[lastUsedRow + 6, 1] = "GO Recomp/Minor/New Rating: ";
                        worksheet.Cells[lastUsedRow + 6, 2] = lblminor.Text;

                        worksheet.Cells[lastUsedRow + 7, 1] = "GO Recomp/Moderate/New Rating:";
                        worksheet.Cells[lastUsedRow + 7, 2] = lblmoderate.Text;

                        worksheet.Cells[lastUsedRow + 8, 1] = "NO GO Rating:";
                        worksheet.Cells[lastUsedRow + 8, 2] = lblnogo.Text;

                        worksheet.Cells[lastUsedRow + 10, 1] = "---Level of Guidance---";
                        worksheet.Cells[lastUsedRow + 11, 1] = "A Rating:";
                        worksheet.Cells[lastUsedRow + 11, 2] = lbllevela.Text;

                        worksheet.Cells[lastUsedRow + 12, 1] = "B Rating:";
                        worksheet.Cells[lastUsedRow + 12, 2] = lbllevelb.Text;

                        worksheet.Cells[lastUsedRow + 14, 1] = "---Author Review---";
                        worksheet.Cells[lastUsedRow + 15, 1] = "A Rating:";
                        worksheet.Cells[lastUsedRow + 15, 2] = lblauta.Text;

                        worksheet.Cells[lastUsedRow + 16, 1] = "B Rating:";
                        worksheet.Cells[lastUsedRow + 16, 2] = lblautb.Text;
                    }
                    ***/

                    worksheet.Rows.AutoFit();
                    worksheet.Columns.AutoFit();

                    //Getting the location and file name of the excel to save from user. 
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx";
                    saveDialog.FilterIndex = 2;
                    //saveDialog.FileName = "Result_Sample";
                    saveDialog.FileName = "Daily Status_" + DateTime.Now.ToString("MM_dd_yyyy");
                    if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        workbook.SaveAs(saveDialog.FileName);
                        MessageBox.Show("Export Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                finally
                {
                    app.Quit();
                    workbook = null;
                    worksheet = null;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString()); } 

        }

        private void btncreatedb_Click(object sender, EventArgs e)
        {
            MessageBox.Show(dtpickerend.Value.ToString("MM/dd/yyyy"));
        }

        private void btnreload_Click(object sender, EventArgs e)
        {
            Filter_by_CPO();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void dtpickerend_ValueChanged(object sender, EventArgs e)
        {
            lblend.Text = dtpickerend.Value.ToString("MM/dd/yyyy");
        }
        private void dtpickerstart_ValueChanged(object sender, EventArgs e)
        {
            lblstart.Text = dtpickerstart.Value.ToString("MM/dd/yyyy");

            dtpickerend.MaxDate = dtpickerstart.Value.AddMonths(9);
            dtpickerend.MinDate = dtpickerstart.Value;

            dtpickerend.Value = dtpickerstart.Value.AddMonths(9);
        }

        public void Virtual_Online_Expected_Date()
        {
            dgridonlineprod.DataSource = null;
            string pathName = txtbrowse.Text;
            string fileName = System.IO.Path.GetFileNameWithoutExtension(txtbrowse.Text);
            DataTable tbContainer = new DataTable();
            string strConn = string.Empty;
            string sheetName = fileName;
            strConn = @"Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + pathName + ";" + "Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\"";

            OleDbConnection cnnxls = new OleDbConnection(strConn);
            cnnxls.Open();
            DataTable dtsheet = new DataTable();
            dtsheet = cnnxls.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            string ExcelSheetName = dtsheet.Rows[0]["Table_Name"].ToString();    //get First Excel Sheet Name

            if (cmbonlinecpo.SelectedItem.ToString() == "ALL CPO")
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("Select [Pub Pub Number], [Rel Release Number], [Poc Name], [Sec Name], [Tity Tier Type], [Tmpl Template Description], [Cpo Name], [Ebookmb Del Method], [Cd Del Method], [Lexis Del Method], [Newlexis Del Method], " +
                    "[P Checkpointing Complete], [Act Checkpointing Complete], [Comm Checkpointing Complete] FROM [" + ExcelSheetName.Trim('\'') + "] " +
                    "WHERE FORMAT([Act Checkpointing Complete], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to ", sheetName), cnnxls); //AND YEAR([P Checkpointing Complete]) = '" + dtponlinestart.Value.ToString("yyyy") + "'", sheetName), cnnxls);
                oda123.SelectCommand.Parameters.AddWithValue("@from", dtponlinestart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.SelectCommand.Parameters.AddWithValue("@to", dtponlineend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }
            else if (cmbonlinecpo.SelectedItem.ToString() == "Manila Team Only")
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("Select [Pub Pub Number], [Rel Release Number], [Poc Name], [Sec Name], [Tity Tier Type], [Tmpl Template Description], [Cpo Name], [Ebookmb Del Method], [Cd Del Method], [Lexis Del Method], [Newlexis Del Method], " +
                    "[P Checkpointing Complete], [Act Checkpointing Complete], [Comm Checkpointing Complete] FROM [" + ExcelSheetName.Trim('\'') + "] " +
                    "WHERE ([CPO Name] = 'Aquino,Sheila' OR [CPO Name] = 'Ampongan,Yudz Bellen' OR [CPO Name] = 'Dino,Jon Frederick Barazon' OR [CPO Name] = 'Manipon,Dada Apilada') AND (FORMAT([Act Checkpointing Complete], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to) ", sheetName), cnnxls);  //AND YEAR([P Checkpointing Complete]) =  " + dtponlinestart.Value.ToString("yyyy") + " ", sheetName), cnnxls);
                oda123.SelectCommand.Parameters.AddWithValue("@from", dtponlinestart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.SelectCommand.Parameters.AddWithValue("@to", dtponlineend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }
            else if (cmbonlinecpo.SelectedItem.ToString() == "Iloilo Team Only")
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("Select [Pub Pub Number], [Rel Release Number], [Poc Name], [Sec Name], [Tity Tier Type], [Tmpl Template Description], [Cpo Name], [Ebookmb Del Method], [Cd Del Method], [Lexis Del Method], [Newlexis Del Method], " +
                    "[P Checkpointing Complete], [Act Checkpointing Complete], [Comm Checkpointing Complete] FROM [" + ExcelSheetName.Trim('\'') + "] " +
                    "WHERE ([CPO Name] = 'Lomigo,Paul Anthony Villeza' OR [CPO Name] = 'Arsenal,Tim Ryan Arroyo' OR [CPO Name] = 'Sumpay,Lirie John Paran')  AND (FORMAT([Act Checkpointing Complete], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to OR FORMAT([Act Checkpointing Complete], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to) ", sheetName), cnnxls); //AND YEAR([P Checkpointing Complete]) =  " + dtponlinestart.Value.ToString("yyyy") + " ", sheetName), cnnxls);
                oda123.SelectCommand.Parameters.AddWithValue("@from", dtponlinestart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.SelectCommand.Parameters.AddWithValue("@to", dtponlineend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }
            else
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("Select [Pub Pub Number], [Rel Release Number], [Poc Name], [Sec Name], [Tity Tier Type], [Tmpl Template Description], [Cpo Name], [Ebookmb Del Method], [Cd Del Method], [Lexis Del Method], [Newlexis Del Method], " +
                    "[P Checkpointing Complete], [Act Checkpointing Complete], [Comm Checkpointing Complete] FROM [" + ExcelSheetName.Trim('\'') + "] " +
                    "WHERE [CPO Name] = '" + cmbonlinecpo.SelectedItem.ToString() + "'  AND (FORMAT([Act Checkpointing Complete], 'MM/dd/yyyy hh:mm:ss') BETWEEN @from AND @to ) ", sheetName), cnnxls); //AND YEAR([P Checkpointing Complete]) =  " + dtponlinestart.Value.ToString("yyyy") + " ", sheetName), cnnxls);
                oda123.SelectCommand.Parameters.AddWithValue("@from", dtponlinestart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.SelectCommand.Parameters.AddWithValue("@to", dtponlineend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }

            dgridonlineprod.DataSource = tbContainer;
            lblonlinecount.Text = "0";
            lblonlinecount.Text = dgridonlineprod.Rows.Count.ToString();

            foreach (DataGridViewColumn dgcol in dgridonlineprod.Columns)
            {
                dgcol.SortMode = DataGridViewColumnSortMode.NotSortable;
                dgcol.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            }
            cnnxls.Close();
            MessageBox.Show("OBIEE Report has been sucessfully loaded", "OBIEE Loaded", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void btncheckonline_Click(object sender, EventArgs e)
        {
            Virtual_Online_Expected_Date();
        }

        private void dtponlinestart_ValueChanged(object sender, EventArgs e)
        {
            dtponlineend.MaxDate = dtponlinestart.Value.AddMonths(1);
            dtponlineend.MinDate = dtponlinestart.Value;

            dtponlineend.Value = dtponlinestart.Value.AddMonths(1);
        }
        private void cmbcpo_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void btnnewsched_Click(object sender, EventArgs e)
        {

        }

        public void Print_ECOMP_Checklist()
        {
            dgvpo.DataSource = null;
            string pathName = txtbrowse.Text;
            string fileName = System.IO.Path.GetFileNameWithoutExtension(txtbrowse.Text);
            DataTable tbContainer = new DataTable();
            string strConn = string.Empty;
            string sheetName = fileName;
            strConn = @"Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + pathName + ";" + "Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\"";

            OleDbConnection cnnxls = new OleDbConnection(strConn);
            cnnxls.Open();
            DataTable dtsheet = new DataTable();
            dtsheet = cnnxls.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            string ExcelSheetName = dtsheet.Rows[0]["Table_Name"].ToString();    //get First Excel Sheet Name

            if (cmbchecklistcpo.SelectedItem.ToString() == "ALL CPO")
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("Select [Pub Pub Number], [Rel Release Number], [Poc Name], [Sec Name], [Tity Tier Type], [Tmpl Template Description], [Cpo Name] " +
                    " FROM [" + ExcelSheetName.Trim('\'') + "] " +
                    " ORDER BY [Pub Pub Number] ", sheetName), cnnxls); //AND YEAR([P Checkpointing Complete]) = '" + dtponlinestart.Value.ToString("yyyy") + "'", sheetName), cnnxls);
                //oda123.SelectCommand.Parameters.AddWithValue("@from", dtponlinestart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                //oda123.SelectCommand.Parameters.AddWithValue("@to", dtponlineend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }
            else if (cmbchecklistcpo.SelectedItem.ToString() == "Manila Team Only")
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("Select [Pub Pub Number], [Rel Release Number], [Poc Name], [Sec Name], [Tity Tier Type], [Tmpl Template Description], [Cpo Name] " +
                    " FROM [" + ExcelSheetName.Trim('\'') + "] " +
                    "WHERE ([CPO Name] = 'Aquino,Sheila' OR [CPO Name] = 'Ampongan,Yudz Bellen' OR [CPO Name] = 'Dino,Jon Frederick Barazon' OR [CPO Name] = 'Manipon,Dada Apilada') ", sheetName), cnnxls);  //AND YEAR([P Checkpointing Complete]) =  " + dtponlinestart.Value.ToString("yyyy") + " ", sheetName), cnnxls);
                //oda123.SelectCommand.Parameters.AddWithValue("@from", dtponlinestart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                //oda123.SelectCommand.Parameters.AddWithValue("@to", dtponlineend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }
            else if (cmbchecklistcpo.SelectedItem.ToString() == "Iloilo Team Only")
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("Select [Pub Pub Number], [Rel Release Number], [Poc Name], [Sec Name], [Tity Tier Type], [Tmpl Template Description], [Cpo Name] " +
                    " FROM [" + ExcelSheetName.Trim('\'') + "] " +
                    "WHERE ([CPO Name] = 'Lomigo,Paul Anthony Villeza' OR [CPO Name] = 'Arsenal,Tim Ryan Arroyo' OR [CPO Name] = 'Sumpay,Lirie John Paran') ", sheetName), cnnxls); //AND YEAR([P Checkpointing Complete]) =  " + dtponlinestart.Value.ToString("yyyy") + " ", sheetName), cnnxls);
                //oda123.SelectCommand.Parameters.AddWithValue("@from", dtponlinestart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                //oda123.SelectCommand.Parameters.AddWithValue("@to", dtponlineend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }
            else
            {
                OleDbDataAdapter oda123 = new OleDbDataAdapter(string.Format("Select [Pub Pub Number], [Rel Release Number], [Poc Name], [Sec Name], [Tity Tier Type], [Tmpl Template Description], [Cpo Name] " +
                    " FROM [" + ExcelSheetName.Trim('\'') + "] " +
                    "WHERE [CPO Name] = '" + cmbchecklistcpo.SelectedItem.ToString() + "' ", sheetName), cnnxls); //AND YEAR([P Checkpointing Complete]) =  " + dtponlinestart.Value.ToString("yyyy") + " ", sheetName), cnnxls);
                //oda123.SelectCommand.Parameters.AddWithValue("@from", dtponlinestart.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                //oda123.SelectCommand.Parameters.AddWithValue("@to", dtponlineend.Value.ToString("MM/dd/yyyy hh:mm:ss"));
                oda123.Fill(tbContainer);
                tbContainer.AcceptChanges();
            }

            dgvpo.DataSource = tbContainer;
            lblpocount.Text = "0";
            lblpocount.Text = dgvpo.Rows.Count.ToString();

            foreach (DataGridViewColumn dgcol in dgvpo.Columns)
            {
                dgcol.SortMode = DataGridViewColumnSortMode.NotSortable;
                dgcol.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            }
            cnnxls.Close();
            //MessageBox.Show("OBIEE Report has been sucessfully loaded", "OBIEE Loaded", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public void Connect_to_QTT()
        {
            //try
            //{
            OpenFileDialog openFileDialog1 = new OpenFileDialog();  //create openfileDialog Object
                                                                    //openFileDialog1.Filter = "Excel Files (*.xls; *.xlsx|*.xls; *.xlsx";//open file format define Excel Files(.xls)|*.xls| Excel Files(.xlsx)|*.xlsx| 
            openFileDialog1.Filter = "Excel Files (*.xlsx|*.xlsx";//open file format define Excel Files(.xls)|*.xls| Excel Files(.xlsx)|*.xlsx| 
            openFileDialog1.FilterIndex = 3;
            openFileDialog1.FilterIndex = 3;

            openFileDialog1.Multiselect = false;        //not allow multiline selection at the file selection level
            openFileDialog1.Title = "Open QTT Exported Results";   //define the name of openfileDialog
            openFileDialog1.InitialDirectory = @"Desktop"; //define the initial directory

            if (openFileDialog1.ShowDialog() == DialogResult.OK)        //executing when file open
            {

                dgvecompcheck.DataSource = null;
                dgvecompcheck.Rows.Clear();

                string pathName = openFileDialog1.FileName;
                string fileName = System.IO.Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
                DataTable tbContainer = new DataTable();
                string strConn = string.Empty;
                string sheetName = fileName;

                FileInfo file = new FileInfo(pathName);
                if (!file.Exists) { throw new Exception("Error, file doesn't exists!"); }
                string extension = file.Extension;
                switch (extension)
                {
                    case ".xls":
                        strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                        //strConn = @"Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + pathName + ";" + "Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\"";

                        //strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + pathName + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
                        break;
                    case ".xlsx":
                        //strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + pathName + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
                        strConn = @"Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + pathName + ";" + "Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\"";
                        break;
                    default:
                        strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                        break;
                }

                txtbrowse.Text = pathName.ToString();

                OleDbConnection cnnxls = new OleDbConnection(strConn);
                cnnxls.Open();
                DataTable dtsheet = new DataTable();
                dtsheet = cnnxls.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                string ExcelSheetName = dtsheet.Rows[0]["Table_Name"].ToString();    //get First Excel Sheet Name

                OleDbDataAdapter oda = new OleDbDataAdapter(string.Format("select [Engagement], [Job No], [Supplier], [Pub No], [Release No], [Pub Owner], [QC Date (LN)], " +
                " [Supplier QC / Dispatch Date], [Date Modified], [Form Type], [Form Status] " +
                " from [" + ExcelSheetName.Trim('\'') + "] ORDER BY [Supplier QC / Dispatch Date]", sheetName), cnnxls); //AND YEAR([P Author]) =  " + dtpickerstart.Value.ToString("yyyy") + " 
                                                                                                                                                                                           //oda.SelectCommand.Parameters.AddWithValue("@from", dtpickerstart.Value.ToString("MM/dd/yyyy"));
                                                                                                                                                                                           //oda.SelectCommand.Parameters.AddWithValue("@to", dtpickerend.Value.AddMonths(12).ToString("MM/dd/yyyy"));
                //oda.SelectCommand.Parameters.Add("@from", OleDbType.Date).Value = dtpickerstart.Value.ToString("MM/dd/yyyy hh:mm:ss");
                //oda.SelectCommand.Parameters.Add("@to", OleDbType.Date).Value = dtpickerend.Value.ToString("MM/dd/yyyy hh:mm:ss");
                oda.Fill(tbContainer);
                tbContainer.AcceptChanges();

                dgvecompcheck.DataSource = tbContainer;
                lblchecklistcount.Text = dgvecompcheck.Rows.Count.ToString();

                cnnxls.Close();
                MessageBox.Show("QTT Data has been loaded", "QTT Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            //}
            //catch (Exception)
            //{
            //    MessageBox.Show("Unable to load excel file. Please select file with .xlsx only", "Unable to load", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}'
        }
        public void export_QTT_PO()
        {
            try
            {
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                app.Visible = false;
                worksheet = workbook.Sheets["Sheet1"];

                //worksheet = workbook.ActiveSheet;
                worksheet.Name = "QTT Checklist" + "_" + DateTime.Now.ToString("MM_dd_yyyy");

                try
                {
                    for (int i = 0; i < dgvecompcheck.Columns.Count; i++)
                    {
                        worksheet.Cells[1, i + 1] = dgvecompcheck.Columns[i].HeaderText;
                        //worksheet.Cells[1, i + 1].Borders.Color = Color.Black;
                    }
                    for (int i = 0; i < dgvecompcheck.Rows.Count; i++)
                    {
                        for (int j = 0; j < dgvecompcheck.Columns.Count; j++)
                        {
                            if (dgvecompcheck.Rows[i].Cells[j].Value != null)// && dgvecompcheck.Rows[i].Cells[7].Value.ToString() == "")
                            {
                                worksheet.Cells[i + 2, j + 1] = dgvecompcheck.Rows[i].Cells[j].Value.ToString();
                                worksheet.Cells[i + 2, j + 1].Interior.Color = dgvecompcheck.Rows[i].Cells[j].Style.BackColor;
                                worksheet.Cells[i + 2, j + 1].Borders.Color = Color.Black;
                            }
                            else
                            {
                                worksheet.Cells[i + 2, j + 1] = "";
                                //worksheet.Cells[i + 2, j + 1].Borders.Color = Color.Black;
                                //worksheet.Cells[i + 2, j + 1].Interior.Color = Color.Red;
                            }
                        }
                    }

                    /// Excel Footer Data

                    /**if (lblsched == "fromshowstopper")
                    {

                        Excel.Range last = worksheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                        Excel.Range range = worksheet.get_Range("A1", last);
                        int lastUsedRow = last.Row;
                        int lastUsedColumn = last.Column;

                        worksheet.Cells[lastUsedRow + 2, 1] = "Total Showstopper QC:";
                        worksheet.Cells[lastUsedRow + 2, 2] = dgvecompcheck.Rows.Count.ToString();

                        worksheet.Cells[lastUsedRow + 4, 1] = "---Showstopper QC Rating---";
                        worksheet.Cells[lastUsedRow + 5, 1] = "GO Rating:";
                        worksheet.Cells[lastUsedRow + 5, 2] = lblgo.Text;

                        worksheet.Cells[lastUsedRow + 6, 1] = "GO Recomp/Minor/New Rating: ";
                        worksheet.Cells[lastUsedRow + 6, 2] = lblminor.Text;

                        worksheet.Cells[lastUsedRow + 7, 1] = "GO Recomp/Moderate/New Rating:";
                        worksheet.Cells[lastUsedRow + 7, 2] = lblmoderate.Text;

                        worksheet.Cells[lastUsedRow + 8, 1] = "NO GO Rating:";
                        worksheet.Cells[lastUsedRow + 8, 2] = lblnogo.Text;

                        worksheet.Cells[lastUsedRow + 10, 1] = "---Level of Guidance---";
                        worksheet.Cells[lastUsedRow + 11, 1] = "A Rating:";
                        worksheet.Cells[lastUsedRow + 11, 2] = lbllevela.Text;

                        worksheet.Cells[lastUsedRow + 12, 1] = "B Rating:";
                        worksheet.Cells[lastUsedRow + 12, 2] = lbllevelb.Text;

                        worksheet.Cells[lastUsedRow + 14, 1] = "---Author Review---";
                        worksheet.Cells[lastUsedRow + 15, 1] = "A Rating:";
                        worksheet.Cells[lastUsedRow + 15, 2] = lblauta.Text;

                        worksheet.Cells[lastUsedRow + 16, 1] = "B Rating:";
                        worksheet.Cells[lastUsedRow + 16, 2] = lblautb.Text;
                    }
                    ***/
                    //worksheet.AutoFilterMode = true;
                    worksheet.Rows.AutoFit();
                    worksheet.Columns.AutoFit();

                    //Getting the location and file name of the excel to save from user. 
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx";
                    saveDialog.FilterIndex = 2;
                    //saveDialog.FileName = "Result_Sample";
                    saveDialog.FileName = "QTT Checklist_" + DateTime.Now.ToString("MM_dd_yyyy");
                    if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        workbook.SaveAs(saveDialog.FileName);
                        MessageBox.Show("Export Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                finally
                {
                    app.Quit();
                    workbook = null;
                    worksheet = null;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString()); }
        }

        private void btngetpo_Click(object sender, EventArgs e)
        {
            //Print_ECOMP_Checklist();
            dgvecompcheck.Columns.Clear();
            Connect_to_QTT();
            dgvecompcheck.Columns.Add("CPO", "CPO");
            dgvecompcheck.Columns.Add("Comment", "Comment");
            //dgvecompcheck.Columns[0].Width = 100;
            dgvecompcheck.Columns[11].Width = 150;
            dgvecompcheck.Columns[12].Width = 250;


            foreach (DataGridViewRow Myrow in dgvecompcheck.Rows)
            {
                //Myrow.DataGridView.GridColor = Color.Black;
                Myrow.Cells[0].Style.BackColor = Color.White;
                Myrow.Cells[1].Style.BackColor = Color.White;
                Myrow.Cells[2].Style.BackColor = Color.White;
                Myrow.Cells[3].Style.BackColor = Color.White;
                Myrow.Cells[4].Style.BackColor = Color.White;
                Myrow.Cells[5].Style.BackColor = Color.White;
                Myrow.Cells[6].Style.BackColor = Color.White;
                Myrow.Cells[7].Style.BackColor = Color.White;
                Myrow.Cells[8].Style.BackColor = Color.White;
                Myrow.Cells[9].Style.BackColor = Color.White;
                Myrow.Cells[10].Style.BackColor = Color.White;
                Myrow.Cells[11].Style.BackColor = Color.White;
                Myrow.Cells[12].Style.BackColor = Color.White;
                //if (Myrow.Cells["Actual"].Value.ToString() == "" && Myrow.Cells["Comment"].Value.ToString() == "")
                //{
                //Myrow.Cells[dgridtoday.Columns["Actual"].Index].Style.BackColor = Color.Yellow;
                //Myrow.Cells[dgridtoday.Columns["Comment"].Index].Style.BackColor = Color.Yellow;
                //}
            }

            foreach (DataGridViewColumn dgcol in dgvecompcheck.Columns)
            {
                dgcol.SortMode = DataGridViewColumnSortMode.NotSortable;
                //dgcol.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            }
        }
        private void btnpochecker_Click(object sender, EventArgs e)
        {
            int i;
            foreach(DataGridViewRow po_row in dgvecompcheck.Rows)
            {
                for (i = 0; i < dgvpo.Rows.Count; i++)
                {
                    if (dgvpo.Rows[i].Cells[0].Value.ToString() == po_row.Cells["Pub No"].Value.ToString() && dgvpo.Rows[i].Cells[1].Value.ToString() == po_row.Cells["Release No"].Value.ToString())
                    {
                        po_row.Cells["Pub Owner"].Value = dgvpo.Rows[i].Cells[2].Value.ToString();
                        po_row.Cells["CPO"].Value = dgvpo.Rows[i].Cells["CPO Name"].Value.ToString();
                    }
                }
                if (po_row.Cells["CPO"].Value == null)
                {
                    po_row.Cells["CPO"].Value = " ";
                }
            }

            //CHECK FORM STATUS
            foreach (DataGridViewRow po_row in dgvecompcheck.Rows)
            {
                if (po_row.Cells["Form Status"].Value.ToString() == "Form Submitted (Supplier)")
                {
                    DateTime expected;
                    expected = Convert.ToDateTime(po_row.Cells["Date Modified"].Value).AddDays(2);
                    if (expected.DayOfWeek == DayOfWeek.Saturday)
                    {
                        po_row.Cells["Comment"].Value = "COMPLETION DATE IS: " + Convert.ToDateTime(po_row.Cells["Date Modified"].Value).AddDays(5).ToString("MM/dd/yyyy 8:00") + " AM";
                    }
                    else if (expected.DayOfWeek == DayOfWeek.Sunday)
                    {
                        po_row.Cells["Comment"].Value = "COMPLETION DATE IS: " + Convert.ToDateTime(po_row.Cells["Date Modified"].Value).AddDays(5).ToString("MM/dd/yyyy 8:00") + " AM";
                    }
                    else
                    {
                        if (Convert.ToDateTime(po_row.Cells["Date Modified"].Value).DayOfWeek == DayOfWeek.Wednesday)
                        {
                            po_row.Cells["Comment"].Value = "COMPLETION DATE IS: " + Convert.ToDateTime(po_row.Cells["Date Modified"].Value).AddDays(2).ToString("MM/dd/yyyy 11:59") + " PM";
                        }
                        else
                        {
                            po_row.Cells["Comment"].Value = "COMPLETION DATE IS: " + Convert.ToDateTime(po_row.Cells["Date Modified"].Value).AddDays(3).ToString("MM/dd/yyyy 8:00") + " AM";
                        }
                    }
                }
                else if (po_row.Cells["Form Status"].Value.ToString() == "Submitted To Team Leader" || po_row.Cells["Form Status"].Value.ToString() == "Ready for Supplier Review")
                {
                    if (po_row.Cells["Form Type"].Value.ToString() == "Alpha QC Checklist")
                    {
                        DateTime TL_expected; String two_day_window;
                        TL_expected = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(2);
                        if(TL_expected.DayOfWeek == DayOfWeek.Saturday || TL_expected.DayOfWeek == DayOfWeek.Sunday)
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(5).ToString("MM/dd/yyyy 8:00") + " AM";
                        }
                        else if (TL_expected.DayOfWeek == DayOfWeek.Wednesday)
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(2).ToString("MM/dd/yyyy 11:59") + " PM";
                        }
                        else
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(3).ToString("MM/dd/yyyy 8:00") + " AM";
                        }

                        if (Convert.ToDateTime(po_row.Cells["Date Modified"].Value) > Convert.ToDateTime(two_day_window))
                        {
                            po_row.Cells["Comment"].Value = "LATE";
                            po_row.Cells["Comment"].Style.BackColor = Color.Red;
                        }
                        else
                        {
                            po_row.Cells["Comment"].Value = "ON-TIME";
                        }
                    }
                    else if (po_row.Cells["Form Type"].Value.ToString() == "eBook QC Checklist")
                    {
                        DateTime TL_expected; String two_day_window;
                        TL_expected = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(2);
                        if (TL_expected.DayOfWeek == DayOfWeek.Saturday || TL_expected.DayOfWeek == DayOfWeek.Sunday)
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(5).ToString("MM/dd/yyyy 8:00") + " AM";
                        }
                        else if (TL_expected.DayOfWeek == DayOfWeek.Wednesday)
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(2).ToString("MM/dd/yyyy 11:59") + " PM";
                        }
                        else
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(3).ToString("MM/dd/yyyy 8:00") + " AM";
                        }

                        if (Convert.ToDateTime(po_row.Cells["Date Modified"].Value) > Convert.ToDateTime(two_day_window))
                        {
                            po_row.Cells["Comment"].Value = "LATE";
                            po_row.Cells["Comment"].Style.BackColor = Color.Red;
                        }
                        else
                        {
                            po_row.Cells["Comment"].Value = "ON-TIME";
                        }
                    }
                    else if (po_row.Cells["Form Type"].Value.ToString() == "Lexis Advance Indexing QC Checklist")
                    {
                        DateTime TL_expected; String two_day_window;
                        TL_expected = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(2);
                        if (TL_expected.DayOfWeek == DayOfWeek.Saturday || TL_expected.DayOfWeek == DayOfWeek.Sunday)
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(5).ToString("MM/dd/yyyy 8:00") + " AM";
                        }
                        else if (TL_expected.DayOfWeek == DayOfWeek.Wednesday)
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(2).ToString("MM/dd/yyyy 11:59") + " PM";
                        }
                        else
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(3).ToString("MM/dd/yyyy 8:00") + " AM";
                        }

                        if (Convert.ToDateTime(po_row.Cells["Date Modified"].Value) > Convert.ToDateTime(two_day_window))
                        {
                            po_row.Cells["Comment"].Value = "LATE";
                            po_row.Cells["Comment"].Style.BackColor = Color.Red;
                        }
                        else
                        {
                            po_row.Cells["Comment"].Value = "ON-TIME";
                        }
                    }
                    else if (po_row.Cells["Form Type"].Value.ToString() == "Lexis Advance QC Checklist")
                    {
                        DateTime TL_expected; String two_day_window;
                        TL_expected = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(2);
                        if (TL_expected.DayOfWeek == DayOfWeek.Saturday || TL_expected.DayOfWeek == DayOfWeek.Sunday)
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(5).ToString("MM/dd/yyyy 8:00") + " AM";
                        }
                        else if (TL_expected.DayOfWeek == DayOfWeek.Wednesday)
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(2).ToString("MM/dd/yyyy 11:59") + " PM";
                        }
                        else
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(3).ToString("MM/dd/yyyy 8:00") + " AM";
                        }

                        if (Convert.ToDateTime(po_row.Cells["Date Modified"].Value) > Convert.ToDateTime(two_day_window))
                        {
                            po_row.Cells["Comment"].Value = "LATE";
                            po_row.Cells["Comment"].Style.BackColor = Color.Red;
                        }
                        else
                        {
                            po_row.Cells["Comment"].Value = "ON-TIME";
                        }
                    }
                    else if (po_row.Cells["Form Type"].Value.ToString() == "Online QC Checklist")
                    {
                        DateTime TL_expected; String two_day_window;
                        TL_expected = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(2);
                        if (TL_expected.DayOfWeek == DayOfWeek.Saturday || TL_expected.DayOfWeek == DayOfWeek.Sunday)
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(5).ToString("MM/dd/yyyy 8:00") + " AM";
                        }
                        else if (TL_expected.DayOfWeek == DayOfWeek.Wednesday)
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(2).ToString("MM/dd/yyyy 11:59") + " PM";
                        }
                        else
                        {
                            two_day_window = Convert.ToDateTime(po_row.Cells["Supplier QC / Dispatch Date"].Value).AddDays(3).ToString("MM/dd/yyyy 8:00") + " AM";
                        }

                        if (Convert.ToDateTime(po_row.Cells["Date Modified"].Value) > Convert.ToDateTime(two_day_window))
                        {
                            po_row.Cells["Comment"].Value = "LATE";
                            po_row.Cells["Comment"].Style.BackColor = Color.Red;
                        }
                        else
                        {
                            po_row.Cells["Comment"].Value = "ON-TIME";
                        }
                    }
                }
                else if (po_row.Cells["Form Status"].Value.ToString() == "Submitted to Project Manager")
                {
                    po_row.Cells["Comment"].Value ="";
                }
                //else if (po_row.Cells["Form Status"].Value.ToString() == "Ready for Supplier Review")
                //{
                //    po_row.Cells["Comment"].Value ="";
                //}
            }
            MessageBox.Show("ECOMP QTT Checklist has been verified");

            //dgvecompcheck.Sort(dgvecompcheck.Columns["Pub Owner"], ListSortDirection.Ascending);
            export_QTT_PO();
        }
    }
}

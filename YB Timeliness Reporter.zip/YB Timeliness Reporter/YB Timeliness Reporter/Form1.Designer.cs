﻿namespace YB_Timeliness_Reporter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbrowse = new System.Windows.Forms.Button();
            this.txtbrowse = new System.Windows.Forms.TextBox();
            this.btncreatedb = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabdaily = new System.Windows.Forms.TabPage();
            this.tabposched = new System.Windows.Forms.TabPage();
            this.tabrelsched = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.dgridmain = new System.Windows.Forms.DataGridView();
            this.btnmilestones = new System.Windows.Forms.Button();
            this.dgriddelay = new System.Windows.Forms.DataGridView();
            this.dgridtoday = new System.Windows.Forms.DataGridView();
            this.dgridupcoming = new System.Windows.Forms.DataGridView();
            this.btnexportdates = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lbltotalrow = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabdaily.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgridmain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgriddelay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridtoday)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridupcoming)).BeginInit();
            this.SuspendLayout();
            // 
            // btnbrowse
            // 
            this.btnbrowse.Location = new System.Drawing.Point(12, 12);
            this.btnbrowse.Name = "btnbrowse";
            this.btnbrowse.Size = new System.Drawing.Size(98, 59);
            this.btnbrowse.TabIndex = 0;
            this.btnbrowse.Text = "BROWSE OBIEE REPORT (.xlsx)";
            this.btnbrowse.UseVisualStyleBackColor = true;
            this.btnbrowse.Click += new System.EventHandler(this.btnbrowse_Click);
            // 
            // txtbrowse
            // 
            this.txtbrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbrowse.Location = new System.Drawing.Point(116, 27);
            this.txtbrowse.Name = "txtbrowse";
            this.txtbrowse.Size = new System.Drawing.Size(838, 26);
            this.txtbrowse.TabIndex = 1;
            this.txtbrowse.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btncreatedb
            // 
            this.btncreatedb.Location = new System.Drawing.Point(1142, 12);
            this.btncreatedb.Name = "btncreatedb";
            this.btncreatedb.Size = new System.Drawing.Size(98, 59);
            this.btncreatedb.TabIndex = 2;
            this.btncreatedb.Text = "CREATE LOCAL DATABASE";
            this.btncreatedb.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1031, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "No Local Database?";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabdaily);
            this.tabControl1.Controls.Add(this.tabposched);
            this.tabControl1.Controls.Add(this.tabrelsched);
            this.tabControl1.Location = new System.Drawing.Point(12, 77);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1228, 621);
            this.tabControl1.TabIndex = 4;
            // 
            // tabdaily
            // 
            this.tabdaily.Controls.Add(this.lbltotalrow);
            this.tabdaily.Controls.Add(this.label3);
            this.tabdaily.Controls.Add(this.btnexportdates);
            this.tabdaily.Controls.Add(this.dgridupcoming);
            this.tabdaily.Controls.Add(this.dgridtoday);
            this.tabdaily.Controls.Add(this.dgriddelay);
            this.tabdaily.Controls.Add(this.btnmilestones);
            this.tabdaily.Controls.Add(this.dgridmain);
            this.tabdaily.Controls.Add(this.label2);
            this.tabdaily.Location = new System.Drawing.Point(4, 22);
            this.tabdaily.Name = "tabdaily";
            this.tabdaily.Padding = new System.Windows.Forms.Padding(3);
            this.tabdaily.Size = new System.Drawing.Size(1220, 595);
            this.tabdaily.TabIndex = 0;
            this.tabdaily.Text = "DAILY STATUS REPORT";
            this.tabdaily.UseVisualStyleBackColor = true;
            // 
            // tabposched
            // 
            this.tabposched.Location = new System.Drawing.Point(4, 22);
            this.tabposched.Name = "tabposched";
            this.tabposched.Padding = new System.Windows.Forms.Padding(3);
            this.tabposched.Size = new System.Drawing.Size(1220, 595);
            this.tabposched.TabIndex = 1;
            this.tabposched.Text = "PUB OWNER SCHEDULE";
            this.tabposched.UseVisualStyleBackColor = true;
            // 
            // tabrelsched
            // 
            this.tabrelsched.Location = new System.Drawing.Point(4, 22);
            this.tabrelsched.Name = "tabrelsched";
            this.tabrelsched.Padding = new System.Windows.Forms.Padding(3);
            this.tabrelsched.Size = new System.Drawing.Size(1220, 474);
            this.tabrelsched.TabIndex = 2;
            this.tabrelsched.Text = "RELEASE SCHEDULE STATUS";
            this.tabrelsched.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(410, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "PUB STATUS";
            // 
            // dgridmain
            // 
            this.dgridmain.AllowUserToAddRows = false;
            this.dgridmain.AllowUserToDeleteRows = false;
            this.dgridmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridmain.Location = new System.Drawing.Point(6, 20);
            this.dgridmain.Name = "dgridmain";
            this.dgridmain.ReadOnly = true;
            this.dgridmain.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridmain.RowHeadersVisible = false;
            this.dgridmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridmain.Size = new System.Drawing.Size(1208, 241);
            this.dgridmain.TabIndex = 6;
            // 
            // btnmilestones
            // 
            this.btnmilestones.Location = new System.Drawing.Point(6, 293);
            this.btnmilestones.Name = "btnmilestones";
            this.btnmilestones.Size = new System.Drawing.Size(1208, 41);
            this.btnmilestones.TabIndex = 5;
            this.btnmilestones.Text = "CHECK MILESTONE DATES";
            this.btnmilestones.UseVisualStyleBackColor = true;
            // 
            // dgriddelay
            // 
            this.dgriddelay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgriddelay.Location = new System.Drawing.Point(6, 340);
            this.dgriddelay.Name = "dgriddelay";
            this.dgriddelay.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgriddelay.RowHeadersVisible = false;
            this.dgriddelay.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgriddelay.Size = new System.Drawing.Size(401, 207);
            this.dgriddelay.TabIndex = 7;
            // 
            // dgridtoday
            // 
            this.dgridtoday.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridtoday.Location = new System.Drawing.Point(413, 340);
            this.dgridtoday.Name = "dgridtoday";
            this.dgridtoday.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridtoday.RowHeadersVisible = false;
            this.dgridtoday.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridtoday.Size = new System.Drawing.Size(416, 207);
            this.dgridtoday.TabIndex = 8;
            // 
            // dgridupcoming
            // 
            this.dgridupcoming.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridupcoming.Location = new System.Drawing.Point(835, 340);
            this.dgridupcoming.Name = "dgridupcoming";
            this.dgridupcoming.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridupcoming.RowHeadersVisible = false;
            this.dgridupcoming.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridupcoming.Size = new System.Drawing.Size(379, 207);
            this.dgridupcoming.TabIndex = 9;
            // 
            // btnexportdates
            // 
            this.btnexportdates.Location = new System.Drawing.Point(6, 551);
            this.btnexportdates.Name = "btnexportdates";
            this.btnexportdates.Size = new System.Drawing.Size(1208, 41);
            this.btnexportdates.TabIndex = 10;
            this.btnexportdates.Text = "EXPORT MILESTONE DATES";
            this.btnexportdates.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 264);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Row Count:";
            // 
            // lbltotalrow
            // 
            this.lbltotalrow.AutoSize = true;
            this.lbltotalrow.Location = new System.Drawing.Point(65, 264);
            this.lbltotalrow.Name = "lbltotalrow";
            this.lbltotalrow.Size = new System.Drawing.Size(13, 13);
            this.lbltotalrow.TabIndex = 12;
            this.lbltotalrow.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1252, 700);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btncreatedb);
            this.Controls.Add(this.txtbrowse);
            this.Controls.Add(this.btnbrowse);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LNUS Analytical Timeliness Report";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabdaily.ResumeLayout(false);
            this.tabdaily.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgridmain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgriddelay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridtoday)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridupcoming)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbrowse;
        private System.Windows.Forms.TextBox txtbrowse;
        private System.Windows.Forms.Button btncreatedb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabdaily;
        private System.Windows.Forms.TabPage tabposched;
        private System.Windows.Forms.TabPage tabrelsched;
        private System.Windows.Forms.DataGridView dgridmain;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnmilestones;
        private System.Windows.Forms.DataGridView dgridupcoming;
        private System.Windows.Forms.DataGridView dgridtoday;
        private System.Windows.Forms.DataGridView dgriddelay;
        private System.Windows.Forms.Button btnexportdates;
        private System.Windows.Forms.Label lbltotalrow;
        private System.Windows.Forms.Label label3;
    }
}


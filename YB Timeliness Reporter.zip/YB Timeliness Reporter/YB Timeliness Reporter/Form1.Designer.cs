﻿namespace YB_Timeliness_Reporter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbrowse = new System.Windows.Forms.Button();
            this.txtbrowse = new System.Windows.Forms.TextBox();
            this.btncreatedb = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabdaily = new System.Windows.Forms.TabPage();
            this.btnreload = new System.Windows.Forms.Button();
            this.cmbcpo = new System.Windows.Forms.ComboBox();
            this.lblupcomingcount = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbltodaycount = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbllatcount = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbltotalrow = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnexportdates = new System.Windows.Forms.Button();
            this.dgridweek = new System.Windows.Forms.DataGridView();
            this.dgridtoday = new System.Windows.Forms.DataGridView();
            this.dgridpast = new System.Windows.Forms.DataGridView();
            this.btnmilestones = new System.Windows.Forms.Button();
            this.dgridmain = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.tabposched = new System.Windows.Forms.TabPage();
            this.tabrelsched = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabdaily.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgridweek)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridtoday)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridpast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridmain)).BeginInit();
            this.SuspendLayout();
            // 
            // btnbrowse
            // 
            this.btnbrowse.Location = new System.Drawing.Point(12, 2);
            this.btnbrowse.Name = "btnbrowse";
            this.btnbrowse.Size = new System.Drawing.Size(98, 59);
            this.btnbrowse.TabIndex = 0;
            this.btnbrowse.Text = "BROWSE OBIEE REPORT (.xlsx)";
            this.btnbrowse.UseVisualStyleBackColor = true;
            this.btnbrowse.Click += new System.EventHandler(this.btnbrowse_Click);
            // 
            // txtbrowse
            // 
            this.txtbrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbrowse.Location = new System.Drawing.Point(116, 17);
            this.txtbrowse.Name = "txtbrowse";
            this.txtbrowse.Size = new System.Drawing.Size(838, 26);
            this.txtbrowse.TabIndex = 1;
            this.txtbrowse.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btncreatedb
            // 
            this.btncreatedb.Location = new System.Drawing.Point(1142, 2);
            this.btncreatedb.Name = "btncreatedb";
            this.btncreatedb.Size = new System.Drawing.Size(98, 59);
            this.btncreatedb.TabIndex = 2;
            this.btncreatedb.Text = "CREATE LOCAL DATABASE";
            this.btncreatedb.UseVisualStyleBackColor = true;
            this.btncreatedb.Click += new System.EventHandler(this.btncreatedb_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1031, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "No Local Database?";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabdaily);
            this.tabControl1.Controls.Add(this.tabposched);
            this.tabControl1.Controls.Add(this.tabrelsched);
            this.tabControl1.Location = new System.Drawing.Point(12, 67);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1228, 703);
            this.tabControl1.TabIndex = 4;
            // 
            // tabdaily
            // 
            this.tabdaily.Controls.Add(this.label10);
            this.tabdaily.Controls.Add(this.label9);
            this.tabdaily.Controls.Add(this.label8);
            this.tabdaily.Controls.Add(this.label4);
            this.tabdaily.Controls.Add(this.btnreload);
            this.tabdaily.Controls.Add(this.cmbcpo);
            this.tabdaily.Controls.Add(this.lblupcomingcount);
            this.tabdaily.Controls.Add(this.label7);
            this.tabdaily.Controls.Add(this.lbltodaycount);
            this.tabdaily.Controls.Add(this.label6);
            this.tabdaily.Controls.Add(this.lbllatcount);
            this.tabdaily.Controls.Add(this.label5);
            this.tabdaily.Controls.Add(this.lbltotalrow);
            this.tabdaily.Controls.Add(this.label3);
            this.tabdaily.Controls.Add(this.btnexportdates);
            this.tabdaily.Controls.Add(this.dgridweek);
            this.tabdaily.Controls.Add(this.dgridtoday);
            this.tabdaily.Controls.Add(this.dgridpast);
            this.tabdaily.Controls.Add(this.btnmilestones);
            this.tabdaily.Controls.Add(this.dgridmain);
            this.tabdaily.Controls.Add(this.label2);
            this.tabdaily.Location = new System.Drawing.Point(4, 22);
            this.tabdaily.Name = "tabdaily";
            this.tabdaily.Padding = new System.Windows.Forms.Padding(3);
            this.tabdaily.Size = new System.Drawing.Size(1220, 677);
            this.tabdaily.TabIndex = 0;
            this.tabdaily.Text = "DAILY STATUS REPORT";
            this.tabdaily.UseVisualStyleBackColor = true;
            // 
            // btnreload
            // 
            this.btnreload.Location = new System.Drawing.Point(1109, 7);
            this.btnreload.Name = "btnreload";
            this.btnreload.Size = new System.Drawing.Size(105, 29);
            this.btnreload.TabIndex = 5;
            this.btnreload.Text = "RELOAD DATA";
            this.btnreload.UseVisualStyleBackColor = true;
            this.btnreload.Click += new System.EventHandler(this.btnreload_Click);
            // 
            // cmbcpo
            // 
            this.cmbcpo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbcpo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbcpo.FormattingEnabled = true;
            this.cmbcpo.Items.AddRange(new object[] {
            "ALL CPO",
            "Aquino,Sheila",
            "Ampongan,Yudz Bellen",
            "Arsenal,Tim Ryan Arroyo",
            "Dino,Jon Frederick Barazon",
            "Manipon,Dada Apilada",
            "Lomigo,Paul Anthony Villeza",
            "Sumpay,Lirie John Paran",
            "Manila Team Only",
            "Iloilo Team Only"});
            this.cmbcpo.Location = new System.Drawing.Point(826, 8);
            this.cmbcpo.Name = "cmbcpo";
            this.cmbcpo.Size = new System.Drawing.Size(277, 28);
            this.cmbcpo.TabIndex = 19;
            // 
            // lblupcomingcount
            // 
            this.lblupcomingcount.AutoSize = true;
            this.lblupcomingcount.Location = new System.Drawing.Point(1201, 504);
            this.lblupcomingcount.Name = "lblupcomingcount";
            this.lblupcomingcount.Size = new System.Drawing.Size(13, 13);
            this.lblupcomingcount.TabIndex = 18;
            this.lblupcomingcount.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1142, 504);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Row Count:";
            // 
            // lbltodaycount
            // 
            this.lbltodaycount.AutoSize = true;
            this.lbltodaycount.Location = new System.Drawing.Point(1201, 376);
            this.lbltodaycount.Name = "lbltodaycount";
            this.lbltodaycount.Size = new System.Drawing.Size(13, 13);
            this.lbltodaycount.TabIndex = 16;
            this.lbltodaycount.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1142, 376);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Row Count:";
            // 
            // lbllatcount
            // 
            this.lbllatcount.AutoSize = true;
            this.lbllatcount.Location = new System.Drawing.Point(1201, 248);
            this.lbllatcount.Name = "lbllatcount";
            this.lbllatcount.Size = new System.Drawing.Size(13, 13);
            this.lbllatcount.TabIndex = 14;
            this.lbllatcount.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1142, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Row Count:";
            // 
            // lbltotalrow
            // 
            this.lbltotalrow.AutoSize = true;
            this.lbltotalrow.Location = new System.Drawing.Point(65, 198);
            this.lbltotalrow.Name = "lbltotalrow";
            this.lbltotalrow.Size = new System.Drawing.Size(13, 13);
            this.lbltotalrow.TabIndex = 12;
            this.lbltotalrow.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Row Count:";
            // 
            // btnexportdates
            // 
            this.btnexportdates.Location = new System.Drawing.Point(85, 632);
            this.btnexportdates.Name = "btnexportdates";
            this.btnexportdates.Size = new System.Drawing.Size(1051, 38);
            this.btnexportdates.TabIndex = 10;
            this.btnexportdates.Text = "EXPORT DATA";
            this.btnexportdates.UseVisualStyleBackColor = true;
            this.btnexportdates.Click += new System.EventHandler(this.btnexportdates_Click);
            // 
            // dgridweek
            // 
            this.dgridweek.AllowUserToAddRows = false;
            this.dgridweek.AllowUserToDeleteRows = false;
            this.dgridweek.AllowUserToResizeColumns = false;
            this.dgridweek.AllowUserToResizeRows = false;
            this.dgridweek.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridweek.Location = new System.Drawing.Point(85, 504);
            this.dgridweek.Name = "dgridweek";
            this.dgridweek.ReadOnly = true;
            this.dgridweek.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridweek.RowHeadersVisible = false;
            this.dgridweek.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridweek.Size = new System.Drawing.Size(1051, 122);
            this.dgridweek.TabIndex = 9;
            // 
            // dgridtoday
            // 
            this.dgridtoday.AllowUserToAddRows = false;
            this.dgridtoday.AllowUserToDeleteRows = false;
            this.dgridtoday.AllowUserToResizeColumns = false;
            this.dgridtoday.AllowUserToResizeRows = false;
            this.dgridtoday.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridtoday.Location = new System.Drawing.Point(85, 376);
            this.dgridtoday.Name = "dgridtoday";
            this.dgridtoday.ReadOnly = true;
            this.dgridtoday.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridtoday.RowHeadersVisible = false;
            this.dgridtoday.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridtoday.Size = new System.Drawing.Size(1051, 122);
            this.dgridtoday.TabIndex = 8;
            // 
            // dgridpast
            // 
            this.dgridpast.AllowUserToAddRows = false;
            this.dgridpast.AllowUserToDeleteRows = false;
            this.dgridpast.AllowUserToResizeColumns = false;
            this.dgridpast.AllowUserToResizeRows = false;
            this.dgridpast.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridpast.Location = new System.Drawing.Point(85, 248);
            this.dgridpast.Name = "dgridpast";
            this.dgridpast.ReadOnly = true;
            this.dgridpast.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridpast.RowHeadersVisible = false;
            this.dgridpast.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridpast.Size = new System.Drawing.Size(1051, 122);
            this.dgridpast.TabIndex = 7;
            // 
            // btnmilestones
            // 
            this.btnmilestones.Location = new System.Drawing.Point(9, 214);
            this.btnmilestones.Name = "btnmilestones";
            this.btnmilestones.Size = new System.Drawing.Size(1208, 30);
            this.btnmilestones.TabIndex = 5;
            this.btnmilestones.Text = "CHECK MILESTONE DATES";
            this.btnmilestones.UseVisualStyleBackColor = true;
            this.btnmilestones.Click += new System.EventHandler(this.btnmilestones_Click);
            // 
            // dgridmain
            // 
            this.dgridmain.AllowUserToAddRows = false;
            this.dgridmain.AllowUserToDeleteRows = false;
            this.dgridmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridmain.Location = new System.Drawing.Point(6, 41);
            this.dgridmain.Name = "dgridmain";
            this.dgridmain.ReadOnly = true;
            this.dgridmain.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridmain.RowHeadersVisible = false;
            this.dgridmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridmain.Size = new System.Drawing.Size(1208, 154);
            this.dgridmain.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(544, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "PUB STATUS";
            // 
            // tabposched
            // 
            this.tabposched.Location = new System.Drawing.Point(4, 22);
            this.tabposched.Name = "tabposched";
            this.tabposched.Padding = new System.Windows.Forms.Padding(3);
            this.tabposched.Size = new System.Drawing.Size(1220, 595);
            this.tabposched.TabIndex = 1;
            this.tabposched.Text = "PUB OWNER SCHEDULE";
            this.tabposched.UseVisualStyleBackColor = true;
            // 
            // tabrelsched
            // 
            this.tabrelsched.Location = new System.Drawing.Point(4, 22);
            this.tabrelsched.Name = "tabrelsched";
            this.tabrelsched.Padding = new System.Windows.Forms.Padding(3);
            this.tabrelsched.Size = new System.Drawing.Size(1220, 595);
            this.tabrelsched.TabIndex = 2;
            this.tabrelsched.Text = "RELEASE SCHEDULE STATUS";
            this.tabrelsched.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(723, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 24);
            this.label4.TabIndex = 5;
            this.label4.Text = "PUB CPO:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(21, 299);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 15);
            this.label8.TabIndex = 20;
            this.label8.Text = "LATE";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(0, 428);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 15);
            this.label9.TabIndex = 21;
            this.label9.Text = "DUE TODAY";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 555);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 30);
            this.label10.TabIndex = 22;
            this.label10.Text = "DUE \r\nTHIS WEEK";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1252, 771);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btncreatedb);
            this.Controls.Add(this.txtbrowse);
            this.Controls.Add(this.btnbrowse);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LNUS Analytical Timeliness Report";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabdaily.ResumeLayout(false);
            this.tabdaily.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgridweek)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridtoday)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridpast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridmain)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbrowse;
        private System.Windows.Forms.TextBox txtbrowse;
        private System.Windows.Forms.Button btncreatedb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabdaily;
        private System.Windows.Forms.TabPage tabposched;
        private System.Windows.Forms.TabPage tabrelsched;
        private System.Windows.Forms.DataGridView dgridmain;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnmilestones;
        private System.Windows.Forms.DataGridView dgridweek;
        private System.Windows.Forms.DataGridView dgridtoday;
        private System.Windows.Forms.DataGridView dgridpast;
        private System.Windows.Forms.Button btnexportdates;
        private System.Windows.Forms.Label lbltotalrow;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblupcomingcount;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbltodaycount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbllatcount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbcpo;
        private System.Windows.Forms.Button btnreload;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
    }
}


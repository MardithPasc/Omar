﻿namespace YB_Timeliness_Reporter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbrowse = new System.Windows.Forms.Button();
            this.txtbrowse = new System.Windows.Forms.TextBox();
            this.btncreatedb = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabdaily = new System.Windows.Forms.TabPage();
            this.lblstart = new System.Windows.Forms.Label();
            this.lblend = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dtpickerend = new System.Windows.Forms.DateTimePicker();
            this.dtpickerstart = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnreload = new System.Windows.Forms.Button();
            this.cmbcpo = new System.Windows.Forms.ComboBox();
            this.lblupcomingcount = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbltodaycount = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbllatcount = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbltotalrow = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnexportdates = new System.Windows.Forms.Button();
            this.dgridweek = new System.Windows.Forms.DataGridView();
            this.dgridtoday = new System.Windows.Forms.DataGridView();
            this.dgridpast = new System.Windows.Forms.DataGridView();
            this.btnmilestones = new System.Windows.Forms.Button();
            this.dgridmain = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.tabposched = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabprintsched = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabonline = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.btnnewsched = new System.Windows.Forms.Button();
            this.dgridnewonlinesched = new System.Windows.Forms.DataGridView();
            this.lblonlinecount = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.cmbonlinecpo = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dtponlineend = new System.Windows.Forms.DateTimePicker();
            this.dtponlinestart = new System.Windows.Forms.DateTimePicker();
            this.btncheckonline = new System.Windows.Forms.Button();
            this.dgridonlineprod = new System.Windows.Forms.DataGridView();
            this.tabrelsched = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.tabdaily.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgridweek)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridtoday)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridpast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridmain)).BeginInit();
            this.tabposched.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabprintsched.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.SuspendLayout();
            this.tabonline.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgridnewonlinesched)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridonlineprod)).BeginInit();
            this.SuspendLayout();
            // 
            // btnbrowse
            // 
            this.btnbrowse.Location = new System.Drawing.Point(12, 2);
            this.btnbrowse.Name = "btnbrowse";
            this.btnbrowse.Size = new System.Drawing.Size(98, 59);
            this.btnbrowse.TabIndex = 0;
            this.btnbrowse.Text = "BROWSE OBIEE REPORT (.xlsx)";
            this.btnbrowse.UseVisualStyleBackColor = true;
            this.btnbrowse.Click += new System.EventHandler(this.btnbrowse_Click);
            // 
            // txtbrowse
            // 
            this.txtbrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbrowse.Location = new System.Drawing.Point(116, 17);
            this.txtbrowse.Name = "txtbrowse";
            this.txtbrowse.Size = new System.Drawing.Size(838, 26);
            this.txtbrowse.TabIndex = 1;
            this.txtbrowse.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btncreatedb
            // 
            this.btncreatedb.Location = new System.Drawing.Point(1142, 2);
            this.btncreatedb.Name = "btncreatedb";
            this.btncreatedb.Size = new System.Drawing.Size(98, 59);
            this.btncreatedb.TabIndex = 2;
            this.btncreatedb.Text = "CREATE LOCAL DATABASE";
            this.btncreatedb.UseVisualStyleBackColor = true;
            this.btncreatedb.Click += new System.EventHandler(this.btncreatedb_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1031, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "No Local Database?";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabdaily);
            this.tabControl1.Controls.Add(this.tabposched);
            this.tabControl1.Controls.Add(this.tabrelsched);
            this.tabControl1.Location = new System.Drawing.Point(12, 67);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1228, 703);
            this.tabControl1.TabIndex = 4;
            // 
            // tabdaily
            // 
            this.tabdaily.Controls.Add(this.lblstart);
            this.tabdaily.Controls.Add(this.lblend);
            this.tabdaily.Controls.Add(this.label12);
            this.tabdaily.Controls.Add(this.label11);
            this.tabdaily.Controls.Add(this.dtpickerend);
            this.tabdaily.Controls.Add(this.dtpickerstart);
            this.tabdaily.Controls.Add(this.label10);
            this.tabdaily.Controls.Add(this.label9);
            this.tabdaily.Controls.Add(this.label8);
            this.tabdaily.Controls.Add(this.label4);
            this.tabdaily.Controls.Add(this.btnreload);
            this.tabdaily.Controls.Add(this.cmbcpo);
            this.tabdaily.Controls.Add(this.lblupcomingcount);
            this.tabdaily.Controls.Add(this.label7);
            this.tabdaily.Controls.Add(this.lbltodaycount);
            this.tabdaily.Controls.Add(this.label6);
            this.tabdaily.Controls.Add(this.lbllatcount);
            this.tabdaily.Controls.Add(this.label5);
            this.tabdaily.Controls.Add(this.lbltotalrow);
            this.tabdaily.Controls.Add(this.label3);
            this.tabdaily.Controls.Add(this.btnexportdates);
            this.tabdaily.Controls.Add(this.dgridweek);
            this.tabdaily.Controls.Add(this.dgridtoday);
            this.tabdaily.Controls.Add(this.dgridpast);
            this.tabdaily.Controls.Add(this.btnmilestones);
            this.tabdaily.Controls.Add(this.dgridmain);
            this.tabdaily.Controls.Add(this.label2);
            this.tabdaily.Location = new System.Drawing.Point(4, 22);
            this.tabdaily.Name = "tabdaily";
            this.tabdaily.Padding = new System.Windows.Forms.Padding(3);
            this.tabdaily.Size = new System.Drawing.Size(1220, 677);
            this.tabdaily.TabIndex = 0;
            this.tabdaily.Text = "DAILY STATUS REPORT";
            this.tabdaily.UseVisualStyleBackColor = true;
            // 
            // lblstart
            // 
            this.lblstart.AutoSize = true;
            this.lblstart.Location = new System.Drawing.Point(82, 3);
            this.lblstart.Name = "lblstart";
            this.lblstart.Size = new System.Drawing.Size(13, 13);
            this.lblstart.TabIndex = 28;
            this.lblstart.Text = "0";
            this.lblstart.Visible = false;
            // 
            // lblend
            // 
            this.lblend.AutoSize = true;
            this.lblend.Location = new System.Drawing.Point(355, 1);
            this.lblend.Name = "lblend";
            this.lblend.Size = new System.Drawing.Size(13, 13);
            this.lblend.TabIndex = 27;
            this.lblend.Text = "0";
            this.lblend.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(292, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 13);
            this.label12.TabIndex = 26;
            this.label12.Text = "END DATE:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 13);
            this.label11.TabIndex = 25;
            this.label11.Text = "START DATE:";
            // 
            // dtpickerend
            // 
            this.dtpickerend.Location = new System.Drawing.Point(358, 17);
            this.dtpickerend.MinDate = new System.DateTime(2018, 1, 1, 0, 0, 0, 0);
            this.dtpickerend.Name = "dtpickerend";
            this.dtpickerend.Size = new System.Drawing.Size(200, 20);
            this.dtpickerend.TabIndex = 24;
            this.dtpickerend.Value = new System.DateTime(2018, 8, 20, 0, 0, 0, 0);
            this.dtpickerend.ValueChanged += new System.EventHandler(this.dtpickerend_ValueChanged);
            // 
            // dtpickerstart
            // 
            this.dtpickerstart.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpickerstart.Location = new System.Drawing.Point(85, 17);
            this.dtpickerstart.MinDate = new System.DateTime(2018, 1, 1, 0, 0, 0, 0);
            this.dtpickerstart.Name = "dtpickerstart";
            this.dtpickerstart.Size = new System.Drawing.Size(200, 20);
            this.dtpickerstart.TabIndex = 23;
            this.dtpickerstart.ValueChanged += new System.EventHandler(this.dtpickerstart_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 555);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 30);
            this.label10.TabIndex = 22;
            this.label10.Text = "DUE \r\nTHIS WEEK";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(0, 428);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 15);
            this.label9.TabIndex = 21;
            this.label9.Text = "DUE TODAY";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(21, 299);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 15);
            this.label8.TabIndex = 20;
            this.label8.Text = "LATE";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(625, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 24);
            this.label4.TabIndex = 5;
            this.label4.Text = "PUB CPO:";
            // 
            // btnreload
            // 
            this.btnreload.Location = new System.Drawing.Point(1109, 7);
            this.btnreload.Name = "btnreload";
            this.btnreload.Size = new System.Drawing.Size(105, 29);
            this.btnreload.TabIndex = 5;
            this.btnreload.Text = "RELOAD DATA";
            this.btnreload.UseVisualStyleBackColor = true;
            this.btnreload.Click += new System.EventHandler(this.btnreload_Click);
            // 
            // cmbcpo
            // 
            this.cmbcpo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbcpo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbcpo.FormattingEnabled = true;
            this.cmbcpo.Items.AddRange(new object[] {
            "ALL CPO",
            "Aquino,Sheila",
            "Ampongan,Yudz Bellen",
            "Arsenal,Tim Ryan Arroyo",
            "Dino,Jon Frederick Barazon",
            "Manipon,Dada Apilada",
            "Lomigo,Paul Anthony Villeza",
            "Sumpay,Lirie John Paran",
            "Manila Team Only",
            "Iloilo Team Only"});
            this.cmbcpo.Location = new System.Drawing.Point(826, 8);
            this.cmbcpo.Name = "cmbcpo";
            this.cmbcpo.Size = new System.Drawing.Size(277, 28);
            this.cmbcpo.TabIndex = 19;
            this.cmbcpo.SelectedIndexChanged += new System.EventHandler(this.cmbcpo_SelectedIndexChanged);
            // 
            // lblupcomingcount
            // 
            this.lblupcomingcount.AutoSize = true;
            this.lblupcomingcount.Location = new System.Drawing.Point(1201, 504);
            this.lblupcomingcount.Name = "lblupcomingcount";
            this.lblupcomingcount.Size = new System.Drawing.Size(13, 13);
            this.lblupcomingcount.TabIndex = 18;
            this.lblupcomingcount.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1142, 504);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Row Count:";
            // 
            // lbltodaycount
            // 
            this.lbltodaycount.AutoSize = true;
            this.lbltodaycount.Location = new System.Drawing.Point(1201, 376);
            this.lbltodaycount.Name = "lbltodaycount";
            this.lbltodaycount.Size = new System.Drawing.Size(13, 13);
            this.lbltodaycount.TabIndex = 16;
            this.lbltodaycount.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1142, 376);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Row Count:";
            // 
            // lbllatcount
            // 
            this.lbllatcount.AutoSize = true;
            this.lbllatcount.Location = new System.Drawing.Point(1201, 248);
            this.lbllatcount.Name = "lbllatcount";
            this.lbllatcount.Size = new System.Drawing.Size(13, 13);
            this.lbllatcount.TabIndex = 14;
            this.lbllatcount.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1142, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Row Count:";
            // 
            // lbltotalrow
            // 
            this.lbltotalrow.AutoSize = true;
            this.lbltotalrow.Location = new System.Drawing.Point(65, 198);
            this.lbltotalrow.Name = "lbltotalrow";
            this.lbltotalrow.Size = new System.Drawing.Size(13, 13);
            this.lbltotalrow.TabIndex = 12;
            this.lbltotalrow.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Row Count:";
            // 
            // btnexportdates
            // 
            this.btnexportdates.Location = new System.Drawing.Point(85, 632);
            this.btnexportdates.Name = "btnexportdates";
            this.btnexportdates.Size = new System.Drawing.Size(1051, 38);
            this.btnexportdates.TabIndex = 10;
            this.btnexportdates.Text = "EXPORT DATA";
            this.btnexportdates.UseVisualStyleBackColor = true;
            this.btnexportdates.Click += new System.EventHandler(this.btnexportdates_Click);
            // 
            // dgridweek
            // 
            this.dgridweek.AllowUserToAddRows = false;
            this.dgridweek.AllowUserToDeleteRows = false;
            this.dgridweek.AllowUserToResizeColumns = false;
            this.dgridweek.AllowUserToResizeRows = false;
            this.dgridweek.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridweek.Location = new System.Drawing.Point(85, 504);
            this.dgridweek.Name = "dgridweek";
            this.dgridweek.ReadOnly = true;
            this.dgridweek.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridweek.RowHeadersVisible = false;
            this.dgridweek.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridweek.Size = new System.Drawing.Size(1051, 122);
            this.dgridweek.TabIndex = 9;
            // 
            // dgridtoday
            // 
            this.dgridtoday.AllowUserToAddRows = false;
            this.dgridtoday.AllowUserToDeleteRows = false;
            this.dgridtoday.AllowUserToResizeColumns = false;
            this.dgridtoday.AllowUserToResizeRows = false;
            this.dgridtoday.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridtoday.Location = new System.Drawing.Point(85, 376);
            this.dgridtoday.Name = "dgridtoday";
            this.dgridtoday.ReadOnly = true;
            this.dgridtoday.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridtoday.RowHeadersVisible = false;
            this.dgridtoday.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridtoday.Size = new System.Drawing.Size(1051, 122);
            this.dgridtoday.TabIndex = 8;
            // 
            // dgridpast
            // 
            this.dgridpast.AllowUserToAddRows = false;
            this.dgridpast.AllowUserToDeleteRows = false;
            this.dgridpast.AllowUserToResizeColumns = false;
            this.dgridpast.AllowUserToResizeRows = false;
            this.dgridpast.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridpast.Location = new System.Drawing.Point(85, 248);
            this.dgridpast.Name = "dgridpast";
            this.dgridpast.ReadOnly = true;
            this.dgridpast.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridpast.RowHeadersVisible = false;
            this.dgridpast.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridpast.Size = new System.Drawing.Size(1051, 122);
            this.dgridpast.TabIndex = 7;
            // 
            // btnmilestones
            // 
            this.btnmilestones.Location = new System.Drawing.Point(9, 214);
            this.btnmilestones.Name = "btnmilestones";
            this.btnmilestones.Size = new System.Drawing.Size(1208, 30);
            this.btnmilestones.TabIndex = 5;
            this.btnmilestones.Text = "CHECK MILESTONE DATES";
            this.btnmilestones.UseVisualStyleBackColor = true;
            this.btnmilestones.Click += new System.EventHandler(this.btnmilestones_Click);
            // 
            // dgridmain
            // 
            this.dgridmain.AllowUserToAddRows = false;
            this.dgridmain.AllowUserToDeleteRows = false;
            this.dgridmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridmain.Location = new System.Drawing.Point(6, 41);
            this.dgridmain.Name = "dgridmain";
            this.dgridmain.ReadOnly = true;
            this.dgridmain.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridmain.RowHeadersVisible = false;
            this.dgridmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridmain.Size = new System.Drawing.Size(1208, 154);
            this.dgridmain.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(544, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "PUB STATUS";
            // 
            // tabposched
            // 
            this.tabposched.Controls.Add(this.tabControl2);
            this.tabposched.Location = new System.Drawing.Point(4, 22);
            this.tabposched.Name = "tabposched";
            this.tabposched.Padding = new System.Windows.Forms.Padding(3);
            this.tabposched.Size = new System.Drawing.Size(1220, 677);
            this.tabposched.TabIndex = 1;
            this.tabposched.Text = "SCHEDULE BASED ON JOB ORDER ACTUAL";
            this.tabposched.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabprintsched);
            this.tabControl2.Controls.Add(this.tabonline);
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1211, 664);
            this.tabControl2.TabIndex = 0;
            // 
            // tabprintsched
            // 
            this.tabprintsched.Controls.Add(this.splitContainer1);
            this.tabprintsched.Location = new System.Drawing.Point(4, 22);
            this.tabprintsched.Name = "tabprintsched";
            this.tabprintsched.Padding = new System.Windows.Forms.Padding(3);
            this.tabprintsched.Size = new System.Drawing.Size(1203, 638);
            this.tabprintsched.TabIndex = 0;
            this.tabprintsched.Text = "PRINT SCHEDULE";
            this.tabprintsched.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Size = new System.Drawing.Size(1197, 632);
            this.splitContainer1.SplitterDistance = 328;
            this.splitContainer1.TabIndex = 0;
            // 
            // tabonline
            // 
            this.tabonline.Controls.Add(this.splitContainer2);
            this.tabonline.Location = new System.Drawing.Point(4, 22);
            this.tabonline.Name = "tabonline";
            this.tabonline.Padding = new System.Windows.Forms.Padding(3);
            this.tabonline.Size = new System.Drawing.Size(1203, 638);
            this.tabonline.TabIndex = 1;
            this.tabonline.Text = "ONLINE SCHEDULE";
            this.tabonline.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(3, 3);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.btnnewsched);
            this.splitContainer2.Panel2.Controls.Add(this.dgridnewonlinesched);
            this.splitContainer2.Panel2.Controls.Add(this.lblonlinecount);
            this.splitContainer2.Panel2.Controls.Add(this.label17);
            this.splitContainer2.Panel2.Controls.Add(this.label15);
            this.splitContainer2.Panel2.Controls.Add(this.cmbonlinecpo);
            this.splitContainer2.Panel2.Controls.Add(this.label13);
            this.splitContainer2.Panel2.Controls.Add(this.label14);
            this.splitContainer2.Panel2.Controls.Add(this.dtponlineend);
            this.splitContainer2.Panel2.Controls.Add(this.dtponlinestart);
            this.splitContainer2.Panel2.Controls.Add(this.btncheckonline);
            this.splitContainer2.Panel2.Controls.Add(this.dgridonlineprod);
            this.splitContainer2.Size = new System.Drawing.Size(1197, 632);
            this.splitContainer2.SplitterDistance = 327;
            this.splitContainer2.TabIndex = 0;
            // 
            // btnnewsched
            // 
            this.btnnewsched.Location = new System.Drawing.Point(9, 328);
            this.btnnewsched.Name = "btnnewsched";
            this.btnnewsched.Size = new System.Drawing.Size(98, 37);
            this.btnnewsched.TabIndex = 36;
            this.btnnewsched.Text = "CHECK NEW SCHED";
            this.btnnewsched.UseVisualStyleBackColor = true;
            this.btnnewsched.Click += new System.EventHandler(this.btnnewsched_Click);
            // 
            // dgridnewonlinesched
            // 
            this.dgridnewonlinesched.AllowUserToAddRows = false;
            this.dgridnewonlinesched.AllowUserToDeleteRows = false;
            this.dgridnewonlinesched.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridnewonlinesched.Location = new System.Drawing.Point(9, 371);
            this.dgridnewonlinesched.Name = "dgridnewonlinesched";
            this.dgridnewonlinesched.ReadOnly = true;
            this.dgridnewonlinesched.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridnewonlinesched.RowHeadersVisible = false;
            this.dgridnewonlinesched.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridnewonlinesched.Size = new System.Drawing.Size(848, 258);
            this.dgridnewonlinesched.TabIndex = 35;
            // 
            // lblonlinecount
            // 
            this.lblonlinecount.AutoSize = true;
            this.lblonlinecount.Location = new System.Drawing.Point(65, 303);
            this.lblonlinecount.Name = "lblonlinecount";
            this.lblonlinecount.Size = new System.Drawing.Size(13, 13);
            this.lblonlinecount.TabIndex = 34;
            this.lblonlinecount.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 303);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 13);
            this.label17.TabIndex = 33;
            this.label17.Text = "Row Count:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(603, 11);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 31;
            this.label15.Text = "PUB CPO:";
            // 
            // cmbonlinecpo
            // 
            this.cmbonlinecpo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbonlinecpo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbonlinecpo.FormattingEnabled = true;
            this.cmbonlinecpo.Items.AddRange(new object[] {
            "ALL CPO",
            "Aquino,Sheila",
            "Ampongan,Yudz Bellen",
            "Arsenal,Tim Ryan Arroyo",
            "Dino,Jon Frederick Barazon",
            "Manipon,Dada Apilada",
            "Lomigo,Paul Anthony Villeza",
            "Sumpay,Lirie John Paran",
            "Manila Team Only",
            "Iloilo Team Only"});
            this.cmbonlinecpo.Location = new System.Drawing.Point(666, 6);
            this.cmbonlinecpo.Name = "cmbonlinecpo";
            this.cmbonlinecpo.Size = new System.Drawing.Size(191, 21);
            this.cmbonlinecpo.TabIndex = 32;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(301, 12);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 13);
            this.label13.TabIndex = 30;
            this.label13.Text = "END DATE:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 11);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 13);
            this.label14.TabIndex = 29;
            this.label14.Text = "START DATE:";
            // 
            // dtponlineend
            // 
            this.dtponlineend.Location = new System.Drawing.Point(367, 8);
            this.dtponlineend.MinDate = new System.DateTime(2018, 1, 1, 0, 0, 0, 0);
            this.dtponlineend.Name = "dtponlineend";
            this.dtponlineend.Size = new System.Drawing.Size(200, 20);
            this.dtponlineend.TabIndex = 28;
            this.dtponlineend.Value = new System.DateTime(2018, 8, 20, 0, 0, 0, 0);
            // 
            // dtponlinestart
            // 
            this.dtponlinestart.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtponlinestart.Location = new System.Drawing.Point(94, 8);
            this.dtponlinestart.MinDate = new System.DateTime(2018, 1, 1, 0, 0, 0, 0);
            this.dtponlinestart.Name = "dtponlinestart";
            this.dtponlinestart.Size = new System.Drawing.Size(200, 20);
            this.dtponlinestart.TabIndex = 27;
            this.dtponlinestart.ValueChanged += new System.EventHandler(this.dtponlinestart_ValueChanged);
            // 
            // btncheckonline
            // 
            this.btncheckonline.Location = new System.Drawing.Point(759, 306);
            this.btncheckonline.Name = "btncheckonline";
            this.btncheckonline.Size = new System.Drawing.Size(98, 59);
            this.btncheckonline.TabIndex = 5;
            this.btncheckonline.Text = "CHECK ONLINE SCHEDULE";
            this.btncheckonline.UseVisualStyleBackColor = true;
            this.btncheckonline.Click += new System.EventHandler(this.btncheckonline_Click);
            // 
            // dgridonlineprod
            // 
            this.dgridonlineprod.AllowUserToAddRows = false;
            this.dgridonlineprod.AllowUserToDeleteRows = false;
            this.dgridonlineprod.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgridonlineprod.Location = new System.Drawing.Point(9, 32);
            this.dgridonlineprod.Name = "dgridonlineprod";
            this.dgridonlineprod.ReadOnly = true;
            this.dgridonlineprod.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgridonlineprod.RowHeadersVisible = false;
            this.dgridonlineprod.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgridonlineprod.Size = new System.Drawing.Size(848, 268);
            this.dgridonlineprod.TabIndex = 7;
            // 
            // tabrelsched
            // 
            this.tabrelsched.Location = new System.Drawing.Point(4, 22);
            this.tabrelsched.Name = "tabrelsched";
            this.tabrelsched.Padding = new System.Windows.Forms.Padding(3);
            this.tabrelsched.Size = new System.Drawing.Size(1220, 677);
            this.tabrelsched.TabIndex = 2;
            this.tabrelsched.Text = "RELEASE SCHEDULE STATUS";
            this.tabrelsched.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1252, 771);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btncreatedb);
            this.Controls.Add(this.txtbrowse);
            this.Controls.Add(this.btnbrowse);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LNUS Analytical Timeliness Report";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabdaily.ResumeLayout(false);
            this.tabdaily.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgridweek)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridtoday)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridpast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridmain)).EndInit();
            this.tabposched.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabprintsched.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabonline.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgridnewonlinesched)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgridonlineprod)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbrowse;
        private System.Windows.Forms.TextBox txtbrowse;
        private System.Windows.Forms.Button btncreatedb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabdaily;
        private System.Windows.Forms.TabPage tabposched;
        private System.Windows.Forms.TabPage tabrelsched;
        private System.Windows.Forms.DataGridView dgridmain;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnmilestones;
        private System.Windows.Forms.DataGridView dgridweek;
        private System.Windows.Forms.DataGridView dgridtoday;
        private System.Windows.Forms.DataGridView dgridpast;
        private System.Windows.Forms.Button btnexportdates;
        private System.Windows.Forms.Label lbltotalrow;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblupcomingcount;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbltodaycount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbllatcount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbcpo;
        private System.Windows.Forms.Button btnreload;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpickerend;
        private System.Windows.Forms.DateTimePicker dtpickerstart;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblend;
        private System.Windows.Forms.Label lblstart;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabprintsched;
        private System.Windows.Forms.TabPage tabonline;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.DataGridView dgridonlineprod;
        private System.Windows.Forms.Button btncheckonline;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbonlinecpo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dtponlineend;
        private System.Windows.Forms.DateTimePicker dtponlinestart;
        private System.Windows.Forms.Label lblonlinecount;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DataGridView dgridnewonlinesched;
        private System.Windows.Forms.Button btnnewsched;
    }
}


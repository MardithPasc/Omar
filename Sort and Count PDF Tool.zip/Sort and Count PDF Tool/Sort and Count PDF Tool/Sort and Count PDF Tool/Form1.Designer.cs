﻿namespace Sort_and_Count_PDF_Tool
{
    partial class formcitrix
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Colcheck = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Colfilename = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnup = new System.Windows.Forms.Button();
            this.btndown = new System.Windows.Forms.Button();
            this.btnnumber = new System.Windows.Forms.Button();
            this.btnunnum = new System.Windows.Forms.Button();
            this.SELECT = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnfirst = new System.Windows.Forms.Button();
            this.btnlast = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtpubno = new System.Windows.Forms.TextBox();
            this.txtrelno = new System.Windows.Forms.TextBox();
            this.txtest = new System.Windows.Forms.TextBox();
            this.txtact = new System.Windows.Forms.TextBox();
            this.btnclear = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtmultivol = new System.Windows.Forms.TextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbtype = new System.Windows.Forms.ComboBox();
            this.chkpubup = new System.Windows.Forms.CheckBox();
            this.tabtype = new System.Windows.Forms.TabControl();
            this.tabman = new System.Windows.Forms.TabPage();
            this.tabll = new System.Windows.Forms.TabPage();
            this.btnclearafi = new System.Windows.Forms.Button();
            this.tabbound = new System.Windows.Forms.TabPage();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabtype.SuspendLayout();
            this.tabman.SuspendLayout();
            this.tabll.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowDrop = true;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Colcheck,
            this.Colfilename});
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridView1.Location = new System.Drawing.Point(12, 118);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(569, 317);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.DragDrop += new System.Windows.Forms.DragEventHandler(this.dataGridView1_DragDrop);
            this.dataGridView1.DragOver += new System.Windows.Forms.DragEventHandler(this.dataGridView1_DragOver);
            this.dataGridView1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseDown);
            this.dataGridView1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseMove);
            // 
            // Colcheck
            // 
            this.Colcheck.HeaderText = "Start of Volume";
            this.Colcheck.Name = "Colcheck";
            this.Colcheck.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Colfilename
            // 
            this.Colfilename.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Colfilename.HeaderText = "Filename";
            this.Colfilename.Name = "Colfilename";
            this.Colfilename.ReadOnly = true;
            this.Colfilename.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Colfilename.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // btnup
            // 
            this.btnup.Enabled = false;
            this.btnup.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnup.Location = new System.Drawing.Point(14, 87);
            this.btnup.Name = "btnup";
            this.btnup.Size = new System.Drawing.Size(96, 75);
            this.btnup.TabIndex = 1;
            this.btnup.Text = "Move Up";
            this.btnup.UseVisualStyleBackColor = true;
            this.btnup.Click += new System.EventHandler(this.btnup_Click);
            // 
            // btndown
            // 
            this.btndown.Enabled = false;
            this.btndown.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndown.Location = new System.Drawing.Point(14, 168);
            this.btndown.Name = "btndown";
            this.btndown.Size = new System.Drawing.Size(96, 71);
            this.btndown.TabIndex = 2;
            this.btndown.Text = "Move Down";
            this.btndown.UseVisualStyleBackColor = true;
            this.btndown.Click += new System.EventHandler(this.btndown_Click);
            // 
            // btnnumber
            // 
            this.btnnumber.Enabled = false;
            this.btnnumber.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnumber.Location = new System.Drawing.Point(238, 441);
            this.btnnumber.Name = "btnnumber";
            this.btnnumber.Size = new System.Drawing.Size(96, 67);
            this.btnnumber.TabIndex = 3;
            this.btnnumber.Text = "Number";
            this.btnnumber.UseVisualStyleBackColor = true;
            this.btnnumber.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // btnunnum
            // 
            this.btnunnum.Enabled = false;
            this.btnunnum.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnunnum.Location = new System.Drawing.Point(340, 441);
            this.btnunnum.Name = "btnunnum";
            this.btnunnum.Size = new System.Drawing.Size(96, 67);
            this.btnunnum.TabIndex = 4;
            this.btnunnum.Text = "Remove Number";
            this.btnunnum.UseVisualStyleBackColor = true;
            this.btnunnum.Click += new System.EventHandler(this.btnunnum_Click);
            // 
            // SELECT
            // 
            this.SELECT.Enabled = false;
            this.SELECT.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SELECT.Location = new System.Drawing.Point(116, 249);
            this.SELECT.Name = "SELECT";
            this.SELECT.Size = new System.Drawing.Size(96, 67);
            this.SELECT.TabIndex = 5;
            this.SELECT.Text = "BROWSE PDF";
            this.SELECT.UseVisualStyleBackColor = true;
            this.SELECT.Click += new System.EventHandler(this.SELECT_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(707, 482);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 24);
            this.button1.TabIndex = 6;
            this.button1.Text = "SAMPLE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnfirst
            // 
            this.btnfirst.Enabled = false;
            this.btnfirst.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfirst.Location = new System.Drawing.Point(15, 6);
            this.btnfirst.Name = "btnfirst";
            this.btnfirst.Size = new System.Drawing.Size(95, 75);
            this.btnfirst.TabIndex = 7;
            this.btnfirst.Text = "Move To First Row";
            this.btnfirst.UseVisualStyleBackColor = true;
            this.btnfirst.Click += new System.EventHandler(this.btnfirst_Click);
            // 
            // btnlast
            // 
            this.btnlast.Enabled = false;
            this.btnlast.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlast.Location = new System.Drawing.Point(15, 245);
            this.btnlast.Name = "btnlast";
            this.btnlast.Size = new System.Drawing.Size(95, 75);
            this.btnlast.TabIndex = 8;
            this.btnlast.Text = "Move to Last Row";
            this.btnlast.UseVisualStyleBackColor = true;
            this.btnlast.Click += new System.EventHandler(this.btnlast_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(2, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "Enter 5 Digit Pub No.:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 24);
            this.label2.TabIndex = 10;
            this.label2.Text = "Enter Release No.:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(347, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(196, 24);
            this.label3.TabIndex = 11;
            this.label3.Text = "Enter Estimated Page:";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(657, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(171, 24);
            this.label4.TabIndex = 12;
            this.label4.Text = "Actual Page Count:";
            this.label4.Visible = false;
            // 
            // txtpubno
            // 
            this.txtpubno.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpubno.Location = new System.Drawing.Point(198, 15);
            this.txtpubno.MaxLength = 5;
            this.txtpubno.Name = "txtpubno";
            this.txtpubno.Size = new System.Drawing.Size(143, 29);
            this.txtpubno.TabIndex = 13;
            this.txtpubno.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtpubno.TextChanged += new System.EventHandler(this.txtpubno_TextChanged);
            // 
            // txtrelno
            // 
            this.txtrelno.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrelno.Location = new System.Drawing.Point(198, 48);
            this.txtrelno.MaxLength = 10;
            this.txtrelno.Name = "txtrelno";
            this.txtrelno.Size = new System.Drawing.Size(143, 29);
            this.txtrelno.TabIndex = 14;
            this.txtrelno.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtrelno.TextChanged += new System.EventHandler(this.txtrelno_TextChanged);
            // 
            // txtest
            // 
            this.txtest.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtest.Location = new System.Drawing.Point(551, 6);
            this.txtest.Name = "txtest";
            this.txtest.Size = new System.Drawing.Size(100, 29);
            this.txtest.TabIndex = 15;
            this.txtest.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtest.Visible = false;
            // 
            // txtact
            // 
            this.txtact.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtact.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtact.Location = new System.Drawing.Point(835, 10);
            this.txtact.Name = "txtact";
            this.txtact.ReadOnly = true;
            this.txtact.Size = new System.Drawing.Size(100, 22);
            this.txtact.TabIndex = 16;
            this.txtact.Text = "0";
            this.txtact.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtact.Visible = false;
            // 
            // btnclear
            // 
            this.btnclear.Enabled = false;
            this.btnclear.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(116, 176);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(96, 67);
            this.btnclear.TabIndex = 18;
            this.btnclear.Text = "REMOVE SELECTED PDF";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(707, 452);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 24);
            this.button2.TabIndex = 19;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(8, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(239, 24);
            this.label5.TabIndex = 20;
            this.label5.Text = "Multiple Volume/Package?:";
            this.label5.Visible = false;
            // 
            // txtmultivol
            // 
            this.txtmultivol.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmultivol.Location = new System.Drawing.Point(253, 82);
            this.txtmultivol.MaxLength = 2;
            this.txtmultivol.Name = "txtmultivol";
            this.txtmultivol.Size = new System.Drawing.Size(88, 29);
            this.txtmultivol.TabIndex = 21;
            this.txtmultivol.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtmultivol.Visible = false;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.richTextBox1.Location = new System.Drawing.Point(9, 50);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(191, 245);
            this.richTextBox1.TabIndex = 23;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            this.richTextBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.richTextBox1_KeyDown);
            this.richTextBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.richTextBox1_MouseDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 17);
            this.label6.TabIndex = 24;
            this.label6.Text = "Paste AFI  Units Here:";
            // 
            // cmbtype
            // 
            this.cmbtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbtype.Enabled = false;
            this.cmbtype.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbtype.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbtype.FormattingEnabled = true;
            this.cmbtype.Items.AddRange(new object[] {
            "Manual",
            "Looseleaf via AFI"});
            this.cmbtype.Location = new System.Drawing.Point(587, 46);
            this.cmbtype.Name = "cmbtype";
            this.cmbtype.Size = new System.Drawing.Size(219, 28);
            this.cmbtype.TabIndex = 25;
            this.cmbtype.SelectedIndexChanged += new System.EventHandler(this.cmbtype_SelectedIndexChanged);
            // 
            // chkpubup
            // 
            this.chkpubup.AutoSize = true;
            this.chkpubup.Location = new System.Drawing.Point(9, 6);
            this.chkpubup.Name = "chkpubup";
            this.chkpubup.Size = new System.Drawing.Size(106, 17);
            this.chkpubup.TabIndex = 26;
            this.chkpubup.Text = "No Pub Update?";
            this.chkpubup.UseVisualStyleBackColor = true;
            this.chkpubup.CheckedChanged += new System.EventHandler(this.chkpubup_CheckedChanged);
            // 
            // tabtype
            // 
            this.tabtype.Controls.Add(this.tabman);
            this.tabtype.Controls.Add(this.tabll);
            this.tabtype.Controls.Add(this.tabbound);
            this.tabtype.Location = new System.Drawing.Point(587, 79);
            this.tabtype.Name = "tabtype";
            this.tabtype.SelectedIndex = 0;
            this.tabtype.Size = new System.Drawing.Size(224, 367);
            this.tabtype.TabIndex = 27;
            this.tabtype.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabtype_Selecting);
            // 
            // tabman
            // 
            this.tabman.Controls.Add(this.btnfirst);
            this.tabman.Controls.Add(this.btnup);
            this.tabman.Controls.Add(this.btndown);
            this.tabman.Controls.Add(this.btnlast);
            this.tabman.Controls.Add(this.SELECT);
            this.tabman.Controls.Add(this.btnclear);
            this.tabman.Location = new System.Drawing.Point(4, 22);
            this.tabman.Name = "tabman";
            this.tabman.Padding = new System.Windows.Forms.Padding(3);
            this.tabman.Size = new System.Drawing.Size(216, 341);
            this.tabman.TabIndex = 0;
            this.tabman.Text = "MANUAL";
            this.tabman.UseVisualStyleBackColor = true;
            // 
            // tabll
            // 
            this.tabll.Controls.Add(this.btnclearafi);
            this.tabll.Controls.Add(this.richTextBox1);
            this.tabll.Controls.Add(this.chkpubup);
            this.tabll.Controls.Add(this.label6);
            this.tabll.Location = new System.Drawing.Point(4, 22);
            this.tabll.Name = "tabll";
            this.tabll.Padding = new System.Windows.Forms.Padding(3);
            this.tabll.Size = new System.Drawing.Size(216, 341);
            this.tabll.TabIndex = 1;
            this.tabll.Text = "LOOSELEAF";
            this.tabll.UseVisualStyleBackColor = true;
            this.tabll.Click += new System.EventHandler(this.tabll_Click);
            // 
            // btnclearafi
            // 
            this.btnclearafi.Location = new System.Drawing.Point(44, 301);
            this.btnclearafi.Name = "btnclearafi";
            this.btnclearafi.Size = new System.Drawing.Size(132, 34);
            this.btnclearafi.TabIndex = 27;
            this.btnclearafi.Text = "Clear AFI List";
            this.btnclearafi.UseVisualStyleBackColor = true;
            this.btnclearafi.Click += new System.EventHandler(this.btnclearafi_Click);
            // 
            // tabbound
            // 
            this.tabbound.Location = new System.Drawing.Point(4, 22);
            this.tabbound.Name = "tabbound";
            this.tabbound.Padding = new System.Windows.Forms.Padding(3);
            this.tabbound.Size = new System.Drawing.Size(216, 341);
            this.tabbound.TabIndex = 2;
            this.tabbound.UseVisualStyleBackColor = true;
            // 
            // formcitrix
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(818, 535);
            this.Controls.Add(this.tabtype);
            this.Controls.Add(this.cmbtype);
            this.Controls.Add(this.txtmultivol);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txtact);
            this.Controls.Add(this.txtest);
            this.Controls.Add(this.txtrelno);
            this.Controls.Add(this.txtpubno);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnunnum);
            this.Controls.Add(this.btnnumber);
            this.Controls.Add(this.dataGridView1);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "formcitrix";
            this.Text = "PDF Sorter and Page Counter (Citrix J: Drive)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.formcitrix_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabtype.ResumeLayout(false);
            this.tabman.ResumeLayout(false);
            this.tabll.ResumeLayout(false);
            this.tabll.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnup;
        private System.Windows.Forms.Button btndown;
        private System.Windows.Forms.Button btnnumber;
        private System.Windows.Forms.Button btnunnum;
        private System.Windows.Forms.Button SELECT;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnfirst;
        private System.Windows.Forms.Button btnlast;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtpubno;
        private System.Windows.Forms.TextBox txtrelno;
        private System.Windows.Forms.TextBox txtest;
        private System.Windows.Forms.TextBox txtact;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtmultivol;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Colcheck;
        private System.Windows.Forms.DataGridViewTextBoxColumn Colfilename;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbtype;
        private System.Windows.Forms.CheckBox chkpubup;
        private System.Windows.Forms.TabControl tabtype;
        private System.Windows.Forms.TabPage tabman;
        private System.Windows.Forms.TabPage tabll;
        private System.Windows.Forms.TabPage tabbound;
        private System.Windows.Forms.Button btnclearafi;
    }
}


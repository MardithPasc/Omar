﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using iTextSharp.text.pdf;
using iTextSharp;
using System.IO.Compression;
using System.Data.OleDb;


namespace Sort_and_Count_PDF_Tool
{
    public partial class FormLocal : Form
    {
        private Rectangle dragBoxFromMouseDown;
        private int rowIndexFromMouseDown;
        private int rowIndexOfItemUnderMouseToDrop;
        bool checktab = true;
        string whole_path;
        public string flowbie_pu;
        public string flowbie_fi;
        public int flowbie_pu_count;
        public int flowbie_fi_count;
        public bool has_flowbie = false;
        //string afi_path;
        int whole_pdf_count = 0;
        public FormLocal()
        {
            InitializeComponent();
        }

        private void FormLocal_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void btnnumber_Click(object sender, EventArgs e)
        {
            int pre_check = 0;
            if (txtpubno.Text == "" || txtrelno.Text == "")
            {
                MessageBox.Show("No Pub Number or Release number has been entered. Please provide these details before proceeding", "Pub Number and Release Number Requirement", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (cmbtype.SelectedIndex == 1)
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells["ColCheck"].Value) == true)
                        {
                            pre_check = pre_check + 1;
                        }
                    }

                    if (pre_check > 2 || pre_check == 0)
                    {
                        if (dataGridView1.Rows.Count == 0)
                        {
                            MessageBox.Show("Unable to number, list is empty. Please browse and load PDF files", "Empty List", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            delelte_forclear_folder();
                            number_file();
                            unnumber_file();
                            lblremindme.Visible = true;
                            lblremindme.Text = "DOUBLE CHECK THE PDF FILES, FILE SEQUENCE, ZIP FILES, AND ZIP FILES NAMES";
                        }
                    }
                    else
                    {
                        MessageBox.Show("If you are processing a flowbie release, kindly check atleast three row as the first file in each package.", "REQUIRED PACKAGES", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    if (dataGridView1.Rows.Count == 0)
                    {
                        MessageBox.Show("Unable to number, list is empty. Please browse and load PDF files", "Empty List", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        delelte_forclear_folder();
                        number_file();
                        unnumber_file();
                        lblremindme.Visible = true;
                        lblremindme.Text = "DOUBLE CHECK THE PDF FILES, FILE SEQUENCE, ZIP FILES, AND ZIP FILES NAMES";
                    }
                    
                }
            }
        }
        public void delelte_forclear_folder()
        {
            try
            {
                string path = @txtgetpubno.Text + @"\For Clear\";
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                else
                {
                    Directory.Delete(path, true);
                    Directory.CreateDirectory(path);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        public void number_file()
        {
            int current_pagecount = 0;
            auto_number_file();
            string new_name, fle, new_path;
            int counter = 1;
            bool hasfmv = false;
            if (cmbtype.SelectedIndex == 1) //NEW ADDED * IF COMBOBOX = LOOSELEAF VIA AFI
            {
                if (whole_pdf_count > 1850 && chkautozipflowbie.Checked == true) // FOR FLOWBIE NUMBERING
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {

                        if (row.Index == 0)
                        {
                            counter = 1;
                        }
                        else if ((row.Cells[1].Value.ToString().Contains("_fmv") || (row.Cells[1].Value.ToString().Contains("_ptoc"))) && (hasfmv == false))
                        {
                            counter = 1;
                            hasfmv = true;
                        }

                        /////////// ADDED PO TO CHECK START OF VOLUME
                        if (Convert.ToBoolean(row.Cells["ColCheck"].Value) == true)
                        {
                            counter = 1;
                        }
                        ////////////

                        current_pagecount = current_pagecount + Convert.ToInt16(row.Cells[2].Value.ToString());
                        if (current_pagecount > 1850)
                        {
                            counter = 1;
                            current_pagecount = Convert.ToInt16(row.Cells[2].Value.ToString());
                        }
                        else { }


                        fle = row.Cells[1].Value.ToString();
                        if (counter < 10)
                        {
                            new_name = "00" + counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        else if (counter < 100)
                        {
                            new_name = "0" + counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        else
                        {
                            new_name = counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        counter += 1;
                    }
                }

                else if (chkautozipflowbie.Checked == false)//&& (whole_pdf_count > 1850))//(whole_pdf_count > 1850 && chkautozipflowbie.Checked == false)
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {

                        if (row.Index == 0)
                        {
                            counter = 1;
                        }
                        else if ((row.Cells[1].Value.ToString().Contains("_fmv") || (row.Cells[1].Value.ToString().Contains("_ptoc"))) && (hasfmv == false))
                        {
                            counter = 1;
                            hasfmv = true;
                        }
                        
                        if (Convert.ToBoolean(row.Cells["ColCheck"].Value) == true)
                        {
                            counter = 1;
                        }

                        fle = row.Cells[1].Value.ToString();
                        if (counter < 10)
                        {
                            new_name = "00" + counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        else if (counter < 100)
                        {
                            new_name = "0" + counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        else
                        {
                            new_name = counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        counter += 1;
                    }
                }

                else
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (row.Index == 0)
                        {
                            counter = 1;
                        }
                        else if ((row.Cells[1].Value.ToString().Contains("_fmv") || (row.Cells[1].Value.ToString().Contains("_ptoc"))) && (hasfmv == false))
                        {
                            counter = 1;
                            hasfmv = true;
                        }

                        fle = row.Cells[1].Value.ToString();
                        if (counter < 10)
                        {
                            new_name = "00" + counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        else if (counter < 100)
                        {
                            new_name = "0" + counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        else
                        {
                            new_name = counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        counter += 1;
                    }
                }
            }
            else
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (Convert.ToBoolean(row.Cells["ColCheck"].Value) == true)
                    {
                        counter = 1;
                    }
                    fle = row.Cells[1].Value.ToString();
                    if (counter < 10)
                    {
                        new_name = "00" + counter + "-" + Path.GetFileName(fle);
                        Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                        new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                        row.Cells[1].Value = new_path + @"\" + new_name;
                    }
                    else if (counter < 100)
                    {
                        new_name = "0" + counter + "-" + Path.GetFileName(fle);
                        Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                        new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                        row.Cells[1].Value = new_path + @"\" + new_name;
                    }
                    else
                    {
                        new_name = counter + "-" + Path.GetFileName(fle);
                        Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                        new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                        row.Cells[1].Value = new_path + @"\" + new_name;
                    }
                    counter += 1;
                }
            }
            dataGridView1.Refresh();
            int checkingcheck = 0;
            foreach (DataGridViewRow chk in dataGridView1.Rows)
            {
                if (Convert.ToBoolean(chk.Cells[0].Value) == true)
                {
                    checkingcheck = checkingcheck + 1;
                }
            }
            count_pdf();
            if (checkingcheck > 1)
            {
                each_vol_count();
            }

            lblfiles.Text = dataGridView1.Rows.Count.ToString();
            lblpubnodet.Text = txtpubno.Text.ToString();
            lblrelno.Text = txtrelno.Text.ToString();
            txtpagepath.Text = whole_path.ToString();
            lbltotalpage.Text = whole_pdf_count.ToString();


            if ((Convert.ToInt16(lbltotalpage.Text) > 1850) && (cmbtype.SelectedIndex == 1))
            {
                lblnote.Text = "Page exceeded 1850. Check for possible Flowbie Packages";
            }
            else
            {
                lblnote.Text = "NONE";
            }

            newfolder_copyfiles();
            MessageBox.Show("PDF Files has been renumbered successfully." + Environment.NewLine + Environment.NewLine + "Please check the following items before proceeding to clear:" + Environment.NewLine + "- PDF FILES COMPLETENESS" + Environment.NewLine + "- PDF FILES SEQUENCE" + Environment.NewLine + "- ZIP FILE NAMING CONVENTION", "PDF Sorted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            hasfmv = false;
            current_pagecount = 0;
        }
        public void auto_number_file()
        {
            string new_name, fle, new_path;
            int counter = 1;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                fle = row.Cells[1].Value.ToString();
                if (counter < 10)
                {
                    new_name = "00" + counter + "-" + Path.GetFileName(fle);
                    Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                    new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                    row.Cells[1].Value = new_path + @"\" + new_name;
                    //dataGridView1.Refresh();
                }
                else if (counter < 100)
                {
                    new_name = "0" + counter + "-" + Path.GetFileName(fle);
                    Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                    new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                    row.Cells[1].Value = new_path + @"\" + new_name;
                    //dataGridView1.Refresh();
                }
                else
                {
                    new_name = counter + "-" + Path.GetFileName(fle);
                    Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                    new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                    row.Cells[1].Value = new_path + @"\" + new_name;
                    //dataGridView1.Refresh();
                }
                counter += 1;
            }
            dataGridView1.Refresh();
            count_pdf();
            unnumber_file();
        }
        public void unnumber_file()
        {
            try
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    string removedname, renamed, new_rename;
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        renamed = row.Cells[1].Value.ToString();
                        removedname = Path.GetFileName(renamed).Remove(0, 4);

                        //MessageBox.Show(Path.GetFileName(renamed).Substring(0, 5));
                        new_rename = Path.GetFileName(renamed).Substring(0, 5);

                        //get the 5 first letters and identify if 5  is a DIGIT , if YES = do not renumber, 
                        //NO = removed the first 4
                        Boolean result = new_rename.All(Char.IsLetterOrDigit);
                        if (result == true)
                        {
                            //MessageBox.Show("All DIGIT");
                        }
                        else
                        {
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(renamed, removedname);
                            new_rename = Path.GetDirectoryName(renamed);
                            row.Cells[1].Value = new_rename + @"\" + removedname;
                            //MessageBox.Show("Not All Digit");
                        }
                    }
                    //MessageBox.Show("Sorting Prefixes has been removed");
                    txtpubno.Text = lblpubnodet.Text;
                }
                else
                {
                    MessageBox.Show("List is empty. Unable to remove numbered PDF", "Empty List", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch { }
        }

        public void each_vol_count()
        {
            int version = 0;
            int totalpage = 0;
            int dgtotal = dataGridView1.Rows.Count;

            if (cmbtype.SelectedIndex == 1)
            {
                each_vol_looseleaf_count();
            }
            else
            {
                delete_pkg_txtfile();
                foreach (DataGridViewRow row_per in dataGridView1.Rows)
                {
                    int curidx = row_per.Index;
                    //new added: || (row_per.Index == 0 && (Convert.ToBoolean(row_per.Cells["ColCheck"].Value) == false))
                    if (Convert.ToBoolean(row_per.Cells["ColCheck"].Value) == true || (row_per.Index == 0 && (Convert.ToBoolean(row_per.Cells["ColCheck"].Value) == false)))
                    {
                        version = version + 1;
                        //totalpage  = 0; //NEW ADDED
                        string filename_text = txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_v" + version + ".txt";
                        string path = "";
                        if (rbtJdrive.Checked == true)
                        {
                            path = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\" + filename_text;
                        }
                        else
                        {
                            //path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + filename_text; // Location in  J Drive: + JRS + vat + pub number
                            path = @txtlocpath.Text + @"\" + filename_text;
                        }


                        if (!File.Exists(path))
                        {
                            File.Create(path).Dispose();
                            using (TextWriter tw = new StreamWriter(path))
                            {
                                tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                                string current_loc = row_per.Cells[1].Value.ToString();
                                string ppath = @current_loc;
                                PdfReader pdfReader = new PdfReader(ppath);
                                int numberOfPages = pdfReader.NumberOfPages;
                                pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  
                                                   //NEW ADDED
                                                   //tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                                   //totalpage = totalpage + numberOfPages;
                                                   //NEW ADDED
                                int nextrow = row_per.Index + 1;
                                if (nextrow < dgtotal)
                                {
                                    if (Convert.ToBoolean(dataGridView1.Rows[nextrow].Cells["ColCheck"].Value) == true)
                                    {
                                        tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                        totalpage = totalpage + numberOfPages;
                                        tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                        totalpage = 0;
                                        tw.Close();
                                    }
                                    else
                                    {
                                        tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                        totalpage = totalpage + numberOfPages;
                                        tw.Close();
                                    }

                                    //tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString()); //NEW ADDED
                                    //tw.Close();
                                }
                                else if (nextrow == dgtotal)
                                {
                                    tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                    totalpage = totalpage + numberOfPages;
                                    tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                    tw.Close();
                                }
                                //NEW ADDED: above
                            }
                        }

                        else
                        {
                            //File.Delete(path); //NEW ADDED
                            File.Create(path).Dispose();
                            using (TextWriter tw = new StreamWriter(path))
                            {
                                tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                                string current_loc = row_per.Cells[1].Value.ToString();
                                string ppath = @current_loc;
                                PdfReader pdfReader = new PdfReader(ppath);
                                int numberOfPages = pdfReader.NumberOfPages;
                                pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                                tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                totalpage = totalpage + numberOfPages;
                                tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString()); //NEW ADDED
                                totalpage = 0; //NEW ADDED
                                tw.Close();
                            }
                        }
                    }
                    else
                    {
                        //int totalpage = 0;
                        string filename_text = txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_v" + version + ".txt";
                        string path = "";
                        if (rbtJdrive.Checked == true)
                        {
                            path = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\" + filename_text;
                        }
                        else
                        {
                            // path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + filename_text; // Location in  J Drive: + JRS + vat + pub number
                            path = @txtlocpath.Text + @"\" + filename_text;
                        }

                        using (TextWriter tw = new StreamWriter(path, true))
                        //using (StreamWriter sw = File.AppendText("c:/file.txt"));
                        {
                            //tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                            string current_loc = row_per.Cells[1].Value.ToString();
                            string ppath = @current_loc;
                            PdfReader pdfReader = new PdfReader(ppath);
                            int numberOfPages = pdfReader.NumberOfPages;

                            pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  
                                               //tw.Close();
                            curidx = curidx + 1;
                            if (curidx < dgtotal)
                            {
                                if (Convert.ToBoolean(dataGridView1.Rows[curidx].Cells["ColCheck"].Value) == true)
                                {
                                    tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                    totalpage = totalpage + numberOfPages;
                                    tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                    totalpage = 0;
                                    tw.Close();
                                }
                                else
                                {
                                    tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                    totalpage = totalpage + numberOfPages;

                                    tw.Close();
                                }
                            }
                            else if (curidx == dgtotal)
                            {
                                tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                totalpage = totalpage + numberOfPages;
                                tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                tw.Close();
                            }
                        }
                    }
                }
            }
        }
        public void each_vol_looseleaf_count()
        {
            delete_pkg_txtfile();
            int version = 0;
            int totalpage = 0;
            int dgtotal = dataGridView1.Rows.Count;
            bool pu_added = false, fi_added = false;
            has_flowbie = true;

            foreach (DataGridViewRow row_per in dataGridView1.Rows)
            {

                int curidx = row_per.Index;
                if (row_per.Cells[1].Value.ToString().Contains("pubup") || row_per.Cells[1].Value.ToString().Contains(txtpubno.Text.ToString() + "-fi"))
                {
                }
                else if (Convert.ToBoolean(row_per.Cells["ColCheck"].Value) == true) // || (row_per.Index == 0 && (Convert.ToBoolean(row_per.Cells["ColCheck"].Value) == false)))
                {
                    version = version + 1;
                    //totalpage  = 0; //NEW ADDED
                    string filename_text = txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_PKG" + version + ".txt";
                    string path = "";
                    if (rbtJdrive.Checked == true)
                    {
                        path = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\" + filename_text;
                    }
                    else
                    {
                        path = @txtlocpath.Text + @"\" + filename_text;
                    }

                    if (!File.Exists(path))
                    {
                        File.Create(path).Dispose();
                        using (TextWriter tw = new StreamWriter(path))
                        {
                            tw.WriteLine("Page" + "\t" + "Filename" + "\n");

                            if (pu_added == false)
                            {
                                tw.WriteLine("\n" + flowbie_pu_count.ToString() + "\t" + flowbie_pu);
                                pu_added = true;
                                totalpage = totalpage + flowbie_pu_count;
                            }
                            if (fi_added == false)
                            {
                                tw.WriteLine("\n" + flowbie_fi_count.ToString() + "\t" + flowbie_fi);
                                fi_added = true;
                                totalpage = totalpage + flowbie_fi_count;
                            }

                            string current_loc = row_per.Cells[1].Value.ToString();
                            string ppath = @current_loc;
                            PdfReader pdfReader = new PdfReader(ppath);
                            int numberOfPages = pdfReader.NumberOfPages;
                            pdfReader.Close();

                            int nextrow = row_per.Index + 1;
                            if (nextrow < dgtotal)
                            {
                                if (Convert.ToBoolean(dataGridView1.Rows[nextrow].Cells["ColCheck"].Value) == true)
                                {
                                    tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                    totalpage = totalpage + numberOfPages;
                                    tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                    totalpage = 0;
                                    tw.Close();
                                }
                                else
                                {
                                    tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                    totalpage = totalpage + numberOfPages;
                                    tw.Close();
                                }
                            }
                            else if (nextrow == dgtotal)
                            {
                                tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                totalpage = totalpage + numberOfPages;
                                tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                tw.Close();
                            }
                            //NEW ADDED: above
                        }
                    }

                    else
                    {
                        //File.Delete(path); //NEW ADDED
                        File.Create(path).Dispose();
                        using (TextWriter tw = new StreamWriter(path))
                        {
                            tw.WriteLine("Page" + "\t" + "Filename" + "\n");

                            if (pu_added == false)
                            {
                                tw.WriteLine("\n" + flowbie_pu_count.ToString() + "\t" + flowbie_pu);
                                pu_added = true;
                                totalpage = totalpage + flowbie_pu_count;
                            }
                            if (fi_added == false)
                            {
                                tw.WriteLine("\n" + flowbie_fi_count.ToString() + "\t" + flowbie_fi);
                                fi_added = true;
                                totalpage = totalpage + flowbie_fi_count;
                            }

                            string current_loc = row_per.Cells[1].Value.ToString();
                            string ppath = @current_loc;
                            PdfReader pdfReader = new PdfReader(ppath);
                            int numberOfPages = pdfReader.NumberOfPages;
                            pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                            tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                            totalpage = totalpage + numberOfPages;
                            tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString()); //NEW ADDED
                            totalpage = 0; //NEW ADDED
                            tw.Close();
                        }
                    }
                }

                else
                {
                    //int totalpage = 0;
                    string filename_text = txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_PKG" + version + ".txt";
                    string path = "";
                    if (rbtJdrive.Checked == true)
                    {
                        path = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\" + filename_text;
                    }
                    else
                    {
                        // path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + filename_text; // Location in  J Drive: + JRS + vat + pub number
                        path = @txtlocpath.Text + @"\" + filename_text;
                    }

                    using (TextWriter tw = new StreamWriter(path, true))
                    //using (StreamWriter sw = File.AppendText("c:/file.txt"));
                    {
                        //tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                        string current_loc = row_per.Cells[1].Value.ToString();
                        string ppath = @current_loc;
                        PdfReader pdfReader = new PdfReader(ppath);
                        int numberOfPages = pdfReader.NumberOfPages;

                        pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  
                                           //tw.Close();
                        curidx = curidx + 1;
                        if (curidx < dgtotal)
                        {
                            if (Convert.ToBoolean(dataGridView1.Rows[curidx].Cells["ColCheck"].Value) == true)
                            {
                                tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                totalpage = totalpage + numberOfPages;
                                tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                totalpage = 0;
                                tw.Close();
                            }
                            else
                            {
                                tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                totalpage = totalpage + numberOfPages;

                                tw.Close();
                            }
                        }
                        else if (curidx == dgtotal)
                        {
                            tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                            totalpage = totalpage + numberOfPages;
                            tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                            tw.Close();
                        }
                    }
                }
            }
        }

        public void count_pdf()
        {
            //NEW ADDED
            delele_txtfiles();
            try
            {

                if (txtpubno.Text == "")
                {
                    txtpubno.Text = Path.GetFileName(Path.GetDirectoryName(dataGridView1.SelectedCells[1].Value.ToString()));
                }
                int totalpage = 0;
                string filename_text = txtpubno.Text + "_" + txtrelno.Text + ".txt";
                string path = "";
                if (rbtJdrive.Checked == true)
                {
                    path = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\" + filename_text;
                }
                else
                {
                    //path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + filename_text; // Location in  J Drive: + JRS + vat + pub number
                    path = @txtlocpath.Text + @"\" + filename_text;
                }

                whole_path = path.ToString();

                if (!File.Exists(path))
                {
                    File.Create(path).Dispose();
                    using (TextWriter tw = new StreamWriter(path))
                    {
                        tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                        foreach (DataGridViewRow paths in dataGridView1.Rows)
                        {
                            string current_loc = paths.Cells[1].Value.ToString();
                            string ppath = @current_loc;
                            PdfReader pdfReader = new PdfReader(ppath);
                            int numberOfPages = pdfReader.NumberOfPages;

                            pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                            tw.WriteLine(numberOfPages + "\t" + Path.GetFileName(current_loc) + "\n");

                            if (paths.Cells[1].Value.ToString().Contains("pubup"))
                            {
                                flowbie_pu = Path.GetFileName(current_loc);
                                flowbie_pu_count = numberOfPages;
                            }
                            if (paths.Cells[1].Value.ToString().Contains(txtpubno.Text.ToString() + "-fi"))
                            {
                                flowbie_fi = Path.GetFileName(current_loc);
                                flowbie_fi_count = numberOfPages;
                            }

                            totalpage = totalpage + numberOfPages;

                            paths.Cells[2].Value = numberOfPages;
                        }
                        tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                        tw.Close();
                    }
                }

                else if (File.Exists(path))
                {
                    using (TextWriter tw = new StreamWriter(path))
                    {
                        tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                        foreach (DataGridViewRow paths in dataGridView1.Rows)
                        {
                            string current_loc = paths.Cells[1].Value.ToString();
                            string ppath = @current_loc;
                            PdfReader pdfReader = new PdfReader(ppath);
                            int numberOfPages = pdfReader.NumberOfPages;

                            pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                            tw.WriteLine(numberOfPages + "\t" + Path.GetFileName(current_loc) + "\n");

                            if (paths.Cells[1].Value.ToString().Contains("pubup"))
                            {
                                flowbie_pu = Path.GetFileName(current_loc);
                                flowbie_pu_count = numberOfPages;
                            }
                            if (paths.Cells[1].Value.ToString().Contains(txtpubno.Text.ToString() + "-fi"))
                            {
                                flowbie_fi = Path.GetFileName(current_loc);
                                flowbie_fi_count = numberOfPages;
                            }

                            totalpage = totalpage + numberOfPages;
                            paths.Cells[2].Value = numberOfPages;
                        }
                        tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                        tw.Close();
                    }
                }
                whole_pdf_count = whole_pdf_count + totalpage;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        public void delele_txtfiles()
        {
            try
            {
                //string filename_text = txtpubno.Text + "_" + txtrelno.Text + ".txt";
                string path = "";
                if (rbtJdrive.Checked == true)
                {
                    path = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\";
                }
                else
                {
                    //path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\";//+ filename_text; // Location in  J Drive: + JRS + vat + pub number
                    path = @txtlocpath.Text + @"\";
                }

                foreach (string fInfo in Directory.GetFiles(path))
                {
                    if (fInfo.Contains(txtpubno.Text + "_" + txtrelno.Text))
                    {
                        //MessageBox.Show("File found");
                        File.Delete(fInfo);
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        public void delete_pkg_txtfile()
        {
            //string filename_text = txtpubno.Text + "_" + txtrelno.Text + ".txt";
            string path = "";
            if (rbtJdrive.Checked == true)
            {
                path = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\";
            }
            else
            {
                //path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\";//+ filename_text; // Location in  J Drive: + JRS + vat + pub number
                path = @txtlocpath.Text + @"\";
            }

            foreach (string fInfo in Directory.GetFiles(path))
            {
                if (fInfo.Contains(txtpubno.Text + "_" + txtrelno.Text) || fInfo.Contains(txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_PKG") || fInfo.Contains(txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_v"))
                {
                    //MessageBox.Show("File found");
                    File.Delete(fInfo);
                }
            }
        }
        public void newfolder_copyfiles()
        {
            try
            {
                string pack_name, pack_type, path_newfile;
                int check_count = 0;
                int folderno = 0;
                foreach (DataGridViewRow cpy in dataGridView1.Rows)
                {
                    if (Convert.ToBoolean(cpy.Cells[0].Value.ToString()) == true)
                    {
                        check_count = check_count + 1;
                    }
                }

                if (check_count > 1)
                {
                    pack_name = "PKG";
                }
                else
                {
                    pack_name = "";
                }
                if (chksupp.Checked == true)
                {
                    pack_type = "T";
                }
                else
                {
                    pack_type = "T";
                }

                if (cmbtype.SelectedIndex == 1) //check if Process will be Looseleaf
                {
                    //////////////////////////// NEW ADDED
                    if (chkautozipflowbie.Checked == true)
                    {
                        has_flowbie = true;
                        flowbie_ll();
                    }
                    else
                    {
                        has_flowbie = true;
                        flowbie_manual();
                    }
                    ////////////////////////////
                }
                else
                {
                    foreach (DataGridViewRow cpy in dataGridView1.Rows)
                    {
                        int cpyidx = cpy.Index;
                        if (cpyidx == 0)
                        {
                            folderno = folderno + 1;
                            if (check_count > 1)
                            {
                                path_newfile = folderno + "_" + "x";
                            }
                            else
                            {
                                path_newfile = "_" + "x";
                            }

                            string targetPath = @Path.GetDirectoryName(cpy.Cells[1].Value.ToString()) + @"\For Clear\" + pack_type + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + pack_name + path_newfile;
                            if (!Directory.Exists(targetPath))
                            {
                                Directory.CreateDirectory(targetPath);
                            }
                            else
                            {
                                Directory.Delete(targetPath, true);
                                Directory.CreateDirectory(targetPath);
                            }
                            //Copy the file from sourcepath and place into mentioned target path, 
                            //Overwrite the file if same file is exist in target path
                            var srcPath = cpy.Cells[1].Value.ToString();
                            File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(cpy.Cells[1].Value.ToString()), targetPath), true);
                        }
                        else
                        {
                            if (Convert.ToBoolean(cpy.Cells[0].Value.ToString()) == true)
                            {
                                folderno = folderno + 1;
                                if (check_count > 1)
                                {
                                    path_newfile = folderno + "_" + "x";
                                }
                                else
                                {
                                    path_newfile = "_" + "x";
                                }

                                string targetPath = @Path.GetDirectoryName(cpy.Cells[1].Value.ToString()) + @"\For Clear\" + pack_type + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + pack_name + path_newfile;
                                if (!Directory.Exists(targetPath))
                                {
                                    Directory.CreateDirectory(targetPath);
                                }
                                else
                                {
                                    Directory.Delete(targetPath, true);
                                    Directory.CreateDirectory(targetPath);
                                }
                                //Copy the file from sourcepath and place into mentioned target path, 
                                //Overwrite the file if same file is exist in target path
                                var srcPath = cpy.Cells[1].Value.ToString();
                                File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(cpy.Cells[1].Value.ToString()), targetPath), true);
                                //MessageBox.Show(Path.GetDirectoryName(cpy.Cells[1].Value.ToString()));
                            }
                            else
                            {
                                if (check_count > 1)
                                {
                                    path_newfile = folderno + "_" + "x";
                                }
                                else
                                {
                                    path_newfile = "_" + "x";
                                }

                                string targetPath = @Path.GetDirectoryName(cpy.Cells[1].Value.ToString()) + @"\For Clear\" + pack_type + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + pack_name + path_newfile;
                                var srcPath = cpy.Cells[1].Value.ToString();
                                File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(cpy.Cells[1].Value.ToString()), targetPath), true);
                            }
                        }
                    }
                }

                zipped_files();
                whole_pdf_count = 0;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        public void flowbie_ll()
        {
            int totalpage1 = 0;
            int folderno1 = 1;
            string filename_text1 = txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + ".txt";
            string path1 = "", e_pkg = "";
            if (rbtJdrive.Checked == true)
            {
                path1 = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\" + filename_text1;
            }
            else
            {
                path1 = @txtlocpath.Text + @"\" + filename_text1;
            }

            if (has_flowbie == true)
            {
                e_pkg = "PKG1";
            }

            foreach (DataGridViewRow paths in dataGridView1.Rows)
            {
                string current_loc = paths.Cells[1].Value.ToString();
                string ppath = @current_loc;
                PdfReader pdfReader = new PdfReader(ppath);
                int numberOfPages = pdfReader.NumberOfPages;
                pdfReader.Close();
                totalpage1 = totalpage1 + numberOfPages;

                if ((paths.Index == 0 && paths.Cells[1].Value.ToString().Contains("-pubup")) || (paths.Index == 0 && paths.Cells[1].Value.ToString().Contains(txtpubno.Text + "-fi")))
                {
                    string targetPath = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "E" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text  + e_pkg + "_x";// + folderno1;
                    
                    if (!Directory.Exists(targetPath))
                    {
                        Directory.CreateDirectory(targetPath);
                    }
                    else
                    {
                        Directory.Delete(targetPath, true);
                        Directory.CreateDirectory(targetPath);
                    }
                    var srcPath = paths.Cells[1].Value.ToString();
                    File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath), true);


                    if (paths.Cells[1].Value.ToString().Contains(txtpubno.Text + "-fi"))
                    {
                        string flow_txt = txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_PKG" + folderno1 + ".txt";

                        string flow_path = "";
                        if (rbtJdrive.Checked == true)
                        {
                            flow_path = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\" + flow_txt;
                        }
                        else
                        {
                            flow_path = @txtlocpath.Text + @"\" + flow_txt;
                        }

                        string path11 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "E" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + e_pkg + "_x";
                        totalpage1 = 0;
                    }
                }
                else if (paths.Index > 0 && paths.Cells[1].Value.ToString().Contains(txtpubno.Text + "-fi"))
                {
                    string targetPath = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "E" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + e_pkg + "_x";
                    var srcPath = paths.Cells[1].Value.ToString();
                    File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath), true);
                    totalpage1 = 0;
                }

                //// FOR T Files below
                else
                {
                    string pack_name;
                    int pack_num = 0;
                    if (whole_pdf_count > 1850)
                    {
                        pack_name = "PKG";
                        pack_num = pack_num + 1;
                        

                        if (totalpage1 < 1850)
                        {
                            string targetPath1 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "T" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "PKG" + folderno1 + "_x";
                            if (!Directory.Exists(targetPath1))
                            {
                                Directory.CreateDirectory(targetPath1);
                            }
                            var srcPath = paths.Cells[1].Value.ToString();
                            File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath1), true);
                            //MessageBox.Show("Testing dor <1850");
                        }
                        else
                        {
                            int totalpage2 = 0;
                            string flow_txt1 = txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_PKG" + folderno1 + ".txt";

                            string flow_path1 = "";
                            if (rbtJdrive.Checked == true)
                            {
                                flow_path1 = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\" + flow_txt1;
                            }
                            else
                            {
                               //flow_path1 = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + flow_txt1; // Location in  J Drive: + JRS + vat + pub number
                                flow_path1 = @txtlocpath.Text + @"\" + flow_txt1;
                            }

                            string path111 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "T" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "PKG" + folderno1 + "_x";                                                                                                           //MessageBox.Show(path.ToString());
                                                                                                                                                                                                                                                                                                                       //{
                            File.Create(flow_path1).Dispose();
                            using (TextWriter tw = new StreamWriter(flow_path1))
                            {
                                tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                                foreach (string fInfo in Directory.GetFiles(path111))
                                {
                                    PdfReader pdfReader1 = new PdfReader(fInfo);
                                    int numberOfPages1 = pdfReader1.NumberOfPages;

                                    pdfReader1.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                                    tw.WriteLine(numberOfPages1 + "\t" + Path.GetFileName(fInfo) + "\n");
                                    totalpage2 = totalpage2 + numberOfPages1;
                                }
                                tw.WriteLine("\n" + Environment.NewLine + totalpage2.ToString());
                                tw.Close();
                            }

                            folderno1 = folderno1 + 1;
                            string targetPath1 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "T" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "PKG" + folderno1 + "_x";
                            if (!Directory.Exists(targetPath1))
                            {
                                Directory.CreateDirectory(targetPath1);
                            }
                            else
                            {
                                Directory.Delete(targetPath1, true);
                                Directory.CreateDirectory(targetPath1);
                            }
                            var srcPath = paths.Cells[1].Value.ToString();
                            File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath1), true);
                            totalpage1 = numberOfPages;
                        }

                        //FOR LAST FOLDER IN THE PATH
                        int lastpack = 0;
                        string lastfilename = txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_PKG" + folderno1 + ".txt";

                        string lastpath = "";
                        if (rbtJdrive.Checked == true)
                        {
                            lastpath = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\" + lastfilename;
                        }
                        else
                        {
                            //lastpath = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + lastfilename; // Location in  J Drive: + JRS + vat + pub number
                            lastpath = @txtlocpath.Text + @"\" + lastfilename;
                        }

                        string lastfolder = @txtgetpubno.Text + @"\For Clear\" + "T" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "PKG" + folderno1 + "_x";                                                                                                         //MessageBox.Show(path.ToString());
                                                                                                                                                                                                                                                                              //{
                        File.Create(lastpath).Dispose();
                        using (TextWriter tw = new StreamWriter(lastpath))
                        {
                            tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                            foreach (string fInfo in Directory.GetFiles(lastfolder))
                            {
                                PdfReader pdfReader2 = new PdfReader(fInfo);
                                int numberOfPages2 = pdfReader2.NumberOfPages;

                                pdfReader2.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                                tw.WriteLine(numberOfPages2 + "\t" + Path.GetFileName(fInfo) + "\n");
                                lastpack = lastpack + numberOfPages2;

                            }
                            tw.WriteLine("\n" + Environment.NewLine + lastpack.ToString());
                            tw.Close();
                        }
                    }
                    // FOR LL WITHOUT FLOWBIE
                    else
                    {
                        pack_name = "";
                        pack_num = 0;

                        string targetPath1 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "T" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_x";
                        if (!Directory.Exists(targetPath1))
                        {
                            Directory.CreateDirectory(targetPath1);
                        }
                        var srcPath = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath1), true);
                        //MessageBox.Show("Testing dor <1850");
                    }
                }
            }
        }
        public void flowbie_manual()
        {
            int pack_num = 0;
            string pack_name;
            int totalpage1 = 0;
            int folderno1 = 1;
            string filename_text1 = txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + ".txt";
            string path1 = "", e_pkg = ""; ;
            if (rbtJdrive.Checked == true)
            {
                path1 = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\" + filename_text1;
            }
            else
            {
                //path1 = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + filename_text1; // Location in  J Drive: + JRS + vat + pub number
                path1 = @txtlocpath.Text + @"\" + filename_text1;
            }

            int check_counter = 0;
            foreach (DataGridViewRow chkbox in dataGridView1.Rows)
            {
                if (Convert.ToBoolean(chkbox.Cells[0].Value) == true)
                {
                    check_counter = check_counter + 1;
                }
            }

            if (check_counter > 0)
            {
                pack_name = "PKG";
                e_pkg = "PKG1";

            }
            else
            {
                pack_name = ""; e_pkg = null;
            }
            

            foreach (DataGridViewRow paths in dataGridView1.Rows)
            {
                string current_loc = paths.Cells[1].Value.ToString();
                string ppath = @current_loc;
                PdfReader pdfReader = new PdfReader(ppath);
                int numberOfPages = pdfReader.NumberOfPages;
                pdfReader.Close();
                totalpage1 = totalpage1 + numberOfPages;

                //MessageBox.Show(totalpage1.ToString());

                if ((paths.Index == 0 && paths.Cells[1].Value.ToString().Contains("-pubup")) || (paths.Index == 0 && paths.Cells[1].Value.ToString().Contains(txtpubno.Text + "-fi")))
                {
                    //folderno1 = folderno1 + 1;
                    if (has_flowbie == true )
                    {
                        string targetPath = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "E" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + e_pkg + "_x";// + folderno1;
                        if (!Directory.Exists(targetPath))
                        {
                            Directory.CreateDirectory(targetPath);
                        }
                        else
                        {
                            Directory.Delete(targetPath, true);
                            Directory.CreateDirectory(targetPath);
                        }
                        var srcPath = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath), true);
                    }
                    else
                    {
                        string targetPath = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "E" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_x";// + folderno1;
                        if (!Directory.Exists(targetPath))
                        {
                            Directory.CreateDirectory(targetPath);
                        }
                        else
                        {
                            Directory.Delete(targetPath, true);
                            Directory.CreateDirectory(targetPath);
                        }
                        var srcPath = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath), true);
                    }
                }
                else if (paths.Index > 0 && paths.Cells[1].Value.ToString().Contains(txtpubno.Text + "-fi"))
                {
                    if (has_flowbie == true)
                    {
                        string targetPath = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "E" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + e_pkg + "_x";
                        var srcPath = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath), true);
                        //totalpage1 = 0;
                    }
                    else
                    {
                        string targetPath = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "E" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + "_x";
                        var srcPath = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath), true);
                        //totalpage1 = 0;
                    }
                }
                //// FOR T Files below ///////////////////////////////////////////////////////////
                else if (((paths.Cells[1].Value.ToString().Contains("fmv") || paths.Cells[1].Value.ToString().Contains("ptoc") || paths.Index > 1) && Convert.ToBoolean(paths.Cells[0].Value) == true))
                {
                    if (check_counter > 0)
                    {
                        pack_num = pack_num + 1;
                        string targetPath1 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "T" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + pack_name + pack_num + "_x";
                        if (!Directory.Exists(targetPath1))
                        {
                            Directory.CreateDirectory(targetPath1);
                        }
                        var srcPath1 = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath1, srcPath1.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath1), true);
                    }
                    else
                    {
                        string targetPath1 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "T" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + pack_name + "_x";
                        if (!Directory.Exists(targetPath1))
                        {
                            Directory.CreateDirectory(targetPath1);
                        }
                        var srcPath1 = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath1, srcPath1.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath1), true);
                    }
                }
                else
                {
                    if (check_counter > 0)
                    {
                        string targetPath12 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "T" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + pack_name + pack_num + "_x";
                        if (!Directory.Exists(targetPath12))
                        {
                            Directory.CreateDirectory(targetPath12);
                        }
                        var srcPath1 = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath1, srcPath1.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath12), true);
                    }
                    else
                    {

                        string targetPath12 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + "T" + txtpubno.Text.TrimStart('0') + "_" + txtrelno.Text + pack_name + "_x";
                        if (!Directory.Exists(targetPath12))
                        {
                            Directory.CreateDirectory(targetPath12);
                        }
                        var srcPath1 = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath1, srcPath1.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath12), true);
                    }
                }
            }
            has_flowbie = false;
            e_pkg = "";
        }

        public void ll_numbering()
        {
            richTextBox1.Text = string.Join(Environment.NewLine, richTextBox1.Lines.Distinct());
            String perrow = richTextBox1.Text;
            int dg = dataGridView1.Rows.Count;

            if (dg > 0)
            {
                if (MessageBox.Show("Current Items in Grid will be remove and new one will be loaded", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    dataGridView1.Rows.Clear();
                    load_LL();
                }
            }
            else
            {
                load_LL();
            }
        }
        public void ll_numbering_2_pasted()
        {
            richTextBox2.Text = string.Join(Environment.NewLine, richTextBox2.Lines.Distinct());
            String perrow = richTextBox2.Text;
            int dg = dataGridView1.Rows.Count;

            if (dg > 0)
            {
                if (MessageBox.Show("Current Items in Grid will be remove and new one will be loaded", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    dataGridView1.Rows.Clear();
                    load_LL_pasted();
                }
            }
            else
            {
                load_LL_pasted();
            }
        }

        public void load_LL()
        {
            string flenme;
            foreach (string str in richTextBox1.Lines)
            {
                if (str.Contains("pubup"))
                {
                    //flenme = txtpubno.Text + "_" + txtpubno.Text + "-" + "pubup" + ".pdf";

                    DirectoryInfo d = new DirectoryInfo(txtlocpath.Text);//Assuming Test is your Folder
                    FileInfo[] Files = d.GetFiles("*.pdf"); //Getting Text files
                    //string file_in_Path = "";
                    foreach (FileInfo file in Files)
                    {
                        //file_in_Path = file_in_Path + ", " + file.Name;
                        //MessageBox.Show(file.ToString());
                        string loc_fille = file.ToString();
                        if (loc_fille.Contains(txtpubno.Text + "_" + txtpubno.Text + "-" + "pubup"))
                        {
                            dataGridView1.Rows.Add(1, @txtgetpubno.Text + @"\" + loc_fille.ToString());
                            foreach (DataGridViewRow check_row in dgvafilist.Rows)
                            {
                                if (str == check_row.Cells[0].Value.ToString())
                                {
                                    check_row.Cells[1].Value = "PDF FOUND";
                                }
                            }
                        }
                    }
                }
                else if (str.Contains("filing"))
                {
                    //flenme = txtpubno.Text + "_" + txtpubno.Text + "-" + "fi" + ".pdf";

                    DirectoryInfo d = new DirectoryInfo(txtlocpath.Text);//Assuming Test is your Folder
                    FileInfo[] Files = d.GetFiles("*.pdf"); //Getting Text files
                    //string file_in_Path = "";
                    foreach (FileInfo file in Files)
                    {
                        //file_in_Path = file_in_Path + ", " + file.Name;
                        //MessageBox.Show(file.ToString());
                        string loc_fille = file.ToString();
                        if (loc_fille.Contains(txtpubno.Text + "_" + txtpubno.Text + "-" + "fi"))
                        {
                            dataGridView1.Rows.Add(1, @txtgetpubno.Text + @"\" + loc_fille.ToString());
                            foreach (DataGridViewRow check_row in dgvafilist.Rows)
                            {
                                if (str == check_row.Cells[0].Value.ToString())
                                {
                                    check_row.Cells[1].Value = "PDF FOUND";
                                }
                            }
                        }
                    }
                }
                else
                {
                    flenme = txtpubno.Text + "_" + str + ".pdf";
                    if (File.Exists(@txtgetpubno.Text + @"\" + flenme))
                    {
                        dataGridView1.Rows.Add(1, @txtgetpubno.Text + @"\" + flenme.ToString());
                        foreach (DataGridViewRow check_row in dgvafilist.Rows)
                        {
                            if (str == check_row.Cells[0].Value.ToString())
                            {
                                check_row.Cells[1].Value = "PDF FOUND";
                            }
                        }
                    }
                    else
                    { //MessageBox.Show("not found");
                    }
                }
            }
            // uncheck all check column when pdf are loaded
            foreach (DataGridViewRow rowchk in dataGridView1.Rows)
            {
                Convert.ToBoolean(rowchk.Cells["ColCheck"].Value = false);
            }
            //highlight missing
            foreach (DataGridViewRow missing_row in dgvafilist.Rows)
            {
                if (missing_row.Cells[1].Value.ToString() == "")
                {
                    missing_row.DefaultCellStyle.BackColor = Color.IndianRed;
                }
            }
            count_first();
        }
        public void load_LL_pasted()
        {
            string flenme;
            foreach (string str in richTextBox2.Lines)
            {
                if (str.Contains("pubup"))
                {
                    //flenme = txtpubno.Text + "_" + txtpubno.Text + "-" + "pubup" + ".pdf";

                    DirectoryInfo d = new DirectoryInfo(txtlocpath.Text);//Assuming Test is your Folder
                    FileInfo[] Files = d.GetFiles("*.pdf"); //Getting Text files
                    //string file_in_Path = "";
                    foreach (FileInfo file in Files)
                    {
                        //file_in_Path = file_in_Path + ", " + file.Name;
                        //MessageBox.Show(file.ToString());
                        string loc_fille = file.ToString();
                        if (loc_fille.Contains(txtpubno.Text + "_" + txtpubno.Text + "-" + "pubup"))
                        {
                            dataGridView1.Rows.Add(1, @txtgetpubno.Text + @"\" + loc_fille.ToString());
                            foreach (DataGridViewRow check_row in dgvafilist.Rows)
                            {
                                if (str == check_row.Cells[0].Value.ToString())
                                {
                                    check_row.Cells[1].Value = "PDF FOUND";
                                }
                            }
                        }
                    }
                }
                else if (str.Contains("filing"))
                {
                    //flenme = txtpubno.Text + "_" + txtpubno.Text + "-" + "fi" + ".pdf";

                    DirectoryInfo d = new DirectoryInfo(txtlocpath.Text);//Assuming Test is your Folder
                    FileInfo[] Files = d.GetFiles("*.pdf"); //Getting Text files
                    //string file_in_Path = "";
                    foreach (FileInfo file in Files)
                    {
                        //file_in_Path = file_in_Path + ", " + file.Name;
                        //MessageBox.Show(file.ToString());
                        string loc_fille = file.ToString();
                        if (loc_fille.Contains(txtpubno.Text + "_" + txtpubno.Text + "-" + "fi"))
                        {
                            dataGridView1.Rows.Add(1, @txtgetpubno.Text + @"\" + loc_fille.ToString());
                            foreach (DataGridViewRow check_row in dgvafilist.Rows)
                            {
                                if (str == check_row.Cells[0].Value.ToString())
                                {
                                    check_row.Cells[1].Value = "PDF FOUND";
                                }
                            }
                        }
                    }
                }
                else
                {
                    flenme = txtpubno.Text + "_" + str + ".pdf";
                    if (File.Exists(@txtgetpubno.Text + @"\" + flenme))
                    {
                        dataGridView1.Rows.Add(1, @txtgetpubno.Text + @"\" + flenme.ToString());
                        foreach (DataGridViewRow check_row in dgvafilist.Rows)
                        {
                            if (str == check_row.Cells[0].Value.ToString())
                            {
                                check_row.Cells[1].Value = "PDF FOUND";
                            }
                        }
                    }
                    else
                    { //MessageBox.Show("not found");
                    }
                }
            }
            // uncheck all check column when pdf are loaded
            foreach (DataGridViewRow rowchk in dataGridView1.Rows)
            {
                Convert.ToBoolean(rowchk.Cells["ColCheck"].Value = false);
            }
            //highlight missing
            /*foreach (DataGridViewRow missing_row in dgvafilist.Rows)
            {
                if (missing_row.Cells[1].Value.ToString() == "")
                {
                    missing_row.DefaultCellStyle.BackColor = Color.IndianRed;
                }
            }*/
            count_first();
        }

        private void FormLocal_Load(object sender, EventArgs e)
        {
            cmbtype.SelectedIndex = 0;
            rbtJdrive.Checked = true;
        }
        private void SELECT_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtlocpath.Text) && String.IsNullOrEmpty(txtsearchpub.Text))
            {
                MessageBox.Show("Please provide the location of your PDF files or enter the 5 Digit Pub Number", "No path provided.", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(txtlocpath.Text) && txtsearchpub.Text.ToString().Length < 5)
            {
                MessageBox.Show("Please enter the 5 Digit Pub Number", "Use 5 Digit Pub Number", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if ((String.IsNullOrEmpty(txtlocpath.Text) && Convert.ToInt64(txtsearchpub.Text) > 0))
                {
                    txtlocpath.Clear();
                    txtlocpath.Text = @"\\fabwebd5.net\pclprod\NeptuneUS\pdf\" + txtsearchpub.Text;
                }
                else
                {
                    int fdcount = 0;
                    fdcount = dataGridView1.Rows.Count;
                    if (fdcount > 0)
                    {
                        if (MessageBox.Show("Current Items in ListBox will be removed", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            txtpubno.Clear();
                            txtrelno.Clear();
                            dataGridView1.Rows.Clear();
                            Browse_file();
                        }
                        else
                        {
                            //Browse_file()
                        }
                    }
                    else
                    {
                        Browse_file();
                    }
                }
            }
        }
        public void Browse_file()
        {
            OpenFileDialog fd = new OpenFileDialog();
            string strFileName = null;
            string pubno = txtpubno.Text;
            string relno = txtrelno.Text;
            //int estpages, actpages;
            int x;

            //if (txtpubno.Text.Count() < 5)
            //{
            //    MessageBox.Show("Please enter the 5 Digit Pub Number");
            //}
            //else
            //{
                if (Directory.Exists(txtlocpath.Text))
                {
                    fd.Title = "Select PDF files";
                    fd.InitialDirectory = txtlocpath.Text;
                    fd.Filter = "PDF files (*.*)|*.pdf";
                    //PDF files (*.*)|*.*|
                    fd.FilterIndex = 2;
                    fd.Multiselect = true;
                    fd.RestoreDirectory = false;

                    if (fd.ShowDialog() == DialogResult.OK)
                    {
                        //if ((Path.GetDirectoryName(fd.FileName).Substring(0, 5) != txtpubno.Text)) //fd.InitialDirectory
                        //{
                        //    MessageBox.Show("Selected path do not matched the Pub Number entered");
                        //}
                        //else
                        //{
                            for (x = 0; x <= fd.FileNames.Count() - 1; x++)
                            {
                                dataGridView1.Rows.Add(1, fd.FileNames[x].ToString());
                            }
                            strFileName = fd.FileName;

                        //}


                    txtlocpath.Text = Path.GetDirectoryName(fd.FileName);

                    lblpubnodet.Text = Path.GetFileName(fd.FileName).Substring(0, 5).ToString(); //OR
                    //lblpubnodet.Text = Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Substring(Convert.ToInt32(Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Length) - 5, 5).ToString();

                    string pubno_holder = Path.GetFileName(fd.FileName).Substring(3, 1);
                    //MessageBox.Show(pubno_holder.ToString());

                    if (pubno_holder.ToString() == "-")
                    {
                        txtpubno.Text = Path.GetFileName(fd.FileName).Substring(4, 5); // OR
                    }
                    else
                    {
                        txtpubno.Text = Path.GetFileName(fd.FileName).Substring(0, 5); // OR
                                                                                       //txtpubno.Text = Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Substring(Convert.ToInt32(Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Length) - 5, 5).ToString();
                    }
                    txtgetpubno.Text = Path.GetDirectoryName(fd.FileName); // OR
                    //txtgetpubno.Text = Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Substring(Convert.ToInt32(Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Length) - 5, 5).ToString();

                }
                // uncheck all check column when pdf are loaded
                foreach (DataGridViewRow rowchk in dataGridView1.Rows)
                    {
                        Convert.ToBoolean(rowchk.Cells["ColCheck"].Value = false);
                    }
                }
                else
                {
                    MessageBox.Show("Path not found. Please verify the specified path", "Unable to Locate Path.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtpubno.Clear();
                txtrelno.Clear();
                dataGridView1.Rows.Clear();
                }
            dataGridView1.Columns[0].Visible = true;
            dataGridView1.ClearSelection();
            lblfiles.Text = dataGridView1.Rows.Count.ToString();
            lblpubnodet.Text = txtpubno.Text.ToString();
            lblrelno.Text = txtrelno.Text.ToString();
            lbltotalpage.Text = "0";

            count_first();
            ///txtpubno.Text = Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Substring(Convert.ToInt32(Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Length) - 5, 5).ToString();

            //}
        }

        private void txtpubno_TextChanged(object sender, EventArgs e)
        {
            lblpubnodet.Text = txtpubno.Text;
            //long a;
            //if (!long.TryParse(txtpubno.Text, out a))
            //{
            //    // If not int clear textbox text or Undo() last operation
            //    txtpubno.Clear();
            //}
            if (txtpubno.Text == "" || txtrelno.Text == "")
            {
                /*btnnumber.Enabled = false;
                btnfirst.Enabled = false;
                btnup.Enabled = false;
                btndown.Enabled = false;
                btnlast.Enabled = false;
                */
                cmbtype.Enabled = false;

            }
            else
            {
                /*btnnumber.Enabled = true;
                btnfirst.Enabled = true;
                btnup.Enabled = true;
                btndown.Enabled = true;
                btnlast.Enabled = true;
                */
                cmbtype.Enabled = true;
            } 

            txtgetpubno.Text = txtlocpath.Text;
            
        }
        private void txtrelno_TextChanged(object sender, EventArgs e)
        {
            if (txtpubno.Text == "" || txtrelno.Text == "")
            {
                /*btnnumber.Enabled = false;
                btnfirst.Enabled = false;
                btnup.Enabled = false;
                btndown.Enabled = false;
                btnlast.Enabled = false;
                */
                cmbtype.Enabled = false;

            }
            else
            {
                /*btnnumber.Enabled = true;
                btnfirst.Enabled = true;
                btnup.Enabled = true;
                btndown.Enabled = true;
                btnlast.Enabled = true;
                */
                cmbtype.Enabled = true;
            }
        }

        private void btnfirst_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    bool has_selected = false;
                    foreach (DataGridViewRow checked_selected in dataGridView1.Rows)
                    {
                        if (checked_selected.Selected == true)
                        {
                            has_selected = true;
                        }
                    }


                    int no_selected = 0;
                    foreach (DataGridViewRow checked_selected in dataGridView1.Rows)
                    {
                        if (checked_selected.Selected == true)
                        {
                            no_selected = no_selected + 1;
                        }
                    }

                    if (no_selected > 1)
                    {
                        if (has_selected == true)
                        {
                            foreach (DataGridViewRow last_move in dataGridView1.Rows)
                            {
                                if (last_move.DefaultCellStyle.BackColor == Color.LightBlue)
                                {
                                    last_move.DefaultCellStyle.BackColor = Color.White;
                                }
                            }

                            foreach (DataGridViewRow oneCell in dataGridView1.SelectedRows)
                            {
                                //if (oneCell.Selected)
                                //{
                                int totalRows = dataGridView1.Rows.Count;
                                int idx = oneCell.Cells[0].OwningRow.Index;
                                if (idx == 0)
                                {
                                    //return;
                                }
                                else
                                {
                                    int col = oneCell.Cells[0].OwningColumn.Index;
                                    DataGridViewRowCollection rows = dataGridView1.Rows;
                                    DataGridViewRow row = rows[idx];
                                    rows.Remove(row);
                                    rows.Insert(0, row);
                                    //dataGridView1.ClearSelection();
                                    //oneCell.Selected = false;
                                    //dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[idx1].Selected = false;
                                    row.Selected = true;
                                    //oneCell.DefaultCellStyle.BackColor = Color.LightBlue;
                                }
                                //}
                            }
                            //dataGridView1.ClearSelection();
                            foreach (DataGridViewRow last_move in dataGridView1.Rows)
                            {
                                if (last_move.DefaultCellStyle.BackColor == Color.LightBlue)
                                {
                                    last_move.Selected = true;
                                }
                            }

                        }
                        else { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                    }
                    else
                    {
                        int totalRows = dataGridView1.Rows.Count;
                        int idx = dataGridView1.SelectedCells[0].OwningRow.Index;
                        if (idx == 0)
                            return;
                        int col = dataGridView1.SelectedCells[0].OwningColumn.Index;
                        DataGridViewRowCollection rows = dataGridView1.Rows;
                        DataGridViewRow row = rows[idx];
                        rows.Remove(row);
                        rows.Insert(0, row);
                        dataGridView1.ClearSelection();
                        dataGridView1.Rows[0].Cells[col].Selected = true;
                    }
                }
                else { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            catch { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
        private void btnup_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    foreach (DataGridViewRow last_move in dataGridView1.Rows)
                    {
                        if (last_move.DefaultCellStyle.BackColor == Color.LightBlue)
                        {
                            last_move.DefaultCellStyle.BackColor = Color.White;
                        }
                    }

                    int no_selected = 0;
                    foreach (DataGridViewRow checked_selected in dataGridView1.Rows)
                    {
                        if (checked_selected.Selected == true)
                        {
                            no_selected = no_selected + 1;
                        }
                    }

                    if (no_selected > 1)
                    {
                        foreach (DataGridViewRow oneCell in dataGridView1.Rows)
                        {
                            if (oneCell.Selected)
                            {
                                int totalRows = dataGridView1.Rows.Count;
                                //MessageBox.Show(totalRows.ToString());

                                int idx = oneCell.Cells[0].OwningRow.Index;
                                //MessageBox.Show(oneCell.Cells[1].Value.ToString());

                                if (idx == 0)
                                {
                                }
                                else
                                {
                                    int col = oneCell.Cells[0].OwningColumn.Index;
                                    //MessageBox.Show(col.ToString());

                                    DataGridViewRowCollection rows = dataGridView1.Rows;
                                    //MessageBox.Show(rows.ToString());

                                    DataGridViewRow row = rows[idx];
                                    //MessageBox.Show(row.ToString());

                                    rows.Remove(row);
                                    rows.Insert(idx - 1, row);
                                    row.Selected = true;

                                    //dataGridView1.ClearSelection();
                                    //dataGridView1.Rows[idx - 1].Cells[col].Selected = true;
                                    //oneCell.Selected = true;

                                }
                            }
                        }
                    }
                    else
                    {
                        int totalRows = dataGridView1.Rows.Count;
                        int idx = dataGridView1.SelectedCells[0].OwningRow.Index;
                        //int idx = dataGridView1.SelectedRows[0].Index;
                        if (idx == 0)
                            return;
                        int col = dataGridView1.SelectedCells[0].OwningColumn.Index;
                        //int col = dataGridView1.SelectedRows[0].Index;
                        DataGridViewRowCollection rows = dataGridView1.Rows;
                        DataGridViewRow row = rows[idx];
                        rows.Remove(row);
                        rows.Insert(idx - 1, row);
                        dataGridView1.ClearSelection();
                        dataGridView1.Rows[idx - 1].Cells[col].Selected = true;
                    }
                }
                else { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            catch { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            
        }
        private void btndown_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    foreach (DataGridViewRow last_move in dataGridView1.Rows)
                    {
                        if (last_move.DefaultCellStyle.BackColor == Color.LightBlue)
                        {
                            last_move.DefaultCellStyle.BackColor = Color.White;
                        }
                    }

                    if (dataGridView1.Rows.Count > 0)
                    {
                        int no_selected = 0;
                        foreach (DataGridViewRow checked_selected in dataGridView1.Rows)
                        {
                            if (checked_selected.Selected == true)
                            {
                                no_selected = no_selected + 1;
                            }
                        }
                        //MessageBox.Show(no_selected.ToString());
                        //MessageBox.Show(dataGridView1.SelectedRows[dataGridView1.SelectedRows.Count - 1].Index.ToString());

                        if (no_selected > 1)
                        {
                            for (int i = dataGridView1.Rows.Count - 1; i >= 0 && i <= dataGridView1.Rows.Count; i--)
                            {
                                //MessageBox.Show(i.ToString());

                                if (dataGridView1.Rows[i].Selected == true)
                                {
                                    if (i == dataGridView1.Rows.Count - 1)
                                    { }
                                    else
                                    {
                                        DataGridViewRowCollection rows = dataGridView1.Rows;
                                        DataGridViewRow row1 = rows[i];
                                        rows.Remove(row1);
                                        rows.Insert(i + 1, row1);
                                        row1.Selected = true;

                                    }

                                }
                            }

                        }
                        else
                        {
                            int totalRows1 = dataGridView1.Rows.Count;
                            int idx1 = dataGridView1.SelectedCells[0].OwningRow.Index;
                            if (idx1 == totalRows1 - 1)
                                return;
                            int col1 = dataGridView1.SelectedCells[0].OwningColumn.Index;
                            DataGridViewRowCollection rows = dataGridView1.Rows;
                            DataGridViewRow row1 = rows[idx1];
                            rows.Remove(row1);
                            rows.Insert(idx1 + 1, row1);
                            dataGridView1.ClearSelection();
                            dataGridView1.Rows[idx1 + 1].Cells[col1].Selected = true;
                        }
                    }
                    else { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
                else { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            catch { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
        private void btnlast_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    bool has_selected = false;
                    foreach (DataGridViewRow checked_selected in dataGridView1.Rows)
                    {
                        if (checked_selected.Selected == true)
                        {
                            has_selected = true;
                        }
                    }


                    int no_selected = 0;
                    foreach (DataGridViewRow checked_selected in dataGridView1.Rows)
                    {
                        if (checked_selected.Selected == true)
                        {
                            no_selected = no_selected + 1;
                        }
                    }

                    if (no_selected > 1)
                    {

                        if (has_selected == true)
                        {
                            foreach (DataGridViewRow last_move in dataGridView1.Rows)
                            {
                                if (last_move.DefaultCellStyle.BackColor == Color.LightBlue)
                                {
                                    last_move.DefaultCellStyle.BackColor = Color.White;
                                }
                            }

                            foreach (DataGridViewRow oneCell in dataGridView1.SelectedRows)
                            {
                                //if (oneCell.Selected)
                                //{
                                int totalRows1 = dataGridView1.Rows.Count;
                                int idx1 = oneCell.Cells[0].OwningRow.Index;
                                if (totalRows1 - 1 == idx1)
                                {
                                    //return;
                                }
                                else
                                {
                                    int col1 = oneCell.Cells[0].OwningColumn.Index;
                                    DataGridViewRowCollection rows = dataGridView1.Rows;
                                    DataGridViewRow row1 = rows[idx1];
                                    rows.Remove(row1);
                                    rows.Insert(totalRows1 - 1, row1); //rows.Insert(totalRows1 - 1, row1);
                                                                       //dataGridView1.ClearSelection();
                                    oneCell.Selected = false;
                                    //dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[idx1].Selected = false;
                                    row1.Selected = true;
                                    //oneCell.DefaultCellStyle.BackColor = Color.LightBlue;
                                }
                                //}
                            }
                            //dataGridView1.ClearSelection();
                            foreach (DataGridViewRow last_move in dataGridView1.Rows)
                            {
                                if (last_move.DefaultCellStyle.BackColor == Color.LightBlue)
                                {
                                    last_move.Selected = true;
                                }
                            }

                        }
                        else { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                    }
                    else
                    {
                        int totalRows1 = dataGridView1.Rows.Count;
                        int idx1 = dataGridView1.SelectedCells[0].OwningRow.Index;
                        if (idx1 == totalRows1 - 1)
                            return;
                        int col1 = dataGridView1.SelectedCells[0].OwningColumn.Index;
                        DataGridViewRowCollection rows = dataGridView1.Rows;
                        DataGridViewRow row1 = rows[idx1];
                        rows.Remove(row1);
                        rows.Insert(totalRows1 - 1, row1);
                        dataGridView1.ClearSelection();
                        dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[col1].Selected = true;
                    }
                }
                else { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            catch { MessageBox.Show("No selected PDF files. Unable to arrange the list", "NO SELECTED PDF", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
        private void btnclear_Click(object sender, EventArgs e)
        {
            int no_selected = 0;
            foreach (DataGridViewRow checked_selected in dataGridView1.Rows)
            {
                if (checked_selected.Selected == true)
                {
                    no_selected = no_selected + 1;
                }
            }

            if (no_selected > 0)
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    foreach (DataGridViewCell oneCell in dataGridView1.SelectedCells)
                    {
                        if (oneCell.Selected)
                            dataGridView1.Rows.RemoveAt(oneCell.RowIndex);
                    }
                    lblfiles.Text = dataGridView1.Rows.Count.ToString();
                }
                else
                {
                    lblfiles.Text = "0";
                    MessageBox.Show("Unable to remove PDF. Empty List.", "Empty List", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                count_first();
            }
            else { MessageBox.Show("No selected PDF files to be remove", "No selected files", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        }
        
        private void dataGridView1_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                if ((e.Button & MouseButtons.Left) == MouseButtons.Left)
                {
                    // If the mouse moves outside the rectangle, start the drag.
                    if (dragBoxFromMouseDown != Rectangle.Empty &&
                        !dragBoxFromMouseDown.Contains(e.X, e.Y))
                    {

                        // Proceed with the drag and drop, passing in the list item.                    
                        DragDropEffects dropEffect = dataGridView1.DoDragDrop(
                        dataGridView1.Rows[rowIndexFromMouseDown],
                        DragDropEffects.Move);
                    }
                }
            }
            catch
            {
            //    MessageBox.Show("Omar");
            }
        }
        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                { } // Get the index of the item the mouse is below.
                rowIndexFromMouseDown = dataGridView1.HitTest(e.X, e.Y).RowIndex;
                if (rowIndexFromMouseDown != -1)
                {
                    // Remember the point where the mouse down occurred. 
                    // The DragSize indicates the size that the mouse can move 
                    // before a drag event should be started.                
                    Size dragSize = SystemInformation.DragSize;

                    // Create a rectangle using the DragSize, with the mouse position being
                    // at the center of the rectangle.
                    dragBoxFromMouseDown = new Rectangle(new Point(e.X - (dragSize.Width / 2),
                                                                   e.Y - (dragSize.Height / 2)),
                                        dragSize);

                    dataGridView1.Rows[rowIndexFromMouseDown].Selected = false;
                }
                else
                    // Reset the rectangle if the mouse is not over an item in the ListBox.
                    dragBoxFromMouseDown = Rectangle.Empty;
            }
            catch { }
        }
        private void dataGridView1_DragOver(object sender, DragEventArgs e)
        {
            try
            {
                e.Effect = DragDropEffects.Move;

            }
            catch { }
        }
        private void dataGridView1_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                // The mouse locations are relative to the screen, so they must be 
                // converted to client coordinates.
                Point clientPoint = dataGridView1.PointToClient(new Point(e.X, e.Y));

                // Get the row index of the item the mouse is below. 
                rowIndexOfItemUnderMouseToDrop =
                    dataGridView1.HitTest(clientPoint.X, clientPoint.Y).RowIndex;

                // If the drag operation was a move then remove and insert the row.
                if (e.Effect == DragDropEffects.Move)
                {
                    if (rowIndexOfItemUnderMouseToDrop < 0 || rowIndexOfItemUnderMouseToDrop > dataGridView1.Rows.Count - 1)
                    {
                        MessageBox.Show("Invalid row placement. Please try again", "Invalid Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        DataGridViewRow rowToMove = e.Data.GetData(
                          typeof(DataGridViewRow)) as DataGridViewRow;
                        dataGridView1.Rows.RemoveAt(rowIndexFromMouseDown);
                        dataGridView1.Rows.Insert(rowIndexOfItemUnderMouseToDrop, rowToMove);
                        dataGridView1.Rows[rowIndexOfItemUnderMouseToDrop].Selected = true;
                        dataGridView1.Rows[rowIndexFromMouseDown].Selected = false;

                    }
                }
            }

            catch
            {
                //MessageBox.Show("Selected PDF has been removed in the List");// 
            }
        }

        private void cmbtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            //checktab = true;
            if (cmbtype.SelectedIndex == 0 && (txtpubno.Text != "" && txtrelno.Text != ""))
            {
                checktab = false;
                tabtype.Enabled = true;
                SELECT.Enabled = true;
                tabtype.SelectTab(0);
                //dataGridView1.Rows.Clear();
                dgvafilist.Rows.Clear();
                richTextBox1.Clear();
                richTextBox2.Clear();
                chksupp.Enabled = true;

                //if (dataGridView1.Columns[0].Visible == false)
                //{
                //    dataGridView1.Rows.Clear();
                //    lblfiles.Text = "0";
                //    lbltotalpage.Text = "0";
                //}

                if (dataGridView1.Rows.Count == 0)
                {

                    lblfiles.Text = "0";
                    lbltotalpage.Text = "0";
                    //Browse_file();
                }
            }
            else if (cmbtype.SelectedIndex == 1 && (txtpubno.Text != "" || txtrelno.Text != ""))
            {
                checktab = false;
                tabtype.Enabled = true;
                SELECT.Enabled = false;
                dataGridView1.Rows.Clear();
                tabtype.SelectTab(1);

                chksupp.Checked = false;
                chksupp.Enabled = false;
                //(tabtype.TabPages[0] as TabPage).Enabled = true;
                //(tabtype.TabPages[1] as TabPage).Enabled = false;

                lblfiles.Text = "0";
                lbltotalpage.Text = "0";

                richTextBox3.Clear();

            }
            else if (cmbtype.SelectedIndex == 2 && (txtpubno.Text != "" || txtrelno.Text != ""))
            {
                checktab = false;
                tabtype.Enabled = true;
                tabtype.SelectTab(2);
                dataGridView1.Rows.Clear();
                dgvafilist.Rows.Clear();
                richTextBox1.Clear();
                //(tabtype.TabPages[0] as TabPage).Enabled = false;
                //(tabtype.TabPages[1] as TabPage).Enabled = true;
            }
            lblnote.Text = "";
            checktab = true;

            if (cmbtype.SelectedIndex == 0)
            {
                lblleafreminder.Text = "";
                lblleafreminder.Text = "NOTE: For multi-volume supplement or bound. Please check which files will be the start of each volume.";
            }
            else if(cmbtype.SelectedIndex == 1)
            {
                lblleafreminder.Text = "";
                lblleafreminder.Text = "NOTE: If your release have flowbies. Please check which files will be the start of each volume.";
            }
        }
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnclearafi_Click(object sender, EventArgs e)
        {
            //richTextBox1.Enabled = true;
            richTextBox1.Clear();
            dataGridView1.Rows.Clear();
            dgvafilist.Rows.Clear();

            richTextBox2.Clear();
            lblfiles.Text = "";
            lbltotalpage.Text = "";
            
        }
        private void richTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            lblfiles.Text = dataGridView1.Rows.Count.ToString();
            lbltotalpage.Text = "0";
            int dg = dataGridView1.Rows.Count;
            //richTextBox1.Text = string.Join(Environment.NewLine, richTextBox1.Lines.Distinct());
            String perrow = richTextBox1.Text;
            if (dg > 0)
            {
                dataGridView1.Rows.Clear();
                richTextBox1.Clear();
                if (e.Control == true && e.KeyCode == Keys.V)
                {
                    e.Handled = true;

                    if (chkpubup.Checked == true)
                    {
                        string st = "fi0001" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox1.Text = st;
                    }
                    else
                    {
                        string st = "pubup01" + Environment.NewLine + "fi0001" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox1.Text = st;
                    }
                }

                ll_numbering();
            }
            else
            {
                if (e.Control == true && e.KeyCode == Keys.V)
                {
                    e.Handled = true;

                    if (chkpubup.Checked == true)
                    {
                        string st = "fi0001" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox1.Text = st;
                    }
                    else
                    {
                        string st = "pubup01" + Environment.NewLine + "fi0001" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox1.Text = st;
                    }
                }
                //MessageBox.Show("ag");
                ll_numbering();
                dataGridView1.Columns[0].Visible = true;

                lblfiles.Text = dataGridView1.Rows.Count.ToString();
                lbltotalpage.Text = "0";
            }
        }
        private void richTextBox2_KeyDown(object sender, KeyEventArgs e)
        {
            dgvafilist.Rows.Clear();
            richTextBox2.Clear();
            lblfiles.Text = dataGridView1.Rows.Count.ToString();
            lbltotalpage.Text = "0";
            int dg = dataGridView1.Rows.Count;
            //richTextBox1.Text = string.Join(Environment.NewLine, richTextBox1.Lines.Distinct());
            String perrow = richTextBox1.Text;
            if (dg > 0)
            {
                dataGridView1.Rows.Clear();
                richTextBox2.Clear();
                if (e.Control == true && e.KeyCode == Keys.V)
                {
                    e.Handled = true;

                    if (chkpubup.Checked == true)
                    {
                        string st = "filing instruction" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox2.Text = st;
                    }
                    else
                    {
                        string st = "pubupdate" + Environment.NewLine + "filing instruction" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox2.Text = st;
                    }
                }

                ll_numbering_2_pasted();
            }
            else
            {
                if (e.Control == true && e.KeyCode == Keys.V)
                {
                    e.Handled = true;

                    if (chkpubup.Checked == true)
                    {
                        string st = "filing instruction" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox2.Text = st;
                    }
                    else
                    {
                        string st = "pubupdate" + Environment.NewLine + "filing instruction" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox2.Text = st;
                    }
                }
                //MessageBox.Show("ag");
                ll_numbering_2_pasted();
                dataGridView1.Columns[0].Visible = true;

                lblfiles.Text = dataGridView1.Rows.Count.ToString();
                //lbltotalpage.Text = "0";
            }

        }
        private void tabtype_Selecting(object sender, TabControlCancelEventArgs e)
        {
            e.Cancel = checktab;
            checktab = true;
        }

        private void btnunnum_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count < 1)
            {
                MessageBox.Show("Empty List. Please browse PDF Files.", "Empty List", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //txtpubno.Text = Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Substring(Convert.ToInt32(Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Length) - 5, 5).ToString();
                unnumber_file();
                txtpubno.Text = Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Substring(Convert.ToInt32(Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()).Length) - 5, 5).ToString();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnzipsample_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(whole_pdf_count.ToString());
        }

        public void zipped_files()
        {
            int zip_num = 0;
            //string targetPath = @Path.GetDirectoryName(dataGridView1.Rows[1].Cells[1].Value.ToString()) + @"\For Clear\";//+ @"\" + folderno;
            string targetPath = @Path.GetDirectoryName(dataGridView1.Rows[0].Cells[1].Value.ToString()) + @"\For Clear\";//+ @"\" + folderno;
            string[] folders = System.IO.Directory.GetDirectories(targetPath, "*", System.IO.SearchOption.AllDirectories);

            for (int i = 0; i < folders.Length; i++)
            {
                zip_num = zip_num + 1;
                //MessageBox.Show(folders[i].ToString()); 
                //provide the folder to be zipped
                string folderToZip = @folders[i].ToString();

                //provide the path and name for the zip file to create
                string zipFile = targetPath + @"\" + Path.GetFileName(folders[i].ToString()) + ".zip";


                if (File.Exists(zipFile))
                {
                    File.Delete(zipFile);
                    //call the ZipFile.CreateFromDirectory() method
                    //ZipFile.CreateFromDirectory(folderToZip, zipFile, CompressionLevel.Fastest, false);
                    ZipFile.CreateFromDirectory(folderToZip, zipFile, CompressionLevel.Fastest, false);
                }
                else
                {
                    //call the ZipFile.CreateFromDirectory() method
                    //ZipFile.CreateFromDirectory(folderToZip, zipFile, CompressionLevel.Fastest, false);
                    ZipFile.CreateFromDirectory(folderToZip, zipFile, CompressionLevel.Fastest, false);
                }
            }
        }
        public void count_first()
        {
            if (dataGridView1.Rows.Count > 0)
            {
                int count_total = 0, pass_To_value = 0;
                foreach (DataGridViewRow paths in dataGridView1.Rows)
                {
                    string current_loc = paths.Cells[1].Value.ToString();
                    string ppath = @current_loc;
                    PdfReader pdfReader = new PdfReader(ppath);
                    int numberOfPages = pdfReader.NumberOfPages;

                    pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                    //tw.WriteLine(numberOfPages + "\t" + Path.GetFileName(current_loc) + "\n");
                    //totalpage = totalpage + numberOfPages;

                    paths.Cells[2].Value = numberOfPages;
                    pass_To_value = numberOfPages;
                    numberOfPages = 0;
                    count_total = count_total + pass_To_value;
                }
                lbltotalpage.Text = count_total.ToString();

                if ((Convert.ToInt16(lbltotalpage.Text) > 1850) && (cmbtype.SelectedIndex == 1))
                {
                    lblnote.Text = "Page exceeded 1850. Check for possible Flowbie Packages";
                }
                else
                {
                    lblnote.Text = "NONE";
                }
            }
            else
            {
                lbltotalpage.Text = "0";
                lblnote.Text = "NONE";
            }
        }

        private void bntcountonly_Click(object sender, EventArgs e)
        {

            if (txtpubno.Text == "" || txtrelno.Text == "")
            {
                MessageBox.Show("No Pub Number or Release number has been entered. Please provide these details before proceeding", "Pub Number and Release Number Requirement", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {

                if (dataGridView1.Rows.Count < 1)
                {
                    MessageBox.Show("Unable to count pages. Please browse and load PDF files", "Empty List", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (txtpubno.Text == "")
                    {
                        txtpubno.Text = Path.GetFileName(Path.GetDirectoryName(dataGridView1.SelectedCells[1].Value.ToString()));
                    }
                    int totalpage = 0;
                    string filename_text = txtpubno.Text + "_" + txtrelno.Text + ".txt";
                    string path = @txtlocpath.Text + @"\" + txtpubno.Text + "_Page Count Only" + ".txt";

                    if (!File.Exists(path))
                    {
                        File.Create(path).Dispose();
                        using (TextWriter tw = new StreamWriter(path))
                        {
                            tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                            foreach (DataGridViewRow paths in dataGridView1.Rows)
                            {
                                string current_loc = paths.Cells[1].Value.ToString();
                                string ppath = @current_loc;
                                PdfReader pdfReader = new PdfReader(ppath);
                                int numberOfPages = pdfReader.NumberOfPages;

                                pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                                tw.WriteLine(numberOfPages + "\t" + Path.GetFileName(current_loc) + "\n");
                                totalpage = totalpage + numberOfPages;

                                paths.Cells[2].Value = numberOfPages;
                            }
                            tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                            tw.Close();
                        }

                        lblfiles.Text = dataGridView1.Rows.Count.ToString();
                        lblpubnodet.Text = txtpubno.Text.ToString();
                        lblrelno.Text = txtrelno.Text.ToString();

                        lbltotalpage.Text = totalpage.ToString();
                        txtpagepath.Text = path.ToString();
                        MessageBox.Show("Page count has been generated. See Pub Details below for the location of the text file ", "Page Count", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    else if (File.Exists(path))
                    {
                        using (TextWriter tw = new StreamWriter(path))
                        {
                            tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                            foreach (DataGridViewRow paths in dataGridView1.Rows)
                            {
                                string current_loc = paths.Cells[1].Value.ToString();
                                string ppath = @current_loc;
                                PdfReader pdfReader = new PdfReader(ppath);
                                int numberOfPages = pdfReader.NumberOfPages;

                                pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  
                                tw.WriteLine(numberOfPages + "\t" + Path.GetFileName(current_loc) + "\n");
                                totalpage = totalpage + numberOfPages;

                                paths.Cells[2].Value = numberOfPages;
                            }
                            tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                            tw.Close();
                        }

                        lblfiles.Text = dataGridView1.Rows.Count.ToString();
                        lblpubnodet.Text = txtpubno.Text.ToString();
                        lblrelno.Text = txtrelno.Text.ToString();

                        lbltotalpage.Text = totalpage.ToString();
                        txtpagepath.Text = path.ToString();
                        MessageBox.Show("Page count has been generated. See Pub Details below for the location of the text file ", "Page Count", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                if ((Convert.ToInt16(lbltotalpage.Text) > 1850) && (cmbtype.SelectedIndex == 1))
                {
                    lblnote.Text = "Page exceeded 1850. Check for possible Flowbie Packages";
                }
                else
                {
                    lblnote.Text = "NONE";
                }
            }
        }
        private void btnnumberonly_Click(object sender, EventArgs e)
        {

            if (txtpubno.Text == "" || txtrelno.Text == "")
            {
                MessageBox.Show("No Pub Number or Release number has been entered. Please provide these details before proceeding", "Pub Number and Release Number Requirement", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    string new_name, fle, new_path;
                    int counter = 1;

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells["ColCheck"].Value) == true)
                        {
                            counter = 1;
                        }
                        fle = row.Cells[1].Value.ToString();
                        if (counter < 10)
                        {
                            new_name = "00" + counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        else if (counter < 100)
                        {
                            new_name = "0" + counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        else
                        {
                            new_name = counter + "-" + Path.GetFileName(fle);
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                            new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                            row.Cells[1].Value = new_path + @"\" + new_name;
                        }
                        counter += 1;
                    }

                    dataGridView1.Refresh();
                    int checkingcheck = 0;
                    foreach (DataGridViewRow chk in dataGridView1.Rows)
                    {
                        if (Convert.ToBoolean(chk.Cells[0].Value) == true)
                        {
                            checkingcheck = checkingcheck + 1;
                        }
                    }
                    newfolder_copyfiles();

                    string removedname, renamed, new_rename;
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        renamed = row.Cells[1].Value.ToString();
                        removedname = Path.GetFileName(renamed).Remove(0, 4);

                        //MessageBox.Show(Path.GetFileName(renamed).Substring(0, 5));
                        new_rename = Path.GetFileName(renamed).Substring(0, 5);

                        //get the 5 first letters and identify if 5  is a DIGIT , if YES = do not renumber, 
                        //NO = removed the first 4
                        Boolean result = new_rename.All(Char.IsLetterOrDigit);
                        if (result == true)
                        {
                            //MessageBox.Show("All DIGIT");
                        }
                        else
                        {
                            Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(renamed, removedname);
                            new_rename = Path.GetDirectoryName(renamed);
                            row.Cells[1].Value = new_rename + @"\" + removedname;
                            //MessageBox.Show("Not All Digit");
                        }
                    }
                    //MessageBox.Show("Sorting Prefixes has been removed");
                    //txtpubno.Text = lblpubnodet.Text;
                    MessageBox.Show("PDF has been renumbered successfully", "PDF Sorted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Unable to sort. List is empty", "Empty List", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            } 
        }
        private void btnsavelocal_Click(object sender, EventArgs e)
        {
            rbtJdrive.Checked = false;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void tabman_Click(object sender, EventArgs e)
        {

        }
        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }
        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void btncopytoclip_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(flowbie_pu.ToString() + " " + flowbie_pu_count.ToString());
            //MessageBox.Show(flowbie_fi.ToString() + " " + flowbie_fi_count.ToString());
            string textforClipboard = txtpagepath.Text;
            Clipboard.Clear();
            Clipboard.SetText(textforClipboard);
        }

        private void txtlocpath_TextChanged(object sender, EventArgs e)
        {
            txtgetpubno.Text = txtlocpath.Text;

            if (txtlocpath.Text == "")
            {
                txtpubno.Clear();
                txtrelno.Clear();
                txtpubno.Enabled = false;
                txtrelno.Enabled = false;
            }
            else
            {
                txtpubno.Enabled = true;
                txtrelno.Enabled = true;
            }
            
        }
        private void txtsearchpub_TextChanged(object sender, EventArgs e)
        {
            txtlocpath.Clear();
            txtlocpath.Text = @"\\fabwebd5.net\pclprod\NeptuneUS\pdf\" + txtsearchpub.Text;

            long a;
            if (!long.TryParse(txtsearchpub.Text, out a))
            {
                // If not int clear textbox text or Undo() last operation
                txtsearchpub.Clear();
            }

            if (txtsearchpub.Text == "")
            {
                txtlocpath.Enabled = true;
                txtlocpath.Clear();
            }
            else
            {
                txtlocpath.Enabled = false;
            }
        }

        private void btnafilist_Click(object sender, EventArgs e)
        {
            if (txtpubno.Text.ToString().Length < 5)
            {
                MessageBox.Show("Please enter the 5 Digit Pub Number", "Use 5 Digit Pub Number", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                load_afi();
            }
        }

        public void load_afi()
        {
            //-----------------------------------------
            try
            {
                OpenFileDialog openFileDialog1 = new OpenFileDialog();  //create openfileDialog Object
                openFileDialog1.Filter = "XML Files (*.xml; *.xls; *.xlsx; *.xlsm; *.xlsb) |*.xml; *.xls; *.xlsx; *.xlsm; *.xlsb";//open file format define Excel Files(.xls)|*.xls| Excel Files(.xlsx)|*.xlsx| 
                openFileDialog1.FilterIndex = 3;

                openFileDialog1.Multiselect = false;        //not allow multiline selection at the file selection level
                openFileDialog1.Title = "Open AFI Execl List";   //define the name of openfileDialog
                openFileDialog1.InitialDirectory = @"Desktop"; //define the initial directory

                if (openFileDialog1.ShowDialog() == DialogResult.OK)        //executing when file open
                {
                
                    dgvafilist.DataSource = null;
                    dgvafilist.Rows.Clear();
                    richTextBox1.Clear();
                    dataGridView1.Rows.Clear();

                    string pathName = openFileDialog1.FileName;
                    string fileName = System.IO.Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
                    DataTable tbContainer = new DataTable();
                    string strConn = string.Empty;
                    string sheetName = fileName;

                    FileInfo file = new FileInfo(pathName);
                    if (!file.Exists) { throw new Exception("Error, file doesn't exists!"); }
                    string extension = file.Extension;
                    switch (extension)
                    {
                        case ".xls":
                            strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                            //strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + pathName + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
                        break;
                        case ".xlsx":
                            //strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                            strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + pathName + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
                            break;
                        default:
                            strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                            break;
                    }

                    OleDbConnection cnnxls = new OleDbConnection(strConn);
                    cnnxls.Open();
                    DataTable dtsheet = new DataTable();
                    dtsheet = cnnxls.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    string ExcelSheetName = dtsheet.Rows[0]["Table_Name"].ToString();    //get First Excel Sheet Name

                    OleDbDataAdapter oda = new OleDbDataAdapter(string.Format("select * from [" + ExcelSheetName.Trim('\'') + "]", sheetName), cnnxls);
                    oda.Fill(tbContainer);

                

                for (int i = tbContainer.Rows.Count - 1; i >= 0; i--)
                {
                    DataRow dr = tbContainer.Rows[i];
                    if ((dr[1].ToString() == "") || (dr[1].ToString() == "Unit"))
                    {
                        dr.Delete();
                    }
                }
                tbContainer.AcceptChanges();

                if (chkpubup.Checked == true)
                    {
                        //dgvafilist.Rows.Add("fi0001", "");
                        dgvafilist.Rows.Add("filing instruction", "");
                    }
                    else
                    {
                        //dgvafilist.Rows.Add("pubup01", "");
                        //dgvafilist.Rows.Add("fi0001", "");
                        dgvafilist.Rows.Add("pubupdate", "");
                        dgvafilist.Rows.Add("filing instruction", "");
                    }

                    foreach (DataRow row in tbContainer.Rows)
                    {
                        dgvafilist.Rows.Add(row[1].ToString(), "");
                    }

                //dgvafilist.DataSource = tbContainer;

                    foreach (DataGridViewColumn dgcol in dgvafilist.Columns)
                    {
                        dgcol.SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                dgvafilist.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; 
                dgvafilist.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                cnnxls.Close();

                    //add_Pufi_browse_afi();
                    load_dgvafi_to_richtext(); // transfer distinct rows to Rich Text Box
                    //richTextBox2.Enabled = false;
                    richTextBox2.Clear();
                    lblfiles.Text = dataGridView1.Rows.Count.ToString();
            }

            }
            catch (Exception)
            {
                MessageBox.Show("Unable to load excel file. Please select file with .xls", "Unable to load", MessageBoxButtons.OK,  MessageBoxIcon.Information);
            }
        }
        public void load_dgvafi_to_richtext()
        {
            foreach (DataGridViewRow afirow in dgvafilist.Rows)
            {
                richTextBox1.AppendText(afirow.Cells[0].Value.ToString() + Environment.NewLine);
            }

            ll_numbering();
            //load_ll_via_Grid();
        }
        public void add_Pufi_browse_afi()
        {
            lblfiles.Text = dataGridView1.Rows.Count.ToString();
            lbltotalpage.Text = "0";
            int dg = dataGridView1.Rows.Count;
            //richTextBox1.Text = string.Join(Environment.NewLine, richTextBox1.Lines.Distinct());
            String perrow = richTextBox1.Text;
            if (dg > 0)
            {
                dataGridView1.Rows.Clear();
                richTextBox1.Clear();
                if (chkpubup.Checked == true)
                {
                    string st = "fi0001" + Environment.NewLine;
                    //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                    richTextBox1.Text = st;
                }
                else
                {
                    string st = "pubup01" + Environment.NewLine + "fi0001" + Environment.NewLine;
                    //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                    richTextBox1.Text = st;
                }

                //ll_numbering();
            }
            else
            {
                if (chkpubup.Checked == true)
                {
                    string st = "fi0001" + Environment.NewLine;
                    //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                    richTextBox1.Text = st;
                }
                else
                {
                    string st = "pubup01" + Environment.NewLine + "fi0001" + Environment.NewLine;
                    //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                    richTextBox1.Text = st;
                }
                //MessageBox.Show("ag");
                //ll_numbering();
                dataGridView1.Columns[0].Visible = true;

                lblfiles.Text = dataGridView1.Rows.Count.ToString();
                lbltotalpage.Text = "0";
            }
        }


        private void dgvafilist_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvafilist.ClearSelection();
        }
        private void chkautozipflowbie_CheckedChanged(object sender, EventArgs e)
        {
            if (chkautozipflowbie.Checked == true)
            {
                dataGridView1.Columns[0].Visible = false;
            }
            else
            {
                dataGridView1.Columns[0].Visible = true;
            }

            foreach (DataGridViewRow check_row in dataGridView1.Rows)
            {
                Convert.ToBoolean(check_row.Cells["ColCheck"].Value = false);
            }
        }

        private void btnaddmore_Click(object sender, EventArgs e)
        {

            if (txtpubno.Text == "" || txtrelno.Text == "")
            {
                MessageBox.Show("No Pub Number or Release number has been entered. Please provide these details before proceeding", "Pub Number and Release Number Requirement", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                browse_more();
            } 
        }
        public void browse_more()
        {
            OpenFileDialog fd = new OpenFileDialog();
            string strFileName = null;
            string pubno = txtpubno.Text;
            string relno = txtrelno.Text;
            int x;
            if (Directory.Exists(txtlocpath.Text))
            {
                fd.InitialDirectory = txtlocpath.Text;
                fd.Title = "Select PDF files";
                fd.InitialDirectory = txtlocpath.Text;
                fd.Filter = "PDF files (*.*)|*.pdf";
                //PDF files (*.*)|*.*|
                fd.FilterIndex = 2;
                fd.Multiselect = true;
                fd.RestoreDirectory = false;

                if (fd.ShowDialog() == DialogResult.OK)
                {
                    if (Path.GetDirectoryName(fd.FileName) != txtlocpath.Text)
                    {
                        MessageBox.Show("Browsing directory do not match the current directory", "Directory mismatched", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        for (x = 0; x <= fd.FileNames.Count() - 1; x++)
                        {
                            bool already_exist = false;
                            foreach (DataGridViewRow check_existence in dataGridView1.Rows)
                            {
                                if (fd.FileNames[x].ToString() == check_existence.Cells[1].Value.ToString())
                                {
                                    already_exist = true;
                                }
                            }

                            if (already_exist == false)
                            {
                                dataGridView1.Rows.Add(1, fd.FileNames[x].ToString());
                            }
                        }

                        strFileName = fd.FileName;

                        foreach (DataGridViewRow rowchk in dataGridView1.Rows)
                        {
                            if (Convert.ToBoolean(rowchk.Cells["ColCheck"].Value) == true)
                            {
                                Convert.ToBoolean(rowchk.Cells["ColCheck"].Value = false);
                            }
                            else
                            {
                            }
                        }
                    }
                    lblfiles.Text = dataGridView1.Rows.Count.ToString();
                }
                else
                {
                    MessageBox.Show("No Additonal PDF selected", "No PDF Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                dataGridView1.ClearSelection();

                foreach (DataGridViewRow highlight_row in dataGridView1.Rows)
                {
                    if (Convert.ToBoolean(highlight_row.Cells[0].Value) == true)
                    {
                        highlight_row.DefaultCellStyle.BackColor = Color.YellowGreen;
                    }
                    else
                    {
                        highlight_row.DefaultCellStyle.BackColor = Color.White;
                    }
                }


                count_first();
            }
        }


        // NOT INCLUDED
        /*public void load_ll_via_Grid()
        {
            richTextBox1.Text = string.Join(Environment.NewLine, richTextBox1.Lines.Distinct());

            string flenme;
            foreach (DataGridViewRow perrow in dgvafilist.Rows)
            {
                if ((perrow.Cells[0].Value.ToString().Contains("fi0")) || (perrow.Cells[0].Value.ToString().Contains("pubup")))
                {
                    flenme = txtpubno.Text + "_" + txtpubno.Text + "-" + perrow.Cells[0].Value.ToString() + ".pdf";
                }
                else
                {
                    flenme = txtpubno.Text + "_" + perrow.Cells[0].Value.ToString() + ".pdf";
                }

                if (File.Exists(@txtgetpubno.Text + @"\" + flenme))
                {
                    //MessageBox.Show(txtpubno.Text + "-" + str + ".pdf");
                    dataGridView1.Rows.Add(1, @txtgetpubno.Text + @"\" + flenme.ToString());
                    perrow.Cells[1].Value = "FOUND";
                }
                else
                {
                    perrow.Cells[1].Value = "MISSING";
                }
            }
            // uncheck all check column when pdf are loaded
            foreach (DataGridViewRow rowchk in dataGridView1.Rows)
            {
                Convert.ToBoolean(rowchk.Cells["ColCheck"].Value = false);
            }
        }
        //Not included Above
        */
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            foreach (DataGridViewRow highlight_row in dataGridView1.Rows)
            {
                if (Convert.ToBoolean(highlight_row.Cells[0].Value) == true)
                {
                    highlight_row.DefaultCellStyle.BackColor = Color.YellowGreen;
                }
                else
                {
                    highlight_row.DefaultCellStyle.BackColor = Color.White;
                }
            }
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox3_KeyDown(object sender, KeyEventArgs e)
        {
            richTextBox3.Clear();
            lblfiles.Text = dataGridView1.Rows.Count.ToString();
            lbltotalpage.Text = "0";
            int dg = dataGridView1.Rows.Count;
            //richTextBox3.Text = string.Join(Environment.NewLine, richTextBox3.Lines.Distinct());
            String perrow = richTextBox3.Text;
            if (dg > 0)
            {
                dataGridView1.Rows.Clear();
                richTextBox3.Clear();
                if (e.Control == true && e.KeyCode == Keys.V)
                {
                    e.Handled = true;
                    /*    
                    if (chkpubup.Checked == true)
                    {
                        string st = "pubup01" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox3.Text = st;
                    }
                    */
                    richTextBox3.Text = Clipboard.GetText();
                }
                
                load_for_bound_textfile_in_printcomp();
            }
            else
            {
                 if (e.Control == true && e.KeyCode == Keys.V)
                {
                    e.Handled = true;

                    /*
                        if (chkpubup.Checked == true)
                        {
                            string st = "pubup01" + Environment.NewLine + Clipboard.GetText();
                            //richTextBox3.Text = st;
                        }
                    */
                    richTextBox3.Text = Clipboard.GetText();
                }
                //MessageBox.Show("ag");
                load_for_bound_textfile_in_printcomp();
                dataGridView1.Columns[0].Visible = true;

                lblfiles.Text = dataGridView1.Rows.Count.ToString();
                //lbltotalpage.Text = "0";
            }
        }
        public void load_for_bound_textfile_in_printcomp()
        {
            richTextBox3.Text = string.Join(Environment.NewLine, richTextBox3.Lines.Distinct());
            String perrow = richTextBox3.Text;
            int dg = dataGridView1.Rows.Count;

            if (dg > 0)
            {
                if (MessageBox.Show("Current Items in Grid will be remove and new one will be loaded", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    dataGridView1.Rows.Clear();
                    load_bound();
                }
            }
            else
            {
                load_bound();
            }
        }
        public void load_bound()
        {
            string flenme;
            foreach (string str in richTextBox3.Lines)
            {
                /*if ((str.Contains("pubup")))
                {
                    flenme = txtpubno.Text + "_" + txtpubno.Text + "-" + str + ".pdf";
                }
                else
                {
                    flenme = txtpubno.Text + "_" + txtpubno.Text + "_" + str + ".pdf";
                } */
                flenme = txtpubno.Text + "_" + str + ".pdf";

                if (File.Exists(@txtgetpubno.Text + @"\" + flenme))
                {
                    dataGridView1.Rows.Add(1, @txtgetpubno.Text + @"\" + flenme.ToString());

                    /*foreach (DataGridViewRow check_row in dgvafilist.Rows)
                    {
                        if (str == check_row.Cells[0].Value.ToString())
                        {
                            check_row.Cells[1].Value = "PDF FOUND";
                        }
                    }
                    */
                }
                else
                { //MessageBox.Show("not found");
                }
            }
             //uncheck all check column when pdf are loaded
            foreach (DataGridViewRow rowchk in dataGridView1.Rows)
            {
                Convert.ToBoolean(rowchk.Cells["ColCheck"].Value = false);
            }
            //highlight missing
            /*foreach (DataGridViewRow missing_row in dgvafilist.Rows)
            {
                if (missing_row.Cells[1].Value.ToString() == "")
                {
                    missing_row.DefaultCellStyle.BackColor = Color.IndianRed;
                }
            }
            */
            count_first();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnboundclear_Click(object sender, EventArgs e)
        {
            richTextBox3.Clear();
            dataGridView1.Rows.Clear();
        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

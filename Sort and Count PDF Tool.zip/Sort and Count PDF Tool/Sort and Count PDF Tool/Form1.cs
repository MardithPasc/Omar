﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using iTextSharp.text.pdf;
using iTextSharp;
using System.IO.Compression;

namespace Sort_and_Count_PDF_Tool
{
    public partial class formcitrix : Form
    {
        //string path = @"\\fabwebd5.net\pclprod\NeptuneUS\VRS\DAT\" + txtpubno.Text + @"\sec" + @"\"+ filename_text;
        //int rowIndexFromMouseDown;
        //DataGridViewRow rw;
        private Rectangle dragBoxFromMouseDown;
        private int rowIndexFromMouseDown;
        private int rowIndexOfItemUnderMouseToDrop;
        bool checktab = true;
        public formcitrix()
        {
            InitializeComponent();
        }

        private void SELECT_Click(object sender, EventArgs e)
        {
            int fdcount = 0;

            fdcount = dataGridView1.Rows.Count;
            if (fdcount > 0)
            {
                if (MessageBox.Show("Current Items in ListBox will be removed", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    dataGridView1.Rows.Clear();
                    Browse_file();
                }
                else
                {
                    //Browse_file()
                }
            }
            else
            {
                Browse_file();

            }
        }
        public void Browse_file()
        {
            OpenFileDialog fd = new OpenFileDialog();
            string strFileName = null;
            string pubno = txtpubno.Text;
            string relno = txtrelno.Text;
            //int estpages, actpages;
            int x;

            if (txtpubno.Text.Count() < 5)
            {
                MessageBox.Show("Please enter the 5 Digit Pub Number");
            }
            else
            {
                if (Directory.Exists("C:\\Users\\Omardith\\Desktop\\Sample PDF\\" + pubno))
                {
                    fd.Title = "Select PDF files";
                    fd.InitialDirectory = "C:\\Users\\Omardith\\Desktop\\Sample PDF\\" + pubno;
                    fd.Filter = "PDF files (*.*)|*.pdf";
                    //PDF files (*.*)|*.*|
                    fd.FilterIndex = 2;
                    fd.Multiselect = true;
                    fd.RestoreDirectory = false;

                    if (fd.ShowDialog() == DialogResult.OK)
                    {
                        if ((Path.GetDirectoryName(fd.FileName) != fd.InitialDirectory))
                        {
                            MessageBox.Show("Selected path do not matched the Pub Number entered");
                        }
                        else
                        {
                            for (x = 0; x <= fd.FileNames.Count() - 1; x++)
                            {
                                dataGridView1.Rows.Add(1, fd.FileNames[x].ToString());
                            }
                            strFileName = fd.FileName;

                        }
                    }
                // uncheck all check column when pdf are loaded
                    foreach (DataGridViewRow rowchk in dataGridView1.Rows)
                    {
                        Convert.ToBoolean(rowchk.Cells["ColCheck"].Value = false);
                    }
                }
                
                else
                {
                    MessageBox.Show("Path not found. Please verify the correct pub number");
                }
            }
            
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            cmbtype.SelectedIndex = 0;
        }

        private void btnnumber_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("Empty List");
            }
            else
            {
                delelte_forclear_folder();
                number_file();
                unnumber_file();
            }
        }
        public void number_file()
        {
            auto_number_file();
            string new_name, fle, new_path;
            int counter = 1;
            bool hasfmv = false; 
            if (cmbtype.SelectedIndex == 1) //NEW ADDED
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Index == 0)
                    {
                        counter = 1;
                    }
                    else if ((row.Cells[1].Value.ToString().Contains("_fmv")|| (row.Cells[1].Value.ToString().Contains("_ptoc")) ) && (hasfmv == false))
                    {
                        counter = 1;
                        hasfmv = true;
                    }
                    fle = row.Cells[1].Value.ToString();
                    if (counter < 10)
                    {
                        new_name = "00" + counter + "-" + Path.GetFileName(fle);
                        Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                        new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                        row.Cells[1].Value = new_path + @"\" + new_name;
                        //dataGridView1.Refresh();
                    }
                    else if (counter < 100)
                    {
                        new_name = "0" + counter + "-" + Path.GetFileName(fle);
                        Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                        new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                        row.Cells[1].Value = new_path + @"\" + new_name;
                        //dataGridView1.Refresh();
                    }
                    else
                    {
                        new_name = counter + "-" + Path.GetFileName(fle);
                        Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                        new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                        row.Cells[1].Value = new_path + @"\" + new_name;
                        //dataGridView1.Refresh();
                    }
                    counter += 1;
                }
            }
            else
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (Convert.ToBoolean(row.Cells["ColCheck"].Value) == true)
                    {
                        counter = 1;
                    }
                    fle = row.Cells[1].Value.ToString();
                    if (counter < 10)
                    {
                        new_name = "00" + counter + "-" + Path.GetFileName(fle);
                        Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                        new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                        row.Cells[1].Value = new_path + @"\" + new_name;
                        //dataGridView1.Refresh();
                    }
                    else if (counter < 100)
                    {
                        new_name = "0" + counter + "-" + Path.GetFileName(fle);
                        Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                        new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                        row.Cells[1].Value = new_path + @"\" + new_name;
                        //dataGridView1.Refresh();
                    }
                    else
                    {
                        new_name = counter + "-" + Path.GetFileName(fle);
                        Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                        new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                        row.Cells[1].Value = new_path + @"\" + new_name;
                        //dataGridView1.Refresh();
                    }
                    counter += 1;
                }
            }
            dataGridView1.Refresh();
            int checkingcheck = 0;
            foreach (DataGridViewRow chk in dataGridView1.Rows)
            {
                if (Convert.ToBoolean(chk.Cells[0].Value) == true)
                {
                    checkingcheck = checkingcheck + 1;
                }
            }

            if (checkingcheck > 1) { each_vol_count();}
            //else if (cmbtype.SelectedIndex == 1) { each_vol_count(); }

            newfolder_copyfiles();
            MessageBox.Show("PDF has been renumbered successfully");
            hasfmv = false;
            //count_pdf();
        }

        public void auto_number_file()
        {
            string new_name, fle, new_path;
            int counter = 1;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                fle = row.Cells[1].Value.ToString();
                if (counter < 10)
                {
                    new_name = "00" + counter + "-" + Path.GetFileName(fle);
                    Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                    new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                    row.Cells[1].Value = new_path + @"\" + new_name;
                    //dataGridView1.Refresh();
                }
                else if (counter < 100)
                {
                    new_name = "0" + counter + "-" + Path.GetFileName(fle);
                    Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                    new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                    row.Cells[1].Value = new_path + @"\" + new_name;
                    //dataGridView1.Refresh();
                }
                else
                {
                    new_name = counter + "-" + Path.GetFileName(fle);
                    Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(fle, new_name);
                    new_path = Path.GetDirectoryName(fle); //Get the Directory where each row in pdf is located.
                    row.Cells[1].Value = new_path + @"\" + new_name;
                    //dataGridView1.Refresh();
                }
                counter += 1;
            }
            dataGridView1.Refresh();
            count_pdf();
            unnumber_file();
        }
        public void count_pdf()
        {
//NEW ADDED
            delele_txtfiles();

            if (txtpubno.Text == "")
            {
                txtpubno.Text = Path.GetFileName(Path.GetDirectoryName(dataGridView1.SelectedCells[1].Value.ToString()));
            }
            int totalpage = 0;
            string filename_text = txtpubno.Text + "_" + txtrelno.Text + ".txt";
            string path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + filename_text; // Location in  J Drive: + JRS + vat + pub number
                                                                                                                       //MessageBox.Show(path.ToString());
            if (!File.Exists(path))
            {
                File.Create(path).Dispose();
                using (TextWriter tw = new StreamWriter(path))
                {
                    tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                    foreach (DataGridViewRow paths in dataGridView1.Rows)
                    {
                        string current_loc = paths.Cells[1].Value.ToString();
                        string ppath = @current_loc;
                        PdfReader pdfReader = new PdfReader(ppath);
                        int numberOfPages = pdfReader.NumberOfPages;

                        pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                        tw.WriteLine(numberOfPages + "\t" + Path.GetFileName(current_loc) + "\n");
                        totalpage = totalpage + numberOfPages;
                    }
                    tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                    tw.Close();
                }
            }

            else if (File.Exists(path))
            {
                using (TextWriter tw = new StreamWriter(path))
                {
                    tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                    foreach (DataGridViewRow paths in dataGridView1.Rows)
                    {
                        string current_loc = paths.Cells[1].Value.ToString();
                        string ppath = @current_loc;
                        PdfReader pdfReader = new PdfReader(ppath);
                        int numberOfPages = pdfReader.NumberOfPages;

                        pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  
                        tw.WriteLine(numberOfPages + "\t" + Path.GetFileName(current_loc) + "\n");
                        totalpage = totalpage + numberOfPages;
                    }
                    tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                    tw.Close();
                }
            }
        }

        public void each_vol_count()
        {
            //NEW ADDED: if else for combobox
            int version = 0;
            int totalpage = 0;
            int dgtotal = dataGridView1.Rows.Count;

            if (cmbtype.SelectedIndex == 1)
            {

            }
            else
            {
                foreach (DataGridViewRow row_per in dataGridView1.Rows)
                {
                    int curidx = row_per.Index;
                    //new added: || (row_per.Index == 0 && (Convert.ToBoolean(row_per.Cells["ColCheck"].Value) == false))
                    if (Convert.ToBoolean(row_per.Cells["ColCheck"].Value) == true || (row_per.Index == 0 && (Convert.ToBoolean(row_per.Cells["ColCheck"].Value) == false)))
                    {
                        version = version + 1;
                        //totalpage  = 0; //NEW ADDED
                        string filename_text = txtpubno.Text + "_" + txtrelno.Text + "_v" + version + ".txt";
                        string path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + filename_text; // Location in  J Drive: + JRS + vat + pub number
                                                                                                                                   //MessageBox.Show(path.ToString());
                        if (!File.Exists(path))
                        {
                            File.Create(path).Dispose();
                            using (TextWriter tw = new StreamWriter(path))
                            {
                                tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                                string current_loc = row_per.Cells[1].Value.ToString();
                                string ppath = @current_loc;
                                PdfReader pdfReader = new PdfReader(ppath);
                                int numberOfPages = pdfReader.NumberOfPages;
                                pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  
                                                   //NEW ADDED
                                                   //tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                                   //totalpage = totalpage + numberOfPages;
                                                   //NEW ADDED
                                int nextrow = row_per.Index + 1;
                                if (nextrow < dgtotal)
                                {
                                    if (Convert.ToBoolean(dataGridView1.Rows[nextrow].Cells["ColCheck"].Value) == true)
                                    {
                                        tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                        totalpage = totalpage + numberOfPages;
                                        tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                        totalpage = 0;
                                        tw.Close();
                                    }
                                    else
                                    {
                                        tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                        totalpage = totalpage + numberOfPages;
                                        tw.Close();
                                    }

                                    //tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString()); //NEW ADDED
                                    //tw.Close();
                                }
                                else if (nextrow == dgtotal)
                                {
                                    tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                    totalpage = totalpage + numberOfPages;
                                    tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                    tw.Close();
                                }
                                //NEW ADDED: above
                            }
                        }

                        else
                        {
                            //File.Delete(path); //NEW ADDED
                            File.Create(path).Dispose();
                            using (TextWriter tw = new StreamWriter(path))
                            {
                                tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                                string current_loc = row_per.Cells[1].Value.ToString();
                                string ppath = @current_loc;
                                PdfReader pdfReader = new PdfReader(ppath);
                                int numberOfPages = pdfReader.NumberOfPages;
                                pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                                tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                totalpage = totalpage + numberOfPages;
                                tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString()); //NEW ADDED
                                totalpage = 0; //NEW ADDED
                                tw.Close();
                            }
                        }
                    }
                    else
                    {
                        //int totalpage = 0;
                        string filename_text = txtpubno.Text + "_" + txtrelno.Text + "_v" + version + ".txt";
                        string path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + filename_text; // Location in  J Drive: + JRS + vat + pub number
                                                                                                                                   //File.Delete(path); //NEW ADDED
                                                                                                                                   //File.Create(path).Dispose(); //NEW ADDED
                        using (TextWriter tw = new StreamWriter(path, true))
                        //using (StreamWriter sw = File.AppendText("c:/file.txt"));
                        {
                            //tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                            string current_loc = row_per.Cells[1].Value.ToString();
                            string ppath = @current_loc;
                            PdfReader pdfReader = new PdfReader(ppath);
                            int numberOfPages = pdfReader.NumberOfPages;

                            pdfReader.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  
                                               //tw.Close();
                            curidx = curidx + 1;
                            if (curidx < dgtotal)
                            {
                                if (Convert.ToBoolean(dataGridView1.Rows[curidx].Cells["ColCheck"].Value) == true)
                                {
                                    tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                    totalpage = totalpage + numberOfPages;
                                    tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                    totalpage = 0;
                                    tw.Close();
                                }
                                else
                                {
                                    tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                    totalpage = totalpage + numberOfPages;

                                    tw.Close();
                                }
                            }
                            else if (curidx == dgtotal)
                            {
                                tw.WriteLine("\n" + numberOfPages + "\t" + Path.GetFileName(current_loc));
                                totalpage = totalpage + numberOfPages;
                                tw.WriteLine("\n" + Environment.NewLine + totalpage.ToString());
                                tw.Close();
                            }
                        }
                    }
                }
            }
        }
        public void delele_txtfiles()
        {
            //string filename_text = txtpubno.Text + "_" + txtrelno.Text + ".txt";
            string path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\";//+ filename_text; // Location in  J Drive: + JRS + vat + pub number

            foreach (string fInfo in Directory.GetFiles(path))
            {
                if (fInfo.Contains(txtpubno.Text + "_" + txtrelno.Text))
                {
                    //MessageBox.Show("File found");
                    File.Delete(fInfo);
                }
            }
        }
        public void newfolder_copyfiles()
        {
            if (cmbtype.SelectedIndex == 1) //check if Process will be Looseleaf
            {
                flowbie_ll();
            }
            else
            {
                int folderno = 0;

                foreach (DataGridViewRow cpy in dataGridView1.Rows)
                {
                    int cpyidx = cpy.Index;
                    if (cpyidx == 0)
                    {
                        folderno = folderno + 1;
                        string targetPath = @Path.GetDirectoryName(cpy.Cells[1].Value.ToString()) + @"\" + folderno;
                        if (!Directory.Exists(targetPath))
                        {
                            Directory.CreateDirectory(targetPath);
                        }
                        else
                        {
                            Directory.Delete(targetPath, true);
                            Directory.CreateDirectory(targetPath);
                        }
                        //Copy the file from sourcepath and place into mentioned target path, 
                        //Overwrite the file if same file is exist in target path
                        var srcPath = cpy.Cells[1].Value.ToString();
                        File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(cpy.Cells[1].Value.ToString()), targetPath), true);
                    }
                    else
                    {
                        if (Convert.ToBoolean(cpy.Cells[0].Value.ToString()) == true)
                        {
                            folderno = folderno + 1;
                            string targetPath = @Path.GetDirectoryName(cpy.Cells[1].Value.ToString()) + @"\" + folderno;
                            if (!Directory.Exists(targetPath))
                            {
                                Directory.CreateDirectory(targetPath);
                            }
                            else
                            {
                                Directory.Delete(targetPath, true);
                                Directory.CreateDirectory(targetPath);
                            }
                            //Copy the file from sourcepath and place into mentioned target path, 
                            //Overwrite the file if same file is exist in target path
                            var srcPath = cpy.Cells[1].Value.ToString();
                            File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(cpy.Cells[1].Value.ToString()), targetPath), true);
                            //MessageBox.Show(Path.GetDirectoryName(cpy.Cells[1].Value.ToString()));
                        }
                        else
                        {
                            string targetPath = @Path.GetDirectoryName(cpy.Cells[1].Value.ToString()) + @"\" + folderno;
                            var srcPath = cpy.Cells[1].Value.ToString();
                            File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(cpy.Cells[1].Value.ToString()), targetPath), true);
                        }
                    }
                }
            }
        }
        public void flowbie_ll()
        {
            int totalpage1 = 0;
            int folderno1 = 0;
            string filename_text1 = txtpubno.Text + "_" + txtrelno.Text + ".txt";
            string path1 = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + filename_text1; // Location in  J Drive: + JRS + vat + pub number

            foreach (DataGridViewRow paths in dataGridView1.Rows)
            {
                string current_loc = paths.Cells[1].Value.ToString();
                string ppath = @current_loc;
                PdfReader pdfReader = new PdfReader(ppath);
                int numberOfPages = pdfReader.NumberOfPages;
                pdfReader.Close();
                totalpage1 = totalpage1 + numberOfPages;

                //MessageBox.Show(totalpage1.ToString());

                if ((paths.Index == 0 && paths.Cells[1].Value.ToString().Contains("-pubup")) || (paths.Index == 0 && paths.Cells[1].Value.ToString().Contains("-fi0")))
                {
                    folderno1 = folderno1 + 1;
                    string targetPath = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + txtpubno.Text + "_" + txtrelno.Text + "_" + "PKG" + folderno1;
                    if (!Directory.Exists(targetPath))
                    {
                        Directory.CreateDirectory(targetPath);
                    }
                    else
                    {
                        Directory.Delete(targetPath, true);
                        Directory.CreateDirectory(targetPath);
                    }
                    var srcPath = paths.Cells[1].Value.ToString();
                    File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath), true);

                   
                    if (paths.Cells[1].Value.ToString().Contains("-fi0"))
                    {
                        //int totalpage11 = 0;
                        string flow_txt = txtpubno.Text + "_" + txtrelno.Text + "_PKG" + folderno1 + ".txt";
                        string flow_path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + flow_txt; // Location in  J Drive: + JRS + vat + pub number
                        string path11 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + txtpubno.Text + "_" + txtrelno.Text + "_" + "PKG" + folderno1;                                                                                                           //MessageBox.Show(path.ToString());
                                                                                                                                                                                                                                                                                            //{
                        //File.Create(flow_path).Dispose();
                        //using (TextWriter tw = new StreamWriter(flow_path))
                        //{
                        //    tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                        //    foreach (string fInfo in Directory.GetFiles(path11))
                        //    {
                        //        PdfReader pdfReader1 = new PdfReader(fInfo);
                        //        int numberOfPages1 = pdfReader1.NumberOfPages;
                        //
                        //        pdfReader1.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                        //        tw.WriteLine(numberOfPages1 + "\t" + Path.GetFileName(fInfo) + "\n");
                        //       totalpage11 = totalpage11 + numberOfPages1;
                        //    }
                        //    tw.WriteLine("\n" + Environment.NewLine + totalpage11.ToString());
                        //    tw.Close();
                        //}

                        folderno1 = folderno1 + 1;
                        totalpage1 = 0;
                        //totalpage11 = 0;
                    }
                }
                else if (paths.Index > 0 && paths.Cells[1].Value.ToString().Contains("-fi0"))
                {
                    string targetPath = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + txtpubno.Text + "_" + txtrelno.Text + "_" + "PKG" + folderno1;
                    var srcPath = paths.Cells[1].Value.ToString();
                    File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath), true);

                   // int totalpage11 = 0;
                    //string flow_txt = txtpubno.Text + "_" + txtrelno.Text + "_PKG" + folderno1 + ".txt";
                    //string flow_path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + flow_txt; // Location in  J Drive: + JRS + vat + pub number
                    //string path11 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + txtpubno.Text + "_" + txtrelno.Text + "_" + "PKG" + folderno1;                                                                                                           //MessageBox.Show(path.ToString());
                    //{
                    //File.Create(flow_path).Dispose();
                    //using (TextWriter tw = new StreamWriter(flow_path))
                    //{
                    //tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                    //foreach (string fInfo in Directory.GetFiles(path11))
                    //{
                    //PdfReader pdfReader1 = new PdfReader(fInfo);
                    //int numberOfPages1 = pdfReader1.NumberOfPages;

                    //pdfReader1.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                    //tw.WriteLine(numberOfPages1 + "\t" + Path.GetFileName(fInfo) + "\n");
                    //totalpage11 = totalpage11 + numberOfPages1;
                    //}
                    //tw.WriteLine("\n" + Environment.NewLine + totalpage11.ToString());
                    //tw.Close();
                    //}

                    folderno1 = folderno1 + 1;
                    totalpage1 = 0;
                    //totalpage11 = 0;
                }
                else
                {
                    if (totalpage1 < 1850)
                    {
                        string targetPath1 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + txtpubno.Text + "_" + txtrelno.Text + "_" + "PKG" + folderno1;
                        if (!Directory.Exists(targetPath1))
                        {
                            Directory.CreateDirectory(targetPath1);
                        }
                        
                        var srcPath = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath1), true);
                        //MessageBox.Show("Testing dor <1850");
                    }
                    else
                    {
                        int totalpage2 = 0;
                        string flow_txt1 = txtpubno.Text + "_" + txtrelno.Text + "_PKG" + folderno1 + ".txt";
                        string flow_path1 = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + flow_txt1; // Location in  J Drive: + JRS + vat + pub number
                        string path111 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + txtpubno.Text + "_" + txtrelno.Text + "_" + "PKG" + folderno1;                                                                                                           //MessageBox.Show(path.ToString());
                                                                                                                                                                                                                                                                                            //{
                        File.Create(flow_path1).Dispose();
                        using (TextWriter tw = new StreamWriter(flow_path1))
                        {
                            tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                            foreach (string fInfo in Directory.GetFiles(path111))
                            {
                                PdfReader pdfReader1 = new PdfReader(fInfo);
                                int numberOfPages1 = pdfReader1.NumberOfPages;

                                pdfReader1.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                                tw.WriteLine(numberOfPages1 + "\t" + Path.GetFileName(fInfo) + "\n");
                                totalpage2 = totalpage2 + numberOfPages1;
                            }
                            tw.WriteLine("\n" + Environment.NewLine + totalpage2.ToString());
                            tw.Close();
                        }

                        folderno1 = folderno1 + 1;
                        string targetPath1 = @Path.GetDirectoryName(paths.Cells[1].Value.ToString()) + @"\For Clear\" + txtpubno.Text + "_" + txtrelno.Text + "_" + "PKG" + folderno1;
                        if (!Directory.Exists(targetPath1))
                        {
                            Directory.CreateDirectory(targetPath1);
                        }
                        else
                        {
                            Directory.Delete(targetPath1, true);
                            Directory.CreateDirectory(targetPath1);
                        }
                        var srcPath = paths.Cells[1].Value.ToString();
                        File.Copy(srcPath, srcPath.Replace(@Path.GetDirectoryName(paths.Cells[1].Value.ToString()), targetPath1), true);
                        totalpage1 = numberOfPages;
                    }
                }
            }
            //FOR LAST FOLDER IN THE PATH
            int lastpack = 0;
            string lastfilename = txtpubno.Text + "_" + txtrelno.Text + "_PKG" + folderno1 + ".txt";
            string lastpath = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + txtpubno.Text + @"\" + lastfilename; // Location in  J Drive: + JRS + vat + pub number
            string lastfolder = @"C:\Users\Omardith\Desktop\Sample PDF\" + txtpubno.Text + @"\For Clear\" + txtpubno.Text + "_" + txtrelno.Text + "_" + "PKG" + folderno1;                                                                                                         //MessageBox.Show(path.ToString());
                                                                                                                                                                                                                                                                                  //{
            File.Create(lastpath).Dispose();
            using (TextWriter tw = new StreamWriter(lastpath))
            {
                tw.WriteLine("Page" + "\t" + "Filename" + "\n");
                foreach (string fInfo in Directory.GetFiles(lastfolder))
                {
                    PdfReader pdfReader2 = new PdfReader(fInfo);
                    int numberOfPages2 = pdfReader2.NumberOfPages;

                    pdfReader2.Close(); // Used to Close the open PdfReader that causes the error while trying to renumber again without reloading files  

                    tw.WriteLine(numberOfPages2 + "\t" + Path.GetFileName(fInfo) + "\n");
                    lastpack = lastpack + numberOfPages2;

                }
                tw.WriteLine("\n" + Environment.NewLine + lastpack.ToString());
                tw.Close();
            }
        }
        public void flowbie_each_count()
        {
        
        }
        public void delelte_forclear_folder()
        {
            string path = @"C:\Users\Omardith\Desktop\Sample PDF\" + txtpubno.Text + @"\For Clear\";

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
                //Directory.Delete(path, true);
            }
            else
            {
                Directory.Delete(path, true);
                Directory.CreateDirectory(path);
            }
        }
        public void zipping_file()
        { }
        public void ll_numbering()
        {
            richTextBox1.Text = string.Join(Environment.NewLine, richTextBox1.Lines.Distinct());
            String perrow = richTextBox1.Text;
            int dg = dataGridView1.Rows.Count;

            if (dg > 0)
            {
                if (MessageBox.Show("Current Items in Grid will be remove and new one will be loaded", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    dataGridView1.Rows.Clear();
                    load_LL();
                }
                else
                {
                    //load_LL();
                }
            }
            else
            {
                load_LL();
            }
        }
        public void load_LL()
        {
            string flenme;
            foreach (string str in richTextBox1.Lines)
            {
                if ((str.Contains("fi0")) || (str.Contains("pubup")))
                {
                    flenme = txtpubno.Text + "_" + txtpubno.Text + "-" + str + ".pdf";
                }
                else
                {
                     flenme = txtpubno.Text + "_" + str + ".pdf";
                }

                if (File.Exists("C:\\Users\\Omardith\\Desktop\\Sample PDF\\" + txtpubno.Text + "\\" + flenme))
                {
                    //MessageBox.Show(txtpubno.Text + "-" + str + ".pdf");
                    dataGridView1.Rows.Add(1, "C:\\Users\\Omardith\\Desktop\\Sample PDF\\" + txtpubno.Text + "\\" + flenme.ToString());
                }
                else
                { //MessageBox.Show("not found");
                }
            }
            // uncheck all check column when pdf are loaded
            foreach (DataGridViewRow rowchk in dataGridView1.Rows)
            {
                Convert.ToBoolean(rowchk.Cells["ColCheck"].Value = false);
            }
        }

        private void btnunnum_Click(object sender, EventArgs e)
        {
            unnumber_file();
        }
        public void unnumber_file()
        {
            string removedname, renamed, new_rename;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                renamed = row.Cells[1].Value.ToString();
                removedname = Path.GetFileName(renamed).Remove(0, 4);
                
                //MessageBox.Show(Path.GetFileName(renamed).Substring(0, 5));
                new_rename = Path.GetFileName(renamed).Substring(0, 5);

                //get the 5 first letters and identify if 5  is a DIGIT , if YES = do not renumber, 
                //NO = removed the first 4
                Boolean result = new_rename.All(Char.IsLetterOrDigit);
                if (result == true)
                {
                    //MessageBox.Show("All DIGIT");
                }
                else
                {
                    Microsoft.VisualBasic.FileIO.FileSystem.RenameFile(renamed, removedname);
                    new_rename = Path.GetDirectoryName(renamed);
                    row.Cells[1].Value = new_rename + @"\" + removedname;
                    //MessageBox.Show("Not All Digit");
                }
            }
            //MessageBox.Show("Sorting Prefixes has been removed");
        }

        private void btnup_Click(object sender, EventArgs e)
        {
            try
            {
                int totalRows = dataGridView1.Rows.Count;
                int idx = dataGridView1.SelectedCells[0].OwningRow.Index;
                if (idx == 0)
                    return;
                int col = dataGridView1.SelectedCells[0].OwningColumn.Index;
                DataGridViewRowCollection rows = dataGridView1.Rows;
                DataGridViewRow row = rows[idx];
                rows.Remove(row);
                rows.Insert(idx - 1, row);
                dataGridView1.ClearSelection();
                dataGridView1.Rows[idx - 1].Cells[col].Selected = true;
            }
            catch { MessageBox.Show("Empty List"); }
        }
        private void btndown_Click(object sender, EventArgs e)
        {
            try
            {
                int totalRows1 = dataGridView1.Rows.Count;
                int idx1 = dataGridView1.SelectedCells[0].OwningRow.Index;
                if (idx1 == totalRows1 - 1)
                    return;
                int col1 = dataGridView1.SelectedCells[0].OwningColumn.Index;
                DataGridViewRowCollection rows = dataGridView1.Rows;
                DataGridViewRow row1 = rows[idx1];
                rows.Remove(row1);
                rows.Insert(idx1 + 1, row1);
                dataGridView1.ClearSelection();
                dataGridView1.Rows[idx1 + 1].Cells[col1].Selected = true;
            }
            catch { MessageBox.Show("Empty List"); }
        }
        private void btnclear_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewCell oneCell in dataGridView1.SelectedCells)
            {
                if (oneCell.Selected)
                    dataGridView1.Rows.RemoveAt(oneCell.RowIndex);
            }
        }
        private void btnfirst_Click(object sender, EventArgs e)
        {
            try
            {
                int totalRows = dataGridView1.Rows.Count;
                int idx = dataGridView1.SelectedCells[0].OwningRow.Index;
                if (idx == 0)
                    return;
                int col = dataGridView1.SelectedCells[0].OwningColumn.Index;
                DataGridViewRowCollection rows = dataGridView1.Rows;
                DataGridViewRow row = rows[idx];
                rows.Remove(row);
                rows.Insert(0, row);
                dataGridView1.ClearSelection();
                dataGridView1.Rows[0].Cells[col].Selected = true;
            }
            catch { MessageBox.Show("Empty List"); }
        }
        private void btnlast_Click(object sender, EventArgs e)
        {
            try
            {
                int totalRows1 = dataGridView1.Rows.Count;
                int idx1 = dataGridView1.SelectedCells[0].OwningRow.Index;
                if (idx1 == totalRows1 - 1)
                    return;
                int col1 = dataGridView1.SelectedCells[0].OwningColumn.Index;
                DataGridViewRowCollection rows = dataGridView1.Rows;
                DataGridViewRow row1 = rows[idx1];
                rows.Remove(row1);
                rows.Insert(totalRows1 - 1, row1);
                dataGridView1.ClearSelection();
                dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[col1].Selected = true;
            }
            catch { MessageBox.Show("Empty List"); }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public static string getBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // checking if the text file is already in the path
            string filename_text = txtpubno.Text + ".txt";
            string path = @"C:\Users\Omardith\Desktop" + @"\" + filename_text;

            MessageBox.Show(path.ToString());
            if (!File.Exists(path))
            {
                File.Create(path).Dispose();
                using (TextWriter tw = new StreamWriter(path))
                {
                    tw.WriteLine("The very first line!");
                    tw.Close();
                }
            }

            else if (File.Exists(path))
            {
                using (TextWriter tw = new StreamWriter(path))
                {
                    tw.WriteLine("Overwrite!");
                    tw.Close();
                }
            }
        }
        public void generate_txt()
        {
            string pubno_text = txtpubno.Text;
            string relno_text = txtrelno.Text;
            string filename_text = txtpubno.Text + "_" + relno_text + ".txt";
            string path = @"C:\Users\Omardith\Desktop\Sample PDF\vrs\vat\sec\" + pubno_text + @"\" + filename_text; // Location in  J Drive: + JRS + vat + pub number

            MessageBox.Show(path.ToString());
            if (!File.Exists(path))
            {
                File.Create(path).Dispose();
                using (TextWriter tw = new StreamWriter(path))
                {
                    MessageBox.Show("Text file has been created");
                    tw.Close();
                }
            }

            else if (File.Exists(path))
            {
                using (TextWriter tw = new StreamWriter(path))
                {
                    MessageBox.Show("A file exists in the path");
                    tw.Close();
                }
            }
        }

        private void txtpubno_TextChanged(object sender, EventArgs e)
        {
            if (txtpubno.Text == "" || txtrelno.Text == "")
            {
                SELECT.Enabled = false;
                btnclear.Enabled = false;
                btnnumber.Enabled = false;
                btnunnum.Enabled = false;
                btnfirst.Enabled = false;
                btnup.Enabled = false;
                btndown.Enabled = false;
                btnlast.Enabled = false;
                cmbtype.Enabled = false;
                
            }
            else
            {
                SELECT.Enabled = true;
                btnclear.Enabled = true;
                btnnumber.Enabled = true;
                btnunnum.Enabled = true;
                btnfirst.Enabled = true;
                btnup.Enabled = true;
                btndown.Enabled = true;
                btnlast.Enabled = true;
                cmbtype.Enabled = true;
            }
        }
        private void txtrelno_TextChanged(object sender, EventArgs e)
        {
            if (txtpubno.Text == "" || txtrelno.Text == "")
            {
                SELECT.Enabled = false;
                btnclear.Enabled = false;
                btnnumber.Enabled = false;
                btnunnum.Enabled = false;
                btnfirst.Enabled = false;
                btnup.Enabled = false;
                btndown.Enabled = false;
                btnlast.Enabled = false;
                cmbtype.Enabled = false;
            }
            else
            {
                SELECT.Enabled = true;
                btnclear.Enabled = true;
                btnnumber.Enabled = true;
                btnunnum.Enabled = true;
                btnfirst.Enabled = true;
                btnup.Enabled = true;
                btndown.Enabled = true;
                btnlast.Enabled = true;
                cmbtype.Enabled = true;
            }
        }

        private void dataGridView1_MouseMove(object sender, MouseEventArgs e)
        {
            if ((e.Button & MouseButtons.Left) == MouseButtons.Left)
            {
                // If the mouse moves outside the rectangle, start the drag.
                if (dragBoxFromMouseDown != Rectangle.Empty &&
                    !dragBoxFromMouseDown.Contains(e.X, e.Y))
                {

                    // Proceed with the drag and drop, passing in the list item.                    
                    DragDropEffects dropEffect = dataGridView1.DoDragDrop(
                    dataGridView1.Rows[rowIndexFromMouseDown],
                    DragDropEffects.Move);
                }
            }
        }
        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {
            // Get the index of the item the mouse is below.
            rowIndexFromMouseDown = dataGridView1.HitTest(e.X, e.Y).RowIndex;
            if (rowIndexFromMouseDown != -1)
            {
                // Remember the point where the mouse down occurred. 
                // The DragSize indicates the size that the mouse can move 
                // before a drag event should be started.                
                Size dragSize = SystemInformation.DragSize;

                // Create a rectangle using the DragSize, with the mouse position being
                // at the center of the rectangle.
                dragBoxFromMouseDown = new Rectangle(new Point(e.X - (dragSize.Width / 2),
                                                               e.Y - (dragSize.Height / 2)),
                                    dragSize);
            }
            else
                // Reset the rectangle if the mouse is not over an item in the ListBox.
                dragBoxFromMouseDown = Rectangle.Empty;
        }
        private void dataGridView1_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }
        private void dataGridView1_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                // The mouse locations are relative to the screen, so they must be 
                // converted to client coordinates.
                Point clientPoint = dataGridView1.PointToClient(new Point(e.X, e.Y));

                // Get the row index of the item the mouse is below. 
                rowIndexOfItemUnderMouseToDrop =
                    dataGridView1.HitTest(clientPoint.X, clientPoint.Y).RowIndex;

                // If the drag operation was a move then remove and insert the row.
                if (e.Effect == DragDropEffects.Move)
                {
                    if (rowIndexOfItemUnderMouseToDrop < 0 || rowIndexOfItemUnderMouseToDrop > dataGridView1.Rows.Count -1)
                    {
                        MessageBox.Show("Invalid row placement");
                    }
                    else
                    {
                        DataGridViewRow rowToMove = e.Data.GetData(
                          typeof(DataGridViewRow)) as DataGridViewRow;
                        dataGridView1.Rows.RemoveAt(rowIndexFromMouseDown);
                        dataGridView1.Rows.Insert(rowIndexOfItemUnderMouseToDrop, rowToMove);
                        dataGridView1.Rows[rowIndexOfItemUnderMouseToDrop].Selected = true;
                    } 
                }
            }

            catch
            { 
                //MessageBox.Show("Selected PDF has been removed in the List");// 
            }
        }

        private void richTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            int dg = dataGridView1.Rows.Count;
            //richTextBox1.Text = string.Join(Environment.NewLine, richTextBox1.Lines.Distinct());
            String perrow = richTextBox1.Text;
            if (dg > 0)
            {
                dataGridView1.Rows.Clear();
                richTextBox1.Clear();
                if (e.Control == true && e.KeyCode == Keys.V)
                {
                    e.Handled = true;

                    if (chkpubup.Checked == true)
                    {
                        string st = "fi0001" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox1.Text = st;
                    }
                    else
                    {
                        string st = "pubup01" + Environment.NewLine + "fi0001" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox1.Text = st;
                    }
                }

                ll_numbering();
            }
            else
            {
                if (e.Control == true && e.KeyCode == Keys.V)
                {
                    e.Handled = true;

                    if (chkpubup.Checked == true)
                    {
                        string st = "fi0001" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox1.Text = st;
                    }
                    else
                    {
                        string st = "pubup01" + Environment.NewLine + "fi0001" + Environment.NewLine + Clipboard.GetText();
                        //st = "pubup01" + Environment.NewLine + "fi0001" + Clipboard.GetText();
                        richTextBox1.Text = st;
                    }
                }
                //MessageBox.Show("ag");
                ll_numbering();
                dataGridView1.Columns[0].Visible = false;
            }
        }
        private void richTextBox1_MouseDown(object sender, MouseEventArgs e)
        {
            //if (e.Button == System.Windows.Forms.MouseButtons.Right)
            //{
            //    string st = Clipboard.GetText();
            //    richTextBox1.Text = st;
            //}
            
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabll_Click(object sender, EventArgs e)
        {

        }

        private void cmbtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            //checktab = true;
            if (cmbtype.SelectedIndex == 0 && (txtpubno.Text != "" && txtrelno.Text != ""))
            {
                checktab = false;
                tabtype.Enabled = true;
                SELECT.Enabled = true;
                tabtype.SelectTab(0);
                dataGridView1.Rows.Clear();
                richTextBox1.Clear();
            }
            else if (cmbtype.SelectedIndex == 1 && (txtpubno.Text != "" || txtrelno.Text != ""))
            {
                checktab = false;
                tabtype.Enabled = true;
                SELECT.Enabled = false;

                tabtype.SelectTab(1);
                //(tabtype.TabPages[0] as TabPage).Enabled = true;
                //(tabtype.TabPages[1] as TabPage).Enabled = false;

            }
            else if (cmbtype.SelectedIndex == 2 && (txtpubno.Text != "" || txtrelno.Text != ""))
            {
                checktab = false;
                tabtype.Enabled = true;
                tabtype.SelectTab(2);
                dataGridView1.Rows.Clear();
                richTextBox1.Clear();
                //(tabtype.TabPages[0] as TabPage).Enabled = false;
                //(tabtype.TabPages[1] as TabPage).Enabled = true;
            }
            checktab = true;
        }
        private void tabtype_Selecting(object sender, TabControlCancelEventArgs e)
        {

            e.Cancel = checktab;
            checktab = true;
        }
        private void btnclearafi_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            dataGridView1.Rows.Clear();
        }

        private void formcitrix_FormClosing(object sender, FormClosingEventArgs e)
        {
                System.Windows.Forms.Application.Exit();
        }

        private void chkpubup_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
